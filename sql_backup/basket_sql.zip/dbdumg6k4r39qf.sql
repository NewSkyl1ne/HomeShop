-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 23, 2021 at 07:18 AM
-- Server version: 5.7.32-35-log
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbdumg6k4r39qf`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Administrator',
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `phone`, `role`, `photo`, `password`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@basket.qa', '9207406780', 'Administrator', '1567720489logo.jpg', '$2y$10$hfYpYj94JrRE2zoPlrOEEuNEpDJJaVc/qzFQf3Ify3ykngs0.TEpS', 1, 'TYjbXc7wWl5wPElPLxqw2Evm8ZMpMsZsxOrsRdFfO18jI20grjMmtun7Fmfc', '2018-02-28 23:27:08', '2019-09-05 16:25:43');

-- --------------------------------------------------------

--
-- Table structure for table `admin_user_conversations`
--

CREATE TABLE `admin_user_conversations` (
  `id` int(191) NOT NULL,
  `subject` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(191) NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_user_conversations`
--

INSERT INTO `admin_user_conversations` (`id`, `subject`, `user_id`, `message`, `created_at`, `updated_at`) VALUES
(1, 'Test', 9, 'Test', '2019-10-26 21:02:42', '2019-10-26 21:02:42'),
(2, 'Test', 13, 'test', '2019-10-26 22:57:20', '2019-10-26 22:57:20'),
(3, 'sdss', 12, 'sdfds', '2019-10-26 22:58:40', '2019-10-26 22:58:40');

-- --------------------------------------------------------

--
-- Table structure for table `admin_user_messages`
--

CREATE TABLE `admin_user_messages` (
  `id` int(191) NOT NULL,
  `conversation_id` int(191) NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_user_messages`
--

INSERT INTO `admin_user_messages` (`id`, `conversation_id`, `message`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 'dgfdfsf', NULL, '2019-10-26 21:09:34', '2019-10-26 21:09:34'),
(2, 2, 'test', NULL, '2019-10-26 22:57:41', '2019-10-26 22:57:41'),
(3, 3, 'sdfds', NULL, '2019-10-26 22:59:15', '2019-10-26 22:59:15');

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` int(191) NOT NULL,
  `platform_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '1: Website 2: App',
  `app_slug` varchar(250) DEFAULT NULL,
  `photo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page` enum('home','inner') DEFAULT NULL,
  `type` enum('Large','Small') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `platform_type`, `app_slug`, `photo`, `link`, `page`, `type`) VALUES
(1, '1', NULL, '1567497996ad2.jpg', 'https://basket.qa/beta-api/public/', 'home', 'Small'),
(2, '1', NULL, '1567498012ad3.jpg', 'https://basket.qa/beta-api/public/', 'home', 'Small'),
(3, '1', NULL, '1567497983ad1.jpg', 'https://basket.qa/beta-api/public/item/digimart-girls-partyfestive-dress-cap-zyb12en9', 'home', 'Large'),
(4, '1', NULL, '1567498024ad4.jpg', 'https://basket.qa/beta-api/public/', 'home', 'Small'),
(5, '1', NULL, '1567498037ad5.jpg', 'https://basket.qa/beta-api/public/', 'home', 'Small'),
(6, '1', NULL, '1567498056ad6.jpg', 'https://basket.qa/beta-api/public/', 'home', 'Small'),
(9, '2', 'Latest', '15716527261567497983ad1.jpg', NULL, NULL, 'Large');

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(191) NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `meta_tag` text COLLATE utf8mb4_unicode_ci,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `tags` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

CREATE TABLE `blog_categories` (
  `id` int(191) NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `name`, `slug`) VALUES
(2, 'Oil & gas', 'oil-and-gas'),
(3, 'Manufacturing', 'manufacturing'),
(4, 'Chemical Research', 'chemical_research'),
(5, 'Agriculture', 'agriculture'),
(6, 'Mechanical', 'mechanical'),
(7, 'Entrepreneurs', 'entrepreneurs'),
(8, 'Technology', 'technology');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` varchar(250) NOT NULL,
  `size_key` varchar(250) DEFAULT NULL,
  `size_price` varchar(250) DEFAULT NULL,
  `size` varchar(250) DEFAULT NULL,
  `color` varchar(250) DEFAULT NULL,
  `stock` varchar(250) DEFAULT NULL,
  `price` int(250) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `qty`, `size_key`, `size_price`, `size`, `color`, `stock`, `price`, `updated_at`, `created_at`) VALUES
(82, 35, 10, '1', NULL, NULL, NULL, NULL, NULL, 1492, '2020-12-28 12:18:04', '2020-12-28 12:18:04');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(191) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `photo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_id`, `name`, `slug`, `status`, `photo`) VALUES
(4, 440, 'Dogs', '', 1, 'ad6.jpg'),
(5, 440, 'Cats', '', 1, NULL),
(6, 440, 'Vets', '', 1, NULL),
(48, 4, 'test', '', 1, NULL),
(49, 4, 'tssst', '', 1, NULL),
(50, 5, 'ttt', '', 1, NULL),
(51, 0, 'Furniture', 'Furniture', 1, '1567733771download.png'),
(52, 51, 'Living Room Furniture', '', 1, NULL),
(53, 51, 'Bedroom Furniture', '', 1, NULL),
(54, 51, 'Kitchen & Dining Furniture', '', 1, NULL),
(55, 51, 'Office Furniture', '', 1, NULL),
(56, 51, 'Accent Furniture', '', 1, NULL),
(57, 51, 'Entryway Furniture', '', 1, NULL),
(58, 51, 'Mattresses', '', 1, NULL),
(59, 51, 'Small Space Furniture', '', 1, NULL),
(60, 51, 'Kids Furniture', '', 1, NULL),
(61, 51, 'Made To Order Furniture', '', 1, NULL),
(62, 51, 'baby Furniture', '', 1, NULL),
(63, 51, 'Dorm Room Furniture ', '', 1, NULL),
(64, 51, 'Bath Furniture', '', 1, NULL),
(65, 51, 'Gameroom', '', 1, NULL),
(66, 51, 'Furniture Slipcovers', '', 1, NULL),
(67, 0, 'Bath', 'Bath', 1, '15677337621567688706bath.png'),
(68, 67, 'Bath Towels & Rugs', '', 1, NULL),
(69, 67, 'Bathroom Accessories', '', 1, NULL),
(70, 67, 'Shower', '', 1, NULL),
(71, 67, 'Bathroom Storage', '', 1, NULL),
(72, 67, 'Bath Furniture', '', 1, NULL),
(73, 67, 'Bathroom Mirrors & Lighting', '', 1, NULL),
(74, 67, 'Bathroom Fixtures', '', 1, NULL),
(75, 67, 'Kids Bath', '', 1, NULL),
(76, 67, 'Toilet Seats & Accessories', '', 1, NULL),
(77, 67, 'Bath Safety', '', 1, NULL),
(78, 67, 'Weekend Bathroom Makeover', '', 1, NULL),
(79, 0, 'Kitchen', 'Kitchen', 1, '15677337431567688722kitchen.png'),
(80, 79, 'Small Appliances', '', 1, NULL),
(81, 79, 'Kitchen Tools & Gadgets', '', 1, NULL),
(82, 79, 'Coffee & Tea', '', 1, NULL),
(83, 79, 'Cookware', '', 1, NULL),
(84, 79, 'Kitchen Organization', '', 1, NULL),
(85, 79, 'Bakeware & Baking Tools', '', 1, NULL),
(86, 79, 'Food Storage', '', 1, NULL),
(87, 79, 'Knives & Cutlery', '', 1, NULL),
(88, 79, 'Kitchen Linens', '', 1, NULL),
(89, 79, 'Sink Organization', '', 1, NULL),
(90, 79, 'Trash & Recycling', '', 1, NULL),
(91, 79, 'Large Appliances', '', 1, NULL),
(92, 79, 'Water & Filters', '', 1, NULL),
(93, 0, 'Outdoor', 'Outdoor', 1, '15677337341567688737outdoor.png'),
(94, 93, 'Patio Furniture', '', 1, NULL),
(95, 93, 'Patio Accessories', '', 1, NULL),
(96, 93, 'Patio Umbrellas & Shade', '', 1, NULL),
(97, 93, 'Grills & Outdoor Cooking', '', 1, NULL),
(98, 93, 'Outdoor Dining & Entertaining', '', 1, NULL),
(99, 93, 'Outdoor Decor', '', 1, NULL),
(100, 93, 'Fire Pits & Outdoor Heating', '', 1, NULL),
(101, 93, 'Lawn & Garden', '', 1, NULL),
(102, 93, 'Beach & Pool', '', 1, NULL),
(103, 93, 'Bikes', '', 1, NULL),
(104, 93, 'Sports & Outdoors', '', 1, NULL),
(105, 93, 'Mosquito & Pest Control', '', 1, NULL),
(106, 0, 'Baby and Kids', 'Baby-and-Kids', 1, '15677337251567688752kids.png'),
(107, 106, 'Strollers', '', 1, NULL),
(108, 106, 'Car Seats', '', 1, NULL),
(109, 106, 'Gear & Travel', '', 1, NULL),
(110, 106, 'Baby Nursery', '', 1, NULL),
(111, 106, 'Nursery Decor', '', 1, NULL),
(112, 106, 'Nursing & Feeding', '', 1, NULL),
(113, 106, 'Bath & Potty', '', 1, NULL),
(114, 106, 'Health & Safety', '', 1, NULL),
(115, 106, 'Infant Toys (Ages 0-3 Years)', '', 1, NULL),
(116, 106, 'Kids Toys', '', 1, NULL),
(117, 106, 'Seasonal', '', 1, NULL),
(118, 106, 'Baby & Kids Clothing', '', 1, NULL),
(119, 106, 'The Character Shop', '', 1, NULL),
(120, 52, 'Sofas & Loveseats', '', 1, NULL),
(121, 53, 'Beds', '', 1, NULL),
(122, 52, ' Sectional Sofas', '', 1, NULL),
(123, 52, 'Chairs & Recliners', '', 1, NULL),
(124, 52, 'Ottomans & Benches', '', 1, NULL),
(125, 52, 'Coffee Tables', '', 1, NULL),
(126, 52, 'Accent & End Tables', '', 1, NULL),
(127, 52, 'TV Stands & Entertainment   Centers', '', 1, NULL),
(128, 52, 'Console Tables', '', 1, NULL),
(129, 52, 'Fireplaces & Accessories', '', 1, NULL),
(130, 52, 'Futons & Sleeper Sofas', '', 1, NULL),
(131, 52, 'Bean Bag Chairs & Lounge Seating', '', 1, NULL),
(132, 53, 'Headboards', '', 1, NULL),
(133, 53, 'Nightstands', '', 1, NULL),
(134, 53, 'Mattresses', '', 1, NULL),
(135, 53, 'Dressers & Chests', '', 1, NULL),
(136, 53, 'Daybeds', '', 1, NULL),
(138, 53, 'Jewelry Armoires', '', 1, NULL),
(139, 53, 'Mirrors', '', 1, NULL),
(140, 53, 'Bunk & Loft Beds', '', 1, NULL),
(141, 53, 'Closet Systems', '', 1, NULL),
(142, 54, 'Bar Stools & Counter Stools', '', 1, NULL),
(143, 54, 'Kitchen Islands & Carts', '', 1, NULL),
(144, 54, 'Dining Sets', '', 1, NULL),
(145, 54, 'Bars & Bar Carts', '', 1, NULL),
(146, 54, 'Wine Racks & Cabinets', '', 1, NULL),
(147, 54, 'Dining Tables', '', 1, NULL),
(148, 54, 'Dining Chairs & Benches', '', 1, NULL),
(149, 54, 'Sideboards & Buffets', '', 1, NULL),
(150, 54, 'Curio Cabinets', '', 1, NULL),
(151, 54, 'Folding Tables & Chairs', '', 1, NULL),
(152, 54, 'Pub Tables & Bistro Sets', '', 1, NULL),
(153, 54, 'Baker\'s Racks', '', 1, NULL),
(154, 55, 'Desks', '', 1, NULL),
(155, 55, 'Office Chairs', '', 1, NULL),
(156, 55, 'Bookcases', '', 1, NULL),
(157, 55, 'Office Organization', '', 1, NULL),
(158, 56, 'Ottomans & Benches', '', 1, NULL),
(159, 56, 'Cabinets & Chests', '', 1, NULL),
(160, 56, 'Bookcases', '', 1, NULL),
(161, 56, 'Accent & end Tables', '', 1, NULL),
(162, 56, 'Accent Chairs', '', 1, NULL),
(163, 56, 'Luggage, Magazine & Blanket Racks', '', 1, NULL),
(164, 56, 'Room Dividers', '', 1, NULL),
(165, 56, 'Curio Cabinets', '', 1, NULL),
(166, 56, 'Accent & Garden Stools', '', 1, NULL),
(167, 57, 'Storage Benches & Shevling', '', 1, NULL),
(168, 57, 'Coat Racks & Umbrella Stands', '', 1, NULL),
(169, 57, 'Console Tables', '', 1, NULL),
(170, 57, 'Shoe Storage', '', 1, NULL),
(171, 58, 'Mattresses', '', 1, NULL),
(172, 58, 'Mattress Sets', '', 1, NULL),
(173, 58, 'Bed Frames', '', 1, NULL),
(174, 58, 'Adjustable Bases & Foundations', '', 1, NULL),
(175, 58, 'Air Mattresses & Portable Beds', '', 1, NULL),
(176, 58, 'Futon Mattresses', '', 1, NULL),
(180, 59, 'Office Furniture', '', 1, NULL),
(181, 59, 'Entryway Furniture', '', 1, NULL),
(182, 59, 'Outdoor Furniture', '', 1, NULL),
(183, 60, 'Toddler & Kids Beds', '', 1, NULL),
(184, 60, 'Kids Seating', '', 1, NULL),
(185, 60, 'Kids Tables & Chairs', '', 1, NULL),
(186, 60, 'Headboards', '', 1, NULL),
(187, 60, 'Bunk and Loft Beds', '', 1, NULL),
(188, 60, 'Twin and Full Mattresses', '', 1, NULL),
(189, 60, 'Toy Boxes & Chests', '', 1, NULL),
(190, 60, 'Bookshelves and Bookcases', '', 1, NULL),
(191, 60, 'Nightstands & Accent Tables', '', 1, NULL),
(192, 60, 'Dressers & Chests', '', 1, NULL),
(193, 60, 'Kids Desks & Vanities', '', 1, NULL),
(194, 60, 'Kids Outdoor Furniture', '', 1, NULL),
(195, 61, 'Sofas & Sectionals', '', 1, NULL),
(196, 61, 'Accent Chairs', '', 1, NULL),
(197, 61, 'Beds & Headboards', '', 1, NULL),
(198, 61, 'Dining Seating', '', 1, NULL),
(199, 61, 'Ottomans & Benches', '', 1, NULL),
(200, 62, 'Nursery Collections', '', 1, NULL),
(201, 62, 'Cribs', '', 1, NULL),
(202, 62, 'Bookshelves & Bookcases', '', 1, NULL),
(203, 62, 'Dressers & Chests', '', 1, NULL),
(204, 62, 'Nightstands', '', 1, NULL),
(205, 62, 'Hutches', '', 1, NULL),
(206, 62, 'Gliders & Rockers', '', 1, NULL),
(207, 62, 'Crib Mattresses', '', 1, NULL),
(208, 63, 'Chairs & Lounge Seating ', '', 1, NULL),
(209, 63, 'Desks & Desk Chairs', '', 1, NULL),
(210, 63, 'Dressers & Nightstands', '', 1, NULL),
(211, 63, 'Bookcases & Shelving', '', 1, NULL),
(212, 63, 'Mattresses & Accessories ', '', 1, NULL),
(213, 63, 'Beds & Headboards ', '', 1, NULL),
(214, 63, 'Futons & Sofa Beds ', '', 1, NULL),
(215, 63, 'Ottomans & Poufs', '', 1, NULL),
(216, 63, 'Accent Tables', '', 1, NULL),
(217, 63, ' Dining Tables & Chairs', '', 1, NULL),
(218, 63, 'TV Stands & Entertainment Centers', '', 1, NULL),
(219, 64, 'Bathroom Shelving', '', 1, NULL),
(220, 64, 'Makeup Vanity Sets', '', 1, NULL),
(222, 66, 'Sofa Slipcovers', '', 1, NULL),
(223, 66, 'Loveseat Slipcovers', '', 1, NULL),
(224, 66, 'Chair Slipcovers', '', 1, NULL),
(225, 66, 'Futon Slipcovers', '', 1, NULL),
(226, 66, 'Special Size Slipcovers', '', 1, NULL),
(227, 66, 'Accessories', '', 1, NULL),
(228, 68, 'Bath Towels', '', 1, NULL),
(229, 68, 'Bath Rugs', '', 1, NULL),
(230, 68, 'Beach Towels', '', 1, NULL),
(231, 68, 'Bathrobes & Slippers', '', 1, NULL),
(232, 69, 'Bathroom Accessory Sets', '', 1, NULL),
(233, 69, 'Soap & Lotion Dispensers', '', 1, NULL),
(234, 69, 'Wastebaskets', '', 1, NULL),
(235, 69, 'Toothbrush Holders', '', 1, NULL),
(236, 69, 'Scales', '', 1, NULL),
(237, 69, 'Vanity & Cosmetic Organizers', '', 1, NULL),
(238, 69, 'Guest Towels', '', 1, NULL),
(239, 70, 'Shower Curtains', '', 1, NULL),
(240, 70, 'Shower Hooks & Rods', '', 1, NULL),
(241, 70, 'Shower Curtain Liners', '', 1, NULL),
(242, 70, 'Shower Heads', '', 1, NULL),
(243, 70, 'Shower & Bath Accessories', '', 1, NULL),
(244, 70, 'Shower & Tub Mats', '', 1, NULL),
(245, 70, 'Bath Window Curtains', '', 1, NULL),
(246, 71, 'Shower & Bath Caddies', '', 1, NULL),
(247, 71, 'Cabinet Organization', '', 1, NULL),
(248, 71, 'Over The Toilet Storage', '', 1, NULL),
(249, 71, 'Hampers', '', 1, NULL),
(250, 71, 'Countertop Organization', '', 1, NULL),
(251, 71, 'Vanity & Cosmetic Organizers', '', 1, NULL),
(252, 71, 'Wall Cabinets', '', 1, NULL),
(253, 71, 'Floor Cabinets', '', 1, NULL),
(254, 72, 'Bathroom Shelving', '', 1, NULL),
(255, 72, 'Makeup Vanity Sets', '', 1, NULL),
(257, 73, 'Makeup Mirrors', '', 1, NULL),
(258, 73, 'Bathroom Wall Mirrors', '', 1, NULL),
(259, 73, 'Medicine Cabinets', '', 1, NULL),
(260, 73, 'Vanity Lighting', '', 1, NULL),
(261, 73, 'Ceiling Lighting', '', 1, NULL),
(262, 74, 'Towel Bars', '', 1, NULL),
(263, 74, 'Bathroom Hardware Collections', '', 1, NULL),
(264, 74, 'Bathroom Vanities', '', 1, NULL),
(265, 74, 'Bathroom Sinks', '', 1, NULL),
(266, 74, 'Bathroom Faucets', '', 1, NULL),
(267, 74, 'Cabinet knobs & Pulls', '', 1, NULL),
(268, 74, 'Towel Warmers', '', 1, NULL),
(269, 74, 'Wall Shelves', '', 1, NULL),
(270, 74, 'Towel Rings', '', 1, NULL),
(271, 74, 'Robe & Towel Hooks', '', 1, NULL),
(272, 74, 'Toilet Paper Holders', '', 1, NULL),
(273, 74, 'Bathtub', '', 1, NULL),
(274, 75, 'Kids Shower Curtains', '', 1, NULL),
(275, 75, 'Kids Bathroom Accessories', '', 1, NULL),
(276, 75, 'Kids Bath Towels', '', 1, NULL),
(277, 75, 'Kids bath Rugs', '', 1, NULL),
(278, 76, 'Toilet Seats', '', 1, NULL),
(279, 76, 'Bidet Seats & Attachments', '', 1, NULL),
(280, 76, 'Toilet Brushes & Plungers', '', 1, NULL),
(281, 76, 'Toilet Paper Holders', '', 1, NULL),
(282, 76, 'Toilet Accessories', '', 1, NULL),
(283, 77, 'Shower Safety', '', 1, NULL),
(284, 77, 'Grips & Rails', '', 1, NULL),
(285, 77, 'Toilet Safety', '', 1, NULL),
(286, 78, 'Personalize Your Bathroom', '', 1, NULL),
(287, 78, 'Farmhouse Bathroom', '', 1, NULL),
(288, 78, 'Vintage Chic Bathroom', '', 1, NULL),
(289, 78, 'Mid Century Modern Bathroom', '', 1, NULL),
(290, 78, 'Maximize Your Bathroom Space', '', 1, NULL),
(291, 78, 'Traditional Bathroom', '', 1, NULL),
(292, 78, 'Contemporary Bathroom', '', 1, NULL),
(293, 78, 'Coastal Bathroom', '', 1, NULL),
(294, 78, 'Global Evolution Bathroom', '', 1, NULL),
(295, 80, 'Blenders', '', 1, NULL),
(296, 80, 'Juicers', '', 1, NULL),
(297, 80, 'Food Processors', '', 1, NULL),
(298, 80, 'Mixers & Attachments', '', 1, NULL),
(299, 80, 'Toasters & Ovens', '', 1, NULL),
(300, 80, 'Microwaves', '', 1, NULL),
(301, 80, 'Coffee, Tea & Espresso', '', 1, NULL),
(302, 80, 'Air Fryers & Deep Fryers', '', 1, NULL),
(303, 80, 'Slow Cookers & Multi Cookers', '', 1, NULL),
(304, 80, 'Pressure Cookers', '', 1, NULL),
(305, 80, 'Panini Presses & Indoor Grills', '', 1, NULL),
(306, 80, 'Waffle Makers', '', 1, NULL),
(307, 80, 'Bread Makers', '', 1, NULL),
(308, 80, 'Ice Cream Makers', '', 1, NULL),
(309, 80, 'Rice Cookers', '', 1, NULL),
(310, 80, 'Popcorn Makers', '', 1, NULL),
(311, 80, 'Meat Slicers & Grinders', '', 1, NULL),
(312, 80, 'Dehydrators', '', 1, NULL),
(313, 80, 'Soda Makers', '', 1, NULL),
(314, 80, 'Wine Refrigerators', '', 1, NULL),
(315, 81, ' Cooking Utensils', '', 1, NULL),
(316, 81, 'Choppers', '', 1, NULL),
(317, 81, 'Graters & Zesters', '', 1, NULL),
(318, 81, 'Spiralizers', '', 1, NULL),
(319, 81, 'Peelers', '', 1, NULL),
(320, 81, 'Slicers', '', 1, NULL),
(321, 81, 'Mixing Bowls', '', 1, NULL),
(322, 81, 'Measuring Tools', '', 1, NULL),
(323, 81, 'Can & Jar Openers', '', 1, NULL),
(324, 81, 'Colanders & Strainers', '', 1, NULL),
(325, 81, 'Salt & Pepper', '', 1, NULL),
(326, 81, ' Ice Trays', '', 1, NULL),
(327, 81, 'Ice Cream & Pop Tools', '', 1, NULL),
(328, 81, 'Fruit & Vegetable Tools', '', 1, NULL),
(329, 81, 'Meat & Seafood Tools', '', 1, NULL),
(330, 81, 'Garlic & Herb Tools', '', 1, NULL),
(331, 81, 'Baking & Decorating Tools', '', 1, NULL),
(332, 81, 'Specialized Kitchen Tools', '', 1, NULL),
(333, 82, 'Coffee Makers', '', 1, NULL),
(334, 82, 'Single Serve Coffee Makers', '', 1, NULL),
(335, 82, 'Espresso Machines', '', 1, NULL),
(336, 82, 'French Press', '', 1, NULL),
(337, 82, 'Coffee', '', 1, NULL),
(338, 82, 'Cold Brew Coffee Makers', '', 1, NULL),
(339, 82, 'Pour Over Coffee Makers', '', 1, NULL),
(340, 82, 'Coffee Grinders', '', 1, NULL),
(341, 82, 'Tea & Accessories', '', 1, NULL),
(342, 82, 'Tea Kettles & Pots', '', 1, NULL),
(343, 82, 'Coffee Carafes', '', 1, NULL),
(344, 82, 'Coffee Accessories', '', 1, NULL),
(345, 82, 'Travel Mugs', '', 1, NULL),
(346, 83, 'Cookware Sets', '', 1, NULL),
(347, 83, 'Frying Pans & Skillets', '', 1, NULL),
(348, 83, 'Saute Pans', '', 1, NULL),
(349, 83, 'Dutch Ovens & Braisers', '', 1, NULL),
(350, 83, 'Roasters', '', 1, NULL),
(351, 83, 'Saucepans & Sauciers', '', 1, NULL),
(352, 83, 'Grill Pans & Griddles', '', 1, NULL),
(353, 83, 'Stock Soup & Multipots', '', 1, NULL),
(354, 83, 'Pressure Cookers', '', 1, NULL),
(355, 83, 'Specialty Cookware', '', 1, NULL),
(356, 83, 'Cookware Collections', '', 1, NULL),
(357, 83, 'Tea Kettles', '', 1, NULL),
(358, 83, 'Lids & Splatter Screens', '', 1, NULL),
(359, 83, 'Pot Racks', '', 1, NULL),
(360, 84, 'Drawer Organizers', '', 1, NULL),
(361, 84, 'Cabinet Organizers', '', 1, NULL),
(362, 84, 'Counter Organizers', '', 1, NULL),
(363, 84, 'Refrigerator Organizers', '', 1, NULL),
(364, 84, 'Spice Racks', '', 1, NULL),
(365, 84, 'Kitchen Carts', '', 1, NULL),
(366, 84, 'Pot Racks', '', 1, NULL),
(367, 85, 'Bakeware Sets', '', 1, NULL),
(368, 85, 'Baking Dishes', '', 1, NULL),
(369, 85, 'Baking & Cookie Sheets', '', 1, NULL),
(370, 85, 'Baking & Decorating Tools', '', 1, NULL),
(371, 85, 'Measuring Tools', '', 1, NULL),
(372, 85, 'Cake Pans', '', 1, NULL),
(373, 85, 'Bread & Loaf Pans', '', 1, NULL),
(374, 85, 'Cupcake & Muffin Pans', '', 1, NULL),
(375, 85, 'Pie Dishes & Tart Pans', '', 1, NULL),
(376, 85, 'Pizza Stones & Accessories', '', 1, NULL),
(377, 85, 'Mixing Bowls', '', 1, NULL),
(378, 86, 'Food Storage Containers', '', 1, NULL),
(379, 86, 'Canisters', '', 1, NULL),
(380, 86, 'Lunch Bags & On-The-Go', '', 1, NULL),
(381, 86, 'Canning', '', 1, NULL),
(382, 87, 'Knife Blocks & Storage', '', 1, NULL),
(383, 87, 'Knife Sets', '', 1, NULL),
(384, 87, 'Steak Knives', '', 1, NULL),
(385, 87, 'Chef Knives', '', 1, NULL),
(386, 87, 'Santoku Knives', '', 1, NULL),
(387, 87, 'Knife Collections', '', 1, NULL),
(388, 87, 'Paring Knives', '', 1, NULL),
(389, 87, 'Slicing & Carving Knives', '', 1, NULL),
(390, 87, 'Utility Knives', '', 1, NULL),
(391, 87, 'Bread Knives', '', 1, NULL),
(392, 87, 'Cleavers', '', 1, NULL),
(393, 87, 'Boning & Fillet Knives', '', 1, NULL),
(394, 87, 'Cheese Knives', '', 1, NULL),
(395, 87, 'Specialty Knives', '', 1, NULL),
(396, 87, 'Kitchen Shears', '', 1, NULL),
(397, 87, 'Knife Sharpeners', '', 1, NULL),
(398, 87, 'Cutting Boards', '', 1, NULL),
(442, 0, 'Pets', 'Pets', 1, '15677337081567688763petfood.png'),
(443, 442, 'Pet Food', '', 1, NULL),
(444, 443, 'Cats', '', 1, NULL),
(445, 443, 'Vets', '', 1, NULL),
(446, 443, 'Dogs', '', 1, NULL),
(447, 442, 'Pets Accessories', 'Pets Accessories', 1, NULL),
(448, 0, 'Test', '22', 0, NULL),
(449, 448, 'test1', '22', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `childcategories`
--

CREATE TABLE `childcategories` (
  `id` int(191) NOT NULL,
  `subcategory_id` int(191) NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(191) NOT NULL,
  `user_id` int(191) UNSIGNED NOT NULL,
  `product_id` int(191) UNSIGNED NOT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `conversations`
--

CREATE TABLE `conversations` (
  `id` int(191) NOT NULL,
  `subject` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_user` int(191) NOT NULL,
  `recieved_user` int(191) NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` int(11) NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` tinyint(4) NOT NULL,
  `price` double NOT NULL,
  `times` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `used` int(191) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `start_date` date NOT NULL,
  `end_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `code`, `type`, `price`, `times`, `used`, `status`, `start_date`, `end_date`) VALUES
(1, 'BASKET50', 0, 50, NULL, 0, 1, '2019-10-20', '2019-10-31'),
(2, 'BASKET40', 1, 40, NULL, 0, 1, '2019-10-20', '2019-10-31');

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE `currencies` (
  `id` int(191) NOT NULL,
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sign` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` double NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `name`, `sign`, `value`, `is_default`) VALUES
(1, 'USD', 'QAR', 1, 1),
(4, 'BDT', '৳', 82.92649841308594, 0),
(6, 'EUR', '€', 0.864870011806488, 0);

-- --------------------------------------------------------

--
-- Table structure for table `delivery_time`
--

CREATE TABLE `delivery_time` (
  `id` int(11) NOT NULL,
  `time` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_time`
--

INSERT INTO `delivery_time` (`id`, `time`) VALUES
(1, '2PM - 5PM'),
(2, '6PM - 9PM'),
(3, '9PM - 11PM');

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL,
  `email_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_subject` mediumtext COLLATE utf8_unicode_ci,
  `email_body` longtext COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`id`, `email_type`, `email_subject`, `email_body`, `status`) VALUES
(1, 'new_order', 'Your Order Placed Successfully', '<p>Hello {customer_name},<br>Your order has been placed successfully</p>', 1),
(2, 'new_registration', 'Welcome To Royal Commerce', '<p>Hello {customer_name},<br>You have successfully registered to {website_title}, We wish you will have a wonderful experience using our service.</p><p>Thank You<br></p>', 1),
(3, 'vendor_accept', 'Your Vendor Account Activated', '<p>Hello {customer_name},<br>Your Vendor Account Activated Successfully. Please Login to your account and build your own shop.</p><p>Thank You<br></p>', 1),
(4, 'subscription_warning', 'Your subscrption plan will end after five days', '<p>Hello {customer_name},<br>Your subscription plan duration will end after five days. Please renew your plan otherwise all of your products will be deactivated.</p><p>Thank You<br></p>', 1);

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `title`, `details`, `status`) VALUES
(1, 'Right my front it wound cause fully', '<span style=\"color: rgb(70, 85, 65); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 16px;\">Nam enim risus, molestie et, porta ac, aliquam ac, risus. Quisque lobortis. Phasellus pellentesque purus in massa. Aenean in pede. Phasellus ac libero ac tellus pellentesque semper. Sed ac felis. Sed commodo, magna quis lacinia ornare, quam ante aliquam nisi, eu iaculis leo purus venenatis dui.</span><br>', 1),
(3, 'Man particular insensible celebrated', '<span style=\"color: rgb(70, 85, 65); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 16px;\">Nam enim risus, molestie et, porta ac, aliquam ac, risus. Quisque lobortis. Phasellus pellentesque purus in massa. Aenean in pede. Phasellus ac libero ac tellus pellentesque semper. Sed ac felis. Sed commodo, magna quis lacinia ornare, quam ante aliquam nisi, eu iaculis leo purus venenatis dui.</span><br>', 1),
(4, 'Civilly why how end viewing related', '<span style=\"color: rgb(70, 85, 65); font-family: &quot;Open Sans&quot;, sans-serif; font-size: 16px;\">Nam enim risus, molestie et, porta ac, aliquam ac, risus. Quisque lobortis. Phasellus pellentesque purus in massa. Aenean in pede. Phasellus ac libero ac tellus pellentesque semper. Sed ac felis. Sed commodo, magna quis lacinia ornare, quam ante aliquam nisi, eu iaculis leo purus venenatis dui.</span><br>', 0),
(5, 'Six started far placing saw respect', '<span style=\"color: rgb(70, 85, 65); font-family: \" open=\"\" sans\",=\"\" sans-serif;=\"\" font-size:=\"\" 16px;\"=\"\">Nam enim risus, molestie et, porta ac, aliquam ac, risus. Quisque lobortis. Phasellus pellentesque purus in massa. Aenean in pede. Phasellus ac libero ac tellus pellentesque semper. Sed ac felis. Sed commodo, magna quis lacinia ornare, quam ante aliquam nisi, eu iaculis leo purus venenatis dui.</span><br>', 0),
(6, 'She jointure goodness interest debat', '<div style=\"text-align: center;\"><div style=\"text-align: center;\"><br></div></div><div style=\"text-align: center;\"><br></div><div style=\"text-align: center;\"><span style=\"color: rgb(70, 85, 65); font-family: \" open=\"\" sans\",=\"\" sans-serif;=\"\" font-size:=\"\" 16px;\"=\"\">Nam enim risus, molestie et, porta ac, aliquam ac, risus. Quisque lobortis. Phasellus pellentesque purus in massa. Aenean in pede. Phasellus ac libero ac tellus pellentesque semper. Sed ac felis. Sed commodo, magna quis lacinia ornare, quam ante aliquam nisi, eu iaculis leo purus venenatis dui.<br></span></div>', 0),
(7, 'Test FAQ', 'Tsting FAQ&nbsp;', 0);

-- --------------------------------------------------------

--
-- Table structure for table `favorite_sellers`
--

CREATE TABLE `favorite_sellers` (
  `id` int(191) NOT NULL,
  `user_id` int(191) NOT NULL,
  `vendor_id` int(191) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `galleries`
--

CREATE TABLE `galleries` (
  `id` int(191) UNSIGNED NOT NULL,
  `product_id` int(191) UNSIGNED NOT NULL,
  `photo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `galleries`
--

INSERT INTO `galleries` (`id`, `product_id`, `photo`) VALUES
(1, 1, '15715597162.jpeg'),
(2, 1, '15715597163.jpeg'),
(3, 1, '15715597174.jpeg'),
(4, 1, '15715597175.jpeg'),
(5, 2, '15715624752 - Copy.jpeg'),
(6, 2, '15715624753 - Copy.jpeg'),
(7, 2, '15715624754 - Copy.jpeg'),
(8, 2, '15715624755 - Copy.jpeg'),
(9, 3, '15715627042.jpeg'),
(10, 3, '15715627043.jpeg'),
(11, 3, '15715627044.jpeg'),
(12, 3, '15715627045.jpeg'),
(13, 3, '15715627046.jpeg'),
(14, 3, '15715627047.jpeg'),
(15, 4, '15715629762.jpeg'),
(16, 4, '15715629763.jpeg'),
(17, 5, '15715638312.jpeg'),
(18, 5, '15715638313.jpeg'),
(19, 5, '15715638314.jpeg'),
(20, 5, '15715638315.jpeg'),
(21, 5, '15715638316.jpeg'),
(22, 6, '15715641082.jpeg'),
(23, 6, '15715641083.jpeg'),
(24, 6, '15715641084.jpeg'),
(25, 6, '15715641085.jpeg'),
(27, 9, '15715645552.jpeg'),
(28, 9, '15715645553.jpeg'),
(29, 9, '15715645554.jpeg'),
(30, 9, '15715645555.jpeg'),
(31, 8, '15715646562.jpeg'),
(32, 8, '15715646563.jpeg'),
(33, 8, '15715646564.jpeg'),
(34, 12, '15715650711.jpeg'),
(35, 12, '15715650713.jpeg'),
(36, 13, '15715659152.jpeg'),
(37, 13, '15715659153.jpeg'),
(38, 14, '15715661142.jpeg'),
(39, 14, '15715661143.jpeg'),
(40, 14, '15715661144.jpeg'),
(41, 14, '15715661145.jpeg'),
(42, 15, '15715663332.jpeg'),
(43, 15, '15715663333.jpeg'),
(44, 16, '15715843782.jpeg'),
(45, 16, '15715843783.jpeg'),
(46, 16, '15715843784.jpeg'),
(47, 16, '15715843785.jpeg'),
(48, 17, '1572100624111-visko-original-imafgzbhgfz7pcxj.jpeg'),
(49, 17, '1572100624demo2.jpg'),
(50, 20, '1599407651GUEST_3345b6d4-692e-4aea-ba22-07a9181a0833.jfif'),
(51, 20, '1599407651laett-children-s-table-with-2-chairs__0735856_PE740220_S5.webp'),
(52, 20, '1599407651ROYIND-royaloak-melbourne-coffee-table2.jpg'),
(53, 20, '1599407651TA-PKCLRT.jfif');

-- --------------------------------------------------------

--
-- Table structure for table `generalsettings`
--

CREATE TABLE `generalsettings` (
  `id` int(191) NOT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_email` text COLLATE utf8mb4_unicode_ci,
  `header_phone` text COLLATE utf8mb4_unicode_ci,
  `footer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `copyright` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `colors` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loader` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_loader` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_talkto` tinyint(1) NOT NULL DEFAULT '1',
  `talkto` text COLLATE utf8mb4_unicode_ci,
  `is_language` tinyint(1) NOT NULL DEFAULT '1',
  `is_loader` tinyint(1) NOT NULL DEFAULT '1',
  `map_key` text COLLATE utf8mb4_unicode_ci,
  `is_disqus` tinyint(1) NOT NULL DEFAULT '0',
  `disqus` longtext COLLATE utf8mb4_unicode_ci,
  `is_contact` tinyint(1) NOT NULL DEFAULT '0',
  `is_faq` tinyint(1) NOT NULL DEFAULT '0',
  `guest_checkout` tinyint(1) NOT NULL DEFAULT '0',
  `paypal_check` tinyint(1) DEFAULT '0',
  `stripe_check` tinyint(1) NOT NULL DEFAULT '0',
  `cod_check` tinyint(1) NOT NULL DEFAULT '0',
  `paypal_business` text COLLATE utf8mb4_unicode_ci,
  `stripe_key` text COLLATE utf8mb4_unicode_ci,
  `stripe_secret` text COLLATE utf8mb4_unicode_ci,
  `currency_format` tinyint(1) NOT NULL DEFAULT '0',
  `withdraw_fee` double NOT NULL DEFAULT '0',
  `withdraw_charge` double NOT NULL DEFAULT '0',
  `tax` double NOT NULL DEFAULT '0',
  `shipping_cost` double NOT NULL DEFAULT '0',
  `smtp_host` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `smtp_port` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `smtp_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `smtp_pass` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_smtp` tinyint(1) NOT NULL DEFAULT '0',
  `is_comment` tinyint(1) NOT NULL DEFAULT '1',
  `is_currency` tinyint(1) NOT NULL DEFAULT '1',
  `add_cart` text COLLATE utf8mb4_unicode_ci,
  `out_stock` text COLLATE utf8mb4_unicode_ci,
  `add_wish` text COLLATE utf8mb4_unicode_ci,
  `already_wish` text COLLATE utf8mb4_unicode_ci,
  `wish_remove` text COLLATE utf8mb4_unicode_ci,
  `add_compare` text COLLATE utf8mb4_unicode_ci,
  `already_compare` text COLLATE utf8mb4_unicode_ci,
  `compare_remove` text COLLATE utf8mb4_unicode_ci,
  `color_change` text COLLATE utf8mb4_unicode_ci,
  `coupon_found` text COLLATE utf8mb4_unicode_ci,
  `no_coupon` text COLLATE utf8mb4_unicode_ci,
  `already_coupon` text COLLATE utf8mb4_unicode_ci,
  `order_title` text COLLATE utf8mb4_unicode_ci,
  `order_text` text COLLATE utf8mb4_unicode_ci,
  `is_affilate` tinyint(1) NOT NULL DEFAULT '1',
  `affilate_charge` int(100) NOT NULL DEFAULT '0',
  `affilate_banner` text COLLATE utf8mb4_unicode_ci,
  `already_cart` text COLLATE utf8mb4_unicode_ci,
  `fixed_commission` double NOT NULL DEFAULT '0',
  `percentage_commission` double NOT NULL DEFAULT '0',
  `multiple_shipping` tinyint(1) NOT NULL DEFAULT '0',
  `vendor_ship_info` tinyint(1) NOT NULL DEFAULT '0',
  `reg_vendor` tinyint(1) NOT NULL DEFAULT '0',
  `cod_photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paypal_photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stripe_photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `generalsettings`
--

INSERT INTO `generalsettings` (`id`, `logo`, `favicon`, `title`, `header_email`, `header_phone`, `footer`, `copyright`, `colors`, `loader`, `admin_loader`, `is_talkto`, `talkto`, `is_language`, `is_loader`, `map_key`, `is_disqus`, `disqus`, `is_contact`, `is_faq`, `guest_checkout`, `paypal_check`, `stripe_check`, `cod_check`, `paypal_business`, `stripe_key`, `stripe_secret`, `currency_format`, `withdraw_fee`, `withdraw_charge`, `tax`, `shipping_cost`, `smtp_host`, `smtp_port`, `smtp_user`, `smtp_pass`, `from_email`, `from_name`, `is_smtp`, `is_comment`, `is_currency`, `add_cart`, `out_stock`, `add_wish`, `already_wish`, `wish_remove`, `add_compare`, `already_compare`, `compare_remove`, `color_change`, `coupon_found`, `no_coupon`, `already_coupon`, `order_title`, `order_text`, `is_affilate`, `affilate_charge`, `affilate_banner`, `already_cart`, `fixed_commission`, `percentage_commission`, `multiple_shipping`, `vendor_ship_info`, `reg_vendor`, `cod_photo`, `paypal_photo`, `stripe_photo`) VALUES
(1, '1566970180logo.jpg', '1566970770basketlogo (1).jpg', 'Basket', 'Info@example.com', '0123 456789', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae', 'COPYRIGHT © 2019. All Rights Reserved By <a href=\"http://basket.qa/\">basket.qa</a>', '#cf2336', '1558779995loader.gif', '1560575570spinner.gif', 0, NULL, 1, 1, 'AIzaSyB1GpE4qeoJ__70UZxvX9CTMUTZRZNHcu8', 0, NULL, 1, 1, 0, 0, 0, 0, 'shaon143-facilitator-1@gmail.com', 'pk_test_UnU1Coi1p5qFGwtpjZMRMgJM', 'sk_test_QQcg3vGsKRPlW6T3dXcNJsor', 1, 0, 0, 0, 0, 'smtp.gmail.com', '587', 'smtp.whyte@gmail.com', 'xhtrvevenmalpxds', 'mail@basket.qa', 'BASKET', 1, 1, 1, 'Successfully Added To Basket', 'Out Of Stock', 'Add To Wishlist', 'Already Added To Wishlist', 'Successfully Removed From The Wishlist', 'Successfully Added To Compare', 'Already Added To Compare', 'Successfully Removed From The Compare', 'Successfully Changed The Color', 'Coupon Found', 'No Coupon Found', 'Coupon Already Applied', 'THANK YOU FOR YOUR PURCHASE.', 'We\'ll email you an order confirmation with details and tracking info.', 1, 0, '15587771131554048228onepiece.jpeg', 'Already Added To Basket', 0, 0, 1, 1, 1, '1561633289cod.jpg', '1561633682pm2.jpg', '1561633682pm7.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(191) NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `language` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `is_default`, `language`, `file`) VALUES
(1, 1, 'English', '1562130732a7tOywFK.json'),
(4, 0, 'বাংলা', '1561615675Ng2IJXnV.json');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(191) NOT NULL,
  `conversation_id` int(191) NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_user` int(191) DEFAULT NULL,
  `recieved_user` int(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(191) NOT NULL,
  `order_id` int(191) UNSIGNED DEFAULT NULL,
  `user_id` int(191) DEFAULT NULL,
  `vendor_id` int(191) DEFAULT NULL,
  `product_id` int(191) DEFAULT NULL,
  `conversation_id` int(191) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `order_id`, `user_id`, `vendor_id`, `product_id`, `conversation_id`, `is_read`, `created_at`, `updated_at`) VALUES
(1, NULL, 31, NULL, NULL, NULL, 1, '2020-05-24 20:13:47', '2020-09-08 10:20:38'),
(2, NULL, 35, NULL, NULL, NULL, 1, '2020-09-03 12:55:41', '2020-09-08 10:20:38'),
(3, NULL, 35, NULL, NULL, NULL, 1, '2020-09-03 12:55:46', '2020-09-08 10:20:38'),
(4, NULL, 35, NULL, NULL, NULL, 1, '2020-09-03 13:20:26', '2020-09-08 10:20:38'),
(5, NULL, 37, NULL, NULL, NULL, 1, '2020-09-15 16:06:25', '2020-09-19 09:20:45'),
(6, NULL, 37, NULL, NULL, NULL, 1, '2020-09-15 17:19:54', '2020-09-19 09:20:45'),
(7, NULL, 46, NULL, NULL, NULL, 0, '2020-11-29 11:46:24', '2020-11-29 11:46:24'),
(8, NULL, 56, NULL, NULL, NULL, 0, '2021-01-24 13:16:34', '2021-01-24 13:16:34'),
(9, NULL, 56, NULL, NULL, NULL, 0, '2021-01-24 13:16:40', '2021-01-24 13:16:40'),
(10, NULL, 57, NULL, NULL, NULL, 0, '2021-02-15 09:51:19', '2021-02-15 09:51:19'),
(11, NULL, 57, NULL, NULL, NULL, 0, '2021-02-15 10:07:25', '2021-02-15 10:07:25');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(191) DEFAULT NULL,
  `cart` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pickup_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totalQty` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_amount` float DEFAULT NULL,
  `txnid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charge_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_number` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `customer_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_country` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_phone` varchar(255) DEFAULT NULL,
  `customer_address` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_city` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_building_no` varchar(250) DEFAULT NULL,
  `customer_zone_no` varchar(250) DEFAULT NULL,
  `customer_street_no` varchar(250) DEFAULT NULL,
  `customer_zip` varchar(255) DEFAULT NULL,
  `shipping_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `shipping_country` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `shipping_phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `shipping_address` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `shipping_city` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `shipping_building_no` varchar(250) DEFAULT NULL,
  `shipping_zone_no` varchar(250) DEFAULT NULL,
  `shipping_street_no` varchar(250) DEFAULT NULL,
  `shipping_zip` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `coupon_code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_discount` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','processing','completed','declined') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `affilate_user` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `affilate_charge` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_sign` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_value` double DEFAULT NULL,
  `shipping_cost` double DEFAULT NULL,
  `tax` int(191) DEFAULT NULL,
  `dp` tinyint(1) DEFAULT '0',
  `delivery_time` varchar(250) DEFAULT NULL,
  `disclaimer` text,
  `map_lat` varchar(250) DEFAULT NULL,
  `map_long` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `cart`, `method`, `shipping`, `pickup_location`, `totalQty`, `pay_amount`, `txnid`, `charge_id`, `order_number`, `payment_status`, `customer_email`, `customer_name`, `customer_country`, `customer_phone`, `customer_address`, `customer_city`, `customer_building_no`, `customer_zone_no`, `customer_street_no`, `customer_zip`, `shipping_name`, `shipping_country`, `shipping_email`, `shipping_phone`, `shipping_address`, `shipping_city`, `shipping_building_no`, `shipping_zone_no`, `shipping_street_no`, `shipping_zip`, `order_note`, `coupon_code`, `coupon_discount`, `status`, `created_at`, `updated_at`, `affilate_user`, `affilate_charge`, `currency_sign`, `currency_value`, `shipping_cost`, `tax`, `dp`, `delivery_time`, `disclaimer`, `map_lat`, `map_long`) VALUES
(1, 7, NULL, 'Payment by Card', 'shipto', NULL, '8', 3192, NULL, NULL, '0gp71608815531', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-24 13:12:11', '2020-12-24 13:12:11', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(2, 35, NULL, 'Payment by Card', 'Qpay', NULL, '2', 280, NULL, NULL, 'k0lp1608815563', 'Pending', 'unais.whyte@gmail.com', 'Unais Ellias', '0', '31404159', NULL, '0', '50', '435', '345', NULL, 'try', NULL, 'ajith@whyte.com', '12345678', 'Err retry', '9', '100', '20', '10', NULL, '0', '0', '0', 'pending', '2020-12-24 13:12:43', '2020-12-24 13:12:43', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, NULL, '55.490489897880394', '25.248437449336052'),
(3, 7, NULL, 'Payment by Card', 'shipto', NULL, '18', 12182, NULL, NULL, 'fIFk1608815630', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-24 13:13:50', '2020-12-24 13:13:50', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(4, 7, NULL, 'Payment by Card', 'shipto', NULL, '10', 8990, NULL, NULL, 'JTek1608815665', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-24 13:14:25', '2020-12-24 13:14:25', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(5, 7, NULL, 'Payment by Card', 'shipto', NULL, '7', 2793, NULL, NULL, 'zXWE1608815794', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-24 13:16:34', '2020-12-24 13:16:34', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(6, 7, NULL, 'Payment by Card', 'shipto', NULL, '10', 57380, NULL, NULL, '1lyf1608881937', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:38:57', '2020-12-25 07:38:57', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(7, 7, NULL, 'Payment by Card', 'shipto', NULL, '12', 826272, NULL, NULL, 'flTh1608881983', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:39:43', '2020-12-25 07:39:43', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(8, 7, NULL, 'Payment by Card', 'shipto', NULL, '12', 826272, NULL, NULL, '5ye61608882022', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:40:22', '2020-12-25 07:40:22', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(9, 7, NULL, 'Payment by Card', 'shipto', NULL, '12', 826272, NULL, NULL, 'Nerp1608882050', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:40:50', '2020-12-25 07:40:50', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(10, 7, NULL, 'Payment by Card', 'shipto', NULL, '5', 500, NULL, NULL, 'x5L51608882222', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:43:42', '2020-12-25 07:43:42', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(11, 7, NULL, 'Payment by Card', 'shipto', NULL, '67', 21373, NULL, NULL, '4gxo1608882385', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:46:25', '2020-12-25 07:46:25', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(12, 7, NULL, 'Payment by Card', 'shipto', NULL, '10', 21580, NULL, NULL, '4yik1608882441', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:47:21', '2020-12-25 07:47:21', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(13, 7, NULL, 'Payment by Card', 'shipto', NULL, '20', 78960, NULL, NULL, 'Akzw1608882502', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:48:22', '2020-12-25 07:48:22', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(14, 7, NULL, 'Payment by Card', 'shipto', NULL, '20', 78960, NULL, NULL, 'mlfR1608882520', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:48:40', '2020-12-25 07:48:40', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(15, 7, NULL, 'Payment by Card', 'shipto', NULL, '54', 16732000, NULL, NULL, 'Ow391608882650', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:50:50', '2020-12-25 07:50:50', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(16, 7, NULL, 'Payment by Card', 'shipto', NULL, '54', 16732000, NULL, NULL, 'ZS8f1608882681', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:51:21', '2020-12-25 07:51:21', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(17, 7, NULL, 'Payment by Card', 'shipto', NULL, '31', 66898, NULL, NULL, 'lLTv1608882759', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:52:39', '2020-12-25 07:52:39', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(18, 7, NULL, 'Payment by Card', 'shipto', NULL, '28', 9100, NULL, NULL, 'ztZT1608882843', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:54:03', '2020-12-25 07:54:03', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(19, 7, NULL, 'Payment by Card', 'shipto', NULL, '43', 38657, NULL, NULL, 'JHZ51608882909', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:55:09', '2020-12-25 07:55:09', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(20, 7, NULL, 'Payment by Card', 'shipto', NULL, '10', 4190, NULL, NULL, '5KOf1608883024', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:57:04', '2020-12-25 07:57:04', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(21, 7, NULL, 'Payment by Card', 'shipto', NULL, '24', 241344, NULL, NULL, 'o7Zu1608883065', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:57:45', '2020-12-25 07:57:45', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(22, 7, NULL, 'Payment by Card', 'shipto', NULL, '24', 241344, NULL, NULL, 'vBlr1608883076', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:57:56', '2020-12-25 07:57:56', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(23, 7, NULL, 'Payment by Card', 'shipto', NULL, '24', 241344, NULL, NULL, '12001608883106', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 07:58:26', '2020-12-25 07:58:26', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(24, 7, NULL, 'Payment by Card', 'shipto', NULL, '5', 500, NULL, NULL, 'Sl881608916520', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 17:15:20', '2020-12-25 17:15:20', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(25, 7, NULL, 'Payment by Card', 'shipto', NULL, '11', 142989, NULL, NULL, 'ga131608916606', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 17:16:46', '2020-12-25 17:16:46', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(26, 7, NULL, 'Payment by Card', 'shipto', NULL, '34', 237490, NULL, NULL, '8yWd1608916679', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 17:17:59', '2020-12-25 17:17:59', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(27, 7, NULL, 'Payment by Card', 'shipto', NULL, '34', 237490, NULL, NULL, 'SPAB1608916708', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 17:18:28', '2020-12-25 17:18:28', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(28, 7, NULL, 'Payment by Card', 'shipto', NULL, '21', 31332, NULL, NULL, 'p3yj1608916827', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-25 17:20:27', '2020-12-25 17:20:27', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(29, 35, NULL, 'Payment by Card', 'shipto', NULL, '2', 13099, NULL, NULL, 'hhbC1608937746', 'Pending', 'email@gmail.com', 'unais', '0', '1234', 'test', '8', '20', '270', '10', NULL, 'Unais', NULL, 'unaise@ee.com', 'contact.unais@gmail.com', 'Test Address', '1', '50', '20', '20', NULL, '0', '0', '0', 'pending', '2020-12-25 23:09:06', '2020-12-25 23:09:06', NULL, NULL, 'QAR', 0, 0, 0, 0, '12 AM - 10 PM', NULL, NULL, NULL),
(30, 35, NULL, 'Payment by Card', 'shipto', NULL, '82', 13099, NULL, NULL, '3wvn1608937821', 'Pending', 'email@gmail.com', 'unais', '0', '1234', 'test', '8', '20', '270', '10', NULL, 'try', NULL, 'ajith@whyte.com', '12345678', 'Err retry', '9', 'ertrt', 'ret', 'ret', NULL, '0', '0', '0', 'pending', '2020-12-25 23:10:21', '2020-12-25 23:10:21', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '55.490489897880394', '25.248437449336052'),
(31, 35, NULL, 'Payment by Card', 'shipto', NULL, '82', 13099, NULL, NULL, 'aGqT1608937822', 'Pending', 'email@gmail.com', 'unais', '0', '1234', 'test', '8', '20', '270', '10', NULL, 'try', NULL, 'ajith@whyte.com', '12345678', 'Err retry', '9', 'ertrt', 'ret', 'ret', NULL, '0', '0', '0', 'pending', '2020-12-25 23:10:22', '2020-12-25 23:10:22', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '55.490489897880394', '25.248437449336052'),
(32, 35, NULL, 'Payment by Card', 'shipto', NULL, '82', 13099, NULL, NULL, '8Sr11608937892', 'Pending', 'email@gmail.com', 'unais', '0', '1234', 'test', '8', '20', '270', '10', NULL, 'try', NULL, 'ajith@whyte.com', '12345678', 'Err retry', '9', 'ertrt', 'ret', 'ret', NULL, '0', '0', '0', 'pending', '2020-12-25 23:11:32', '2020-12-25 23:11:32', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '55.490489897880394', '25.248437449336052'),
(33, 35, NULL, 'Payment by Card', 'shipto', NULL, '2', 13099, NULL, NULL, 'RfMF1608976189', 'Pending', 'email@gmail.com', 'unais', '0', '1234', 'test', '8', '20', '270', '10', NULL, 'try', NULL, 'ajith@whyte.com', '12345678', 'Err retry', '8', 'ertrt', 'ret', 'ret', NULL, '0', '0', '0', 'pending', '2020-12-26 09:49:49', '2020-12-26 09:49:49', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '55.48085377945495', '25.23966059088707'),
(34, 35, NULL, 'Payment by Card', 'shipto', NULL, '2', 13099, NULL, NULL, 'Jza11608976654', 'Pending', 'email@gmail.com', 'unais', '0', '1234', 'test', '8', '20', '270', '10', NULL, 'try', NULL, 'ajith@whyte.com', '12345678', 'Err retry', '8', 'ertrt', 'ret', 'ret', NULL, '0', '0', '0', 'pending', '2020-12-26 09:57:34', '2020-12-26 09:57:34', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '55.48085377945495', '25.23966059088707'),
(35, 35, NULL, 'Payment by Card', 'shipto', NULL, '2', 13099, NULL, NULL, 'CiWt1608976771', 'Pending', 'email@gmail.com', 'unais', '0', '1234', 'test', '8', '20', '270', '10', NULL, 'try', NULL, 'ajith@whyte.com', '12345678', 'Err retry', '8', 'ertrt', 'ret', 'ret', NULL, '0', '0', '0', 'pending', '2020-12-26 09:59:31', '2020-12-26 09:59:31', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '55.48085377945495', '25.23966059088707'),
(36, 7, NULL, 'Payment by Card', 'shipto', NULL, '11', 63118, NULL, NULL, 'gEb11609006657', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-26 18:17:37', '2020-12-26 18:17:37', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(37, 7, NULL, 'Payment by Card', 'shipto', NULL, '18', 7542, NULL, NULL, 'zTJb1609006809', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-26 18:20:09', '2020-12-26 18:20:09', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(38, 7, NULL, 'Payment by Card', 'shipto', NULL, '18', 7542, NULL, NULL, 'IfMe1609007038', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-26 18:23:58', '2020-12-26 18:23:58', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(39, 7, NULL, 'Payment by Card', 'shipto', NULL, '23', 14927, NULL, NULL, 'sDVp1609045089', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-27 04:58:09', '2020-12-27 04:58:09', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(40, 7, NULL, 'Payment by Card', 'shipto', NULL, '43', 38657, NULL, NULL, 'ITUX1609047224', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-27 05:33:44', '2020-12-27 05:33:44', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(41, 7, NULL, 'Payment by Card', 'shipto', NULL, '105', 49135, NULL, NULL, 'V5xS1609065732', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-27 10:42:12', '2020-12-27 10:42:12', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(42, 35, NULL, 'Payment by Card', 'shipto', NULL, '5', 53950, NULL, NULL, 'UihA1609136681', 'Pending', 'email@gmail.com', 'unais', '0', '1234', 'test', '8', '20', '270', '10', NULL, 'try', NULL, 'ajith@whyte.com', '12345678', 'Err retry', '8', 'ertrt', 'ret', 'ret', NULL, '0', '0', '0', 'pending', '2020-12-28 06:24:41', '2020-12-28 06:24:41', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '55.48085377945495', '25.23966059088707'),
(43, 7, NULL, 'Cash On Delivery', 'shipto', NULL, '30', 377100, NULL, NULL, 'GL341609163016', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:43:36', '2020-12-28 13:43:36', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(44, 7, NULL, 'Cash On Delivery', 'shipto', NULL, '18', 7542, NULL, NULL, 'G0Bn1609163059', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:44:19', '2020-12-28 13:44:19', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(45, 7, NULL, 'Payment by Card', 'shipto', NULL, '18', 7542, NULL, NULL, 'JETO1609163083', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:44:43', '2020-12-28 13:44:43', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(46, 7, NULL, 'Payment by Card', 'shipto', NULL, '30', 377100, NULL, NULL, 'KxSe1609163127', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:45:27', '2020-12-28 13:45:27', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(47, 7, NULL, 'Payment by Card', 'shipto', NULL, '23', 14927, NULL, NULL, '4pva1609163194', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:46:34', '2020-12-28 13:46:34', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(48, 7, NULL, 'Payment by Card', 'shipto', NULL, '30', 584100, NULL, NULL, 'BvCS1609163231', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:47:11', '2020-12-28 13:47:11', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(49, 7, NULL, 'Payment by Card', 'shipto', NULL, '13', 70811, NULL, NULL, 'BPVW1609163309', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:48:29', '2020-12-28 13:48:29', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, NULL, '25.33033690869079', '51.516316160559654'),
(50, 7, NULL, 'Payment by Card', 'shipto', NULL, '11', 63118, NULL, NULL, 'H77d1609163362', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:49:22', '2020-12-28 13:49:22', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(51, 7, NULL, 'Payment by Card', 'shipto', NULL, '12', 826272, NULL, NULL, 'HtVW1609163391', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:49:51', '2020-12-28 13:49:51', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(52, 7, NULL, 'Payment by Card', 'shipto', NULL, '5', 2095, NULL, NULL, 'u1Oo1609163451', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:50:51', '2020-12-28 13:50:51', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(53, 7, NULL, 'Payment by Card', 'shipto', NULL, '10', 41900, NULL, NULL, '7twm1609163543', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:52:23', '2020-12-28 13:52:23', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(54, 7, NULL, 'Payment by Card', 'shipto', NULL, '15', 57083, NULL, NULL, 'oM1V1609163776', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:56:16', '2020-12-28 13:56:16', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(55, 7, NULL, 'Payment by Card', 'shipto', NULL, '20', 96488, NULL, NULL, 'qaKV1609163829', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-28 13:57:09', '2020-12-28 13:57:09', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(56, 7, NULL, 'Payment by Card', 'shipto', NULL, '21', 101675, NULL, NULL, 'WKmW1609317863', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2020-12-30 08:44:23', '2020-12-30 08:44:23', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(57, 21, NULL, 'Payment by Card', 'shipto', NULL, '2', 5838, NULL, NULL, 'UbyZ1610968993', 'Pending', NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'gdfgdf', NULL, 'ajith@ewhyte.com', '12345678', 'Test', '8', '32', '12', '12', NULL, '0', '0', '0', 'pending', '2021-01-18 11:23:13', '2021-01-18 11:23:13', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '51.17889991879489', '-1.8263999372720716'),
(58, 21, NULL, 'Cash On Delivery', 'shipto', NULL, '2', 5838, NULL, NULL, 'kMUu1610969007', 'Pending', NULL, NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'gdfgdf', NULL, 'ajith@ewhyte.com', '12345678', 'Test', '8', '32', '12', '12', NULL, '0', '0', '0', 'pending', '2021-01-18 11:23:27', '2021-01-18 11:23:27', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '51.17889991879489', '-1.8263999372720716'),
(59, 7, NULL, 'Payment by Card', 'shipto', NULL, '38', 2797170, NULL, NULL, '68iU1610999762', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2021-01-18 19:56:02', '2021-01-18 19:56:02', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(60, 7, NULL, 'Payment by Card', 'shipto', NULL, '2', 400, NULL, NULL, '5lIJ1610999806', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2021-01-18 19:56:46', '2021-01-18 19:56:46', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(61, 7, NULL, 'Payment by Card', 'shipto', NULL, '24', 241344, NULL, NULL, 'j7sB1610999934', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2021-01-18 19:58:54', '2021-01-18 19:58:54', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(62, 7, NULL, 'Payment by Card', 'shipto', NULL, '20', 2295200, NULL, NULL, 'oSgn1611031555', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2021-01-19 04:45:55', '2021-01-19 04:45:55', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(63, 7, NULL, 'Payment by Card', 'shipto', NULL, '18', 7542, NULL, NULL, '9zKL1611031797', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2021-01-19 04:49:57', '2021-01-19 04:49:57', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(64, 7, NULL, 'Payment by Card', 'shipto', NULL, '18', 7542, NULL, NULL, 'g2CR1611031823', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2021-01-19 04:50:23', '2021-01-19 04:50:23', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(65, 7, NULL, 'Payment by Card', 'shipto', NULL, '19', 151259, NULL, NULL, 'APKs1611031854', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2021-01-19 04:50:54', '2021-01-19 04:50:54', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(66, 7, NULL, 'Payment by Card', 'shipto', NULL, '25', 62500, NULL, NULL, 'hYeY1611050717', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2021-01-19 10:05:17', '2021-01-19 10:05:17', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(67, 7, NULL, 'Payment by Card', 'shipto', NULL, '1', 100, NULL, NULL, 'eDcf1611050798', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2021-01-19 10:06:38', '2021-01-19 10:06:38', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(68, 56, NULL, 'Payment by Card', 'Qpay', NULL, '1', 649, NULL, NULL, 'EBGD1611495717', 'Pending', 'unais.whyte@gmail.com', 'Unais Ellias', '0', '31404156', NULL, '8', '500', '600', '700', NULL, 'unais', NULL, 'contact.unais@gmail.com', '09207406780', 'EKM', '8', '500', '500', '5000', NULL, '0', '0', '0', 'pending', '2021-01-24 13:41:57', '2021-01-24 13:41:57', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, NULL, '25.288861974966373', '51.54408606464843'),
(69, 7, NULL, 'Payment by Card', 'shipto', NULL, '16', 25600, NULL, NULL, 'nDWd1612333445', 'Pending', 'mgalsulaiti8@gmail.com', 'Mohammed Alsulaiti', '0', '66655997', 'aldafna', '0', '55', '99', '55', NULL, 'gogo', NULL, 'mgalsulaiti8@gmail.com', '66655997', 'Aldafna', '8', '55', '55', '55', NULL, '0', '0', '0', 'pending', '2021-02-03 06:24:05', '2021-02-03 06:24:05', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, 'Delivery will take 3 to 5 working days', '25.33033690869079', '51.516316160559654'),
(70, 57, NULL, 'Payment by Card', 'Qpay', NULL, '1', 12999, NULL, NULL, 'QB5W1613382781', 'Pending', 'info@papayaqatar.com', 'SHAMEER NADUVILAKKANDIYIL', '0', '08113844811', 'NADUVILAKKANDIYIL VADAKARA', '9', '737', '73637', '7362772', NULL, 'Jshbs', NULL, 'demo@demo.com', '76767578', 'Shsbbbs', '8', '7363', '7363', '7363', NULL, '0', '0', '0', 'pending', '2021-02-15 09:53:00', '2021-02-15 09:53:00', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, NULL, '25.279238553768735', '51.528293217968745'),
(71, 57, NULL, 'Payment by Card', 'Qpay', NULL, '1', 6985, NULL, NULL, '7dQw1613382888', 'Pending', 'info@papayaqatar.com', 'SHAMEER NADUVILAKKANDIYIL', '0', '08113844811', 'NADUVILAKKANDIYIL VADAKARA', '9', '737', '73637', '7362772', NULL, 'Jshbs', NULL, 'demo@demo.com', '76767578', 'Shsbbbs', '8', '7363', '7363', '7363', NULL, '0', '0', '0', 'pending', '2021-02-15 09:54:48', '2021-02-15 09:54:48', NULL, NULL, 'QAR', 0, 0, 0, 0, NULL, NULL, '25.279238553768735', '51.528293217968745');

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `id` int(11) NOT NULL,
  `order_number` varchar(250) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` varchar(250) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`id`, `order_number`, `product_id`, `qty`, `price`, `updated_at`, `created_at`) VALUES
(1, '0gp71608815531', 14, 8, '399', '2020-12-24 13:12:11', '2020-12-24 13:12:11'),
(2, '5WIs1608815563', 20, 2, '100', '2020-12-24 13:12:43', '2020-12-24 13:12:43'),
(3, 'fIFk1608815630', 14, 8, '399', '2020-12-24 13:13:50', '2020-12-24 13:13:50'),
(4, 'fIFk1608815630', 6, 10, '899', '2020-12-24 13:13:50', '2020-12-24 13:13:50'),
(5, 'JTek1608815665', 6, 10, '899', '2020-12-24 13:14:25', '2020-12-24 13:14:25'),
(6, 'zXWE1608815794', 14, 7, '399', '2020-12-24 13:16:34', '2020-12-24 13:16:34'),
(7, '1lyf1608881937', 15, 10, '5738', '2020-12-25 07:38:57', '2020-12-25 07:38:57'),
(8, 'flTh1608881983', 15, 12, '68856', '2020-12-25 07:39:43', '2020-12-25 07:39:43'),
(9, '5ye61608882022', 15, 12, '68856', '2020-12-25 07:40:22', '2020-12-25 07:40:22'),
(10, 'Nerp1608882050', 15, 12, '68856', '2020-12-25 07:40:50', '2020-12-25 07:40:50'),
(11, 'x5L51608882222', 20, 5, '100', '2020-12-25 07:43:42', '2020-12-25 07:43:42'),
(12, '4gxo1608882385', 12, 67, '319', '2020-12-25 07:46:25', '2020-12-25 07:46:25'),
(13, '4yik1608882441', 11, 10, '2158', '2020-12-25 07:47:21', '2020-12-25 07:47:21'),
(14, 'Akzw1608882502', 11, 10, '2158', '2020-12-25 07:48:22', '2020-12-25 07:48:22'),
(15, 'Akzw1608882502', 15, 10, '5738', '2020-12-25 07:48:22', '2020-12-25 07:48:22'),
(16, 'mlfR1608882520', 11, 10, '2158', '2020-12-25 07:48:40', '2020-12-25 07:48:40'),
(17, 'mlfR1608882520', 15, 10, '5738', '2020-12-25 07:48:40', '2020-12-25 07:48:40'),
(18, 'Ow391608882650', 15, 54, '309852', '2020-12-25 07:50:50', '2020-12-25 07:50:50'),
(19, 'ZS8f1608882681', 15, 54, '309852', '2020-12-25 07:51:21', '2020-12-25 07:51:21'),
(20, 'lLTv1608882759', 11, 31, '2158', '2020-12-25 07:52:39', '2020-12-25 07:52:39'),
(21, 'ztZT1608882843', 4, 28, '325', '2020-12-25 07:54:03', '2020-12-25 07:54:03'),
(22, 'JHZ51608882909', 6, 43, '899', '2020-12-25 07:55:09', '2020-12-25 07:55:09'),
(23, '5KOf1608883024', 8, 10, '419', '2020-12-25 07:57:04', '2020-12-25 07:57:04'),
(24, 'o7Zu1608883065', 8, 24, '10056', '2020-12-25 07:57:45', '2020-12-25 07:57:45'),
(25, 'vBlr1608883076', 8, 24, '10056', '2020-12-25 07:57:56', '2020-12-25 07:57:56'),
(26, '12001608883106', 8, 24, '10056', '2020-12-25 07:58:26', '2020-12-25 07:58:26'),
(27, 'Sl881608916520', 20, 5, '100', '2020-12-25 17:15:20', '2020-12-25 17:15:20'),
(28, 'ga131608916606', 3, 11, '12999', '2020-12-25 17:16:46', '2020-12-25 17:16:46'),
(29, '8yWd1608916679', 1, 34, '6985', '2020-12-25 17:17:59', '2020-12-25 17:17:59'),
(30, 'SPAB1608916708', 1, 34, '6985', '2020-12-25 17:18:28', '2020-12-25 17:18:28'),
(31, 'p3yj1608916827', 10, 21, '1492', '2020-12-25 17:20:27', '2020-12-25 17:20:27'),
(32, 'dfbj1608937715', 20, 1, '100', '2020-12-25 23:08:35', '2020-12-25 23:08:35'),
(33, 'dfbj1608937715', 3, 1, '12999', '2020-12-25 23:08:35', '2020-12-25 23:08:35'),
(34, 'hhbC1608937746', 20, 1, '100', '2020-12-25 23:09:06', '2020-12-25 23:09:06'),
(35, 'hhbC1608937746', 3, 1, '12999', '2020-12-25 23:09:06', '2020-12-25 23:09:06'),
(36, '3wvn1608937821', 20, 1, '100', '2020-12-25 23:10:21', '2020-12-25 23:10:21'),
(37, '3wvn1608937821', 3, 1, '12999', '2020-12-25 23:10:21', '2020-12-25 23:10:21'),
(38, 'aGqT1608937822', 20, 1, '100', '2020-12-25 23:10:22', '2020-12-25 23:10:22'),
(39, 'aGqT1608937822', 3, 1, '12999', '2020-12-25 23:10:22', '2020-12-25 23:10:22'),
(40, '8Sr11608937892', 20, 1, '100', '2020-12-25 23:11:32', '2020-12-25 23:11:32'),
(41, '8Sr11608937892', 3, 1, '12999', '2020-12-25 23:11:32', '2020-12-25 23:11:32'),
(42, 'RfMF1608976189', 20, 1, '100', '2020-12-26 09:49:49', '2020-12-26 09:49:49'),
(43, 'RfMF1608976189', 3, 1, '12999', '2020-12-26 09:49:49', '2020-12-26 09:49:49'),
(44, 'Jza11608976654', 20, 1, '100', '2020-12-26 09:57:34', '2020-12-26 09:57:34'),
(45, 'Jza11608976654', 3, 1, '12999', '2020-12-26 09:57:34', '2020-12-26 09:57:34'),
(46, 'CiWt1608976771', 20, 1, '100', '2020-12-26 09:59:31', '2020-12-26 09:59:31'),
(47, 'CiWt1608976771', 3, 1, '12999', '2020-12-26 09:59:31', '2020-12-26 09:59:31'),
(48, 'gEb11609006657', 15, 11, '5738', '2020-12-26 18:17:37', '2020-12-26 18:17:37'),
(49, 'zTJb1609006809', 8, 18, '419', '2020-12-26 18:20:09', '2020-12-26 18:20:09'),
(50, 'IfMe1609007038', 8, 18, '419', '2020-12-26 18:23:58', '2020-12-26 18:23:58'),
(51, 'sDVp1609045089', 9, 23, '649', '2020-12-27 04:58:09', '2020-12-27 04:58:09'),
(52, 'ITUX1609047224', 6, 43, '899', '2020-12-27 05:33:44', '2020-12-27 05:33:44'),
(53, 'V5xS1609065732', 6, 1, '899', '2020-12-27 10:42:12', '2020-12-27 10:42:12'),
(54, 'V5xS1609065732', 8, 18, '419', '2020-12-27 10:42:12', '2020-12-27 10:42:12'),
(55, 'V5xS1609065732', 9, 23, '649', '2020-12-27 10:42:12', '2020-12-27 10:42:12'),
(56, 'V5xS1609065732', 5, 63, '409', '2020-12-27 10:42:12', '2020-12-27 10:42:12'),
(57, 'UihA1609136681', 11, 5, '10790', '2020-12-28 06:24:41', '2020-12-28 06:24:41'),
(58, 'GL341609163016', 8, 30, '12570', '2020-12-28 13:43:36', '2020-12-28 13:43:36'),
(59, 'G0Bn1609163059', 8, 18, '419', '2020-12-28 13:44:19', '2020-12-28 13:44:19'),
(60, 'JETO1609163083', 8, 18, '419', '2020-12-28 13:44:43', '2020-12-28 13:44:43'),
(61, 'KxSe1609163127', 8, 30, '12570', '2020-12-28 13:45:27', '2020-12-28 13:45:27'),
(62, '4pva1609163194', 9, 23, '649', '2020-12-28 13:46:34', '2020-12-28 13:46:34'),
(63, 'BvCS1609163231', 9, 30, '19470', '2020-12-28 13:47:11', '2020-12-28 13:47:11'),
(64, 'BPVW1609163309', 8, 13, '5447', '2020-12-28 13:48:29', '2020-12-28 13:48:29'),
(65, 'H77d1609163362', 15, 11, '5738', '2020-12-28 13:49:22', '2020-12-28 13:49:22'),
(66, 'HtVW1609163391', 15, 12, '68856', '2020-12-28 13:49:51', '2020-12-28 13:49:51'),
(67, 'u1Oo1609163451', 8, 5, '419', '2020-12-28 13:50:51', '2020-12-28 13:50:51'),
(68, '7twm1609163543', 8, 10, '4190', '2020-12-28 13:52:23', '2020-12-28 13:52:23'),
(69, 'oM1V1609163776', 8, 11, '4609', '2020-12-28 13:56:16', '2020-12-28 13:56:16'),
(70, 'oM1V1609163776', 14, 4, '1596', '2020-12-28 13:56:16', '2020-12-28 13:56:16'),
(71, 'qaKV1609163829', 8, 14, '5866', '2020-12-28 13:57:09', '2020-12-28 13:57:09'),
(72, 'qaKV1609163829', 14, 6, '2394', '2020-12-28 13:57:09', '2020-12-28 13:57:09'),
(73, 'WKmW1609317863', 8, 14, '5866', '2020-12-30 08:44:23', '2020-12-30 08:44:23'),
(74, 'WKmW1609317863', 14, 7, '2793', '2020-12-30 08:44:23', '2020-12-30 08:44:23'),
(75, 'UbyZ1610968993', 20, 1, '100', '2021-01-18 11:23:13', '2021-01-18 11:23:13'),
(76, 'UbyZ1610968993', 15, 1, '5738', '2021-01-18 11:23:13', '2021-01-18 11:23:13'),
(77, 'kMUu1610969007', 20, 1, '100', '2021-01-18 11:23:27', '2021-01-18 11:23:27'),
(78, 'kMUu1610969007', 15, 1, '5738', '2021-01-18 11:23:27', '2021-01-18 11:23:27'),
(79, '68iU1610999762', 20, 2, '200', '2021-01-18 19:56:02', '2021-01-18 19:56:02'),
(80, '68iU1610999762', 11, 36, '77688', '2021-01-18 19:56:02', '2021-01-18 19:56:02'),
(81, '5lIJ1610999806', 20, 2, '200', '2021-01-18 19:56:46', '2021-01-18 19:56:46'),
(82, 'j7sB1610999934', 8, 24, '10056', '2021-01-18 19:58:54', '2021-01-18 19:58:54'),
(83, 'oSgn1611031555', 15, 20, '114760', '2021-01-19 04:45:55', '2021-01-19 04:45:55'),
(84, '9zKL1611031797', 8, 18, '419', '2021-01-19 04:49:57', '2021-01-19 04:49:57'),
(85, 'g2CR1611031823', 8, 18, '419', '2021-01-19 04:50:23', '2021-01-19 04:50:23'),
(86, 'APKs1611031854', 8, 19, '7961', '2021-01-19 04:50:54', '2021-01-19 04:50:54'),
(87, 'hYeY1611050717', 20, 25, '2500', '2021-01-19 10:05:17', '2021-01-19 10:05:17'),
(88, 'eDcf1611050798', 20, 1, '100', '2021-01-19 10:06:38', '2021-01-19 10:06:38'),
(89, 'gJbZ1611495717', 9, 1, '649', '2021-01-24 13:41:57', '2021-01-24 13:41:57'),
(90, 'nDWd1612333445', 20, 16, '1600', '2021-02-03 06:24:05', '2021-02-03 06:24:05'),
(91, '8twC1613382780', 3, 1, '12999', '2021-02-15 09:53:00', '2021-02-15 09:53:00'),
(92, 'NN3a1613382888', 1, 1, '6985', '2021-02-15 09:54:48', '2021-02-15 09:54:48');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(191) NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details_ar` text CHARACTER SET utf8,
  `meta_tag` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `header` tinyint(1) NOT NULL DEFAULT '0',
  `footer` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `slug`, `details`, `details_ar`, `meta_tag`, `meta_description`, `header`, `footer`) VALUES
(1, 'About Us', 'about', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br>', 'أبجد هوز هو مجرد دمية النص لصناعة الطباعة والتنضيد. كان Lorem Ipsum هو النص الوهمي القياسي في هذه الصناعة منذ القرن الخامس عشر الميلادي ، عندما أخذت طابعة غير معروفة لوحًا من نوعه وتدافعت عليه لصنع كتاب نموذج للعينات. لقد نجا ليس فقط خمسة قرون ، ولكن أيضا قفزة في التنضيد الإلكتروني ، تبقى دون تغيير أساسي. تم الترويج لها في الستينيات من القرن الماضي من خلال إصدار أوراق Letraset التي تحتوي على مقاطع Lorem Ipsum ، ومؤخراً مع برنامج النشر المكتبي مثل Aldus PageMaker بما في ذلك إصدارات Lorem Ipsum.', NULL, NULL, 1, 1),
(2, 'Privacy & Policy', 'privacy', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br>', 'أبجد هوز هو مجرد دمية النص لصناعة الطباعة والتنضيد. كان Lorem Ipsum هو النص الوهمي القياسي في هذه الصناعة منذ القرن الخامس عشر الميلادي ، عندما أخذت طابعة غير معروفة لوحًا من نوعه وتدافعت عليه لصنع كتاب نموذج للعينات. لقد نجا ليس فقط خمسة قرون ، ولكن أيضا قفزة في التنضيد الإلكتروني ، تبقى دون تغيير أساسي. تم الترويج لها في الستينيات من القرن الماضي من خلال إصدار أوراق Letraset التي تحتوي على مقاطع Lorem Ipsum ، ومؤخراً مع برنامج النشر المكتبي مثل Aldus PageMaker بما في ذلك إصدارات Lorem Ipsum.', 'test,test1,test2,test3', 'Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.', 1, 1),
(3, 'Terms & Condition', 'terms', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br>', 'أبجد هوز هو مجرد دمية النص لصناعة الطباعة والتنضيد. كان Lorem Ipsum هو النص الوهمي القياسي في هذه الصناعة منذ القرن الخامس عشر الميلادي ، عندما أخذت طابعة غير معروفة لوحًا من نوعه وتدافعت عليه لصنع كتاب نموذج للعينات. لقد نجا ليس فقط خمسة قرون ، ولكن أيضا قفزة في التنضيد الإلكتروني ، تبقى دون تغيير أساسي. تم الترويج لها في الستينيات من القرن الماضي من خلال إصدار أوراق Letraset التي تحتوي على مقاطع Lorem Ipsum ، ومؤخراً مع برنامج النشر المكتبي مثل Aldus PageMaker بما في ذلك إصدارات Lorem Ipsum.', 't1,t2,t3,t4', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.', 1, 1),
(4, 'Disclaimer', 'Disclaimer', 'Delivery will take 3 to 5 working days', 'سيستغرق التوصيل من 3 إلى 5 أيام عمل', NULL, NULL, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pagesettings`
--

CREATE TABLE `pagesettings` (
  `id` int(10) UNSIGNED NOT NULL,
  `contact_success` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_title` text COLLATE utf8mb4_unicode_ci,
  `contact_text` text COLLATE utf8mb4_unicode_ci,
  `side_title` text COLLATE utf8mb4_unicode_ci,
  `side_text` text COLLATE utf8mb4_unicode_ci,
  `street` text COLLATE utf8mb4_unicode_ci,
  `phone` text COLLATE utf8mb4_unicode_ci,
  `fax` text COLLATE utf8mb4_unicode_ci,
  `email` text COLLATE utf8mb4_unicode_ci,
  `site` text COLLATE utf8mb4_unicode_ci,
  `slider` tinyint(1) NOT NULL DEFAULT '1',
  `service` tinyint(1) NOT NULL DEFAULT '1',
  `featured` tinyint(1) NOT NULL DEFAULT '1',
  `small_banner` tinyint(1) NOT NULL DEFAULT '1',
  `best` tinyint(1) NOT NULL DEFAULT '1',
  `top_rated` tinyint(1) NOT NULL DEFAULT '1',
  `large_banner` tinyint(1) NOT NULL DEFAULT '1',
  `big` tinyint(1) NOT NULL DEFAULT '1',
  `hot_sale` tinyint(1) NOT NULL DEFAULT '1',
  `review_blog` tinyint(1) NOT NULL DEFAULT '1',
  `best_seller_banner` text COLLATE utf8mb4_unicode_ci,
  `best_seller_banner_link` text COLLATE utf8mb4_unicode_ci,
  `big_save_banner` text COLLATE utf8mb4_unicode_ci,
  `big_save_banner_link` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pagesettings`
--

INSERT INTO `pagesettings` (`id`, `contact_success`, `contact_email`, `contact_title`, `contact_text`, `side_title`, `side_text`, `street`, `phone`, `fax`, `email`, `site`, `slider`, `service`, `featured`, `small_banner`, `best`, `top_rated`, `large_banner`, `big`, `hot_sale`, `review_blog`, `best_seller_banner`, `best_seller_banner_link`, `big_save_banner`, `big_save_banner_link`) VALUES
(1, 'Success! Thanks for contacting us, we will get back to you shortly.', 'admin@basket.qa', '<h4 class=\"subtitle\" style=\"margin-bottom: 6px; font-weight: 600; line-height: 28px; font-size: 28px; text-transform: uppercase;\">WE\'D LOVE TO</h4><h2 class=\"title\" style=\"margin-bottom: 13px; font-weight: 600; line-height: 50px; font-size: 40px; color: rgb(255, 85, 0); text-transform: uppercase;\">HEAR FROM YOU</h2>', '<span style=\"color: rgb(119, 119, 119);\">Send us a message and we\' ll respond as soon as possible</span><br>', '<h4 class=\"title\" style=\"margin-bottom: 10px; font-weight: 600; line-height: 28px; font-size: 28px;\">Let\'s Connect</h4>', '<span style=\"color: rgb(51, 51, 51);\">Get in touch with us</span>', '3584 Hickory Heights Drive ,Hanover MD 21076, USA', '00 000 000 000', '00 000 000 000', 'admin@basket.qa', 'https://basket.qa/', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '1558815608electronic2.jpg', 'www.google.com', '1558815592accessories.jpg', 'www.google.com');

-- --------------------------------------------------------

--
-- Table structure for table `payment_gateways`
--

CREATE TABLE `payment_gateways` (
  `id` int(191) NOT NULL,
  `photo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` tinyint(10) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_gateways`
--

INSERT INTO `payment_gateways` (`id`, `photo`, `title`, `details`, `status`) VALUES
(2, '1558607469mlogo.png', 'Rocket', '<b>Rocket Mobile No: 01728068515<br>Rocket Reference No: 6622</b>', 0),
(3, '15586074081234.jpg', 'bKash', '<div style=\"text-align: left;\"><b>Mobile Number: 01732716885</b></div><b><div style=\"text-align: left;\"><b>Reference Number: 778899</b></div></b>', 0),
(4, NULL, 'QuickCash', '<b>MOBILE NUMBER: 9038423432849</b>', 0),
(5, NULL, 'Easy Cash', '<b>Please Call at 98989898989</b>', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pickups`
--

CREATE TABLE `pickups` (
  `id` int(191) UNSIGNED NOT NULL,
  `location` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_charge` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pickups`
--

INSERT INTO `pickups` (`id`, `location`, `shipping_charge`) VALUES
(8, 'Doha', '0'),
(9, 'wakra', '80');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(191) UNSIGNED NOT NULL,
  `user_id` int(191) NOT NULL DEFAULT '0',
  `shop_id` int(11) DEFAULT NULL,
  `category_id` int(191) UNSIGNED NOT NULL,
  `subcategory_id` int(191) UNSIGNED DEFAULT NULL,
  `childcategory_id` int(191) UNSIGNED DEFAULT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `photo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size_qty` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size_price` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price` double NOT NULL,
  `basket_commission_amount` varchar(250) DEFAULT NULL,
  `previous_price` double DEFAULT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sub_details` text CHARACTER SET utf8,
  `stock` int(191) DEFAULT NULL,
  `policy` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` tinyint(2) UNSIGNED NOT NULL DEFAULT '1',
  `views` int(191) UNSIGNED NOT NULL DEFAULT '0',
  `tags` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `features` text,
  `colors` text,
  `product_condition` tinyint(1) NOT NULL DEFAULT '0',
  `ship` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_meta` tinyint(1) NOT NULL DEFAULT '0',
  `meta_tag` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `youtube` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('Physical','Digital','License') NOT NULL,
  `license` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `license_qty` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `platform` varchar(255) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `licence_type` varchar(255) DEFAULT NULL,
  `measure` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `featured` tinyint(2) UNSIGNED NOT NULL DEFAULT '0',
  `best` tinyint(10) UNSIGNED NOT NULL DEFAULT '0',
  `top` tinyint(10) UNSIGNED NOT NULL DEFAULT '0',
  `hot` tinyint(10) UNSIGNED NOT NULL DEFAULT '0',
  `latest` tinyint(10) UNSIGNED NOT NULL DEFAULT '0',
  `big` tinyint(10) UNSIGNED NOT NULL DEFAULT '0',
  `trending` tinyint(1) NOT NULL DEFAULT '0',
  `sale` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_discount` tinyint(1) NOT NULL DEFAULT '0',
  `discount` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `discount_date` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `user_id`, `shop_id`, `category_id`, `subcategory_id`, `childcategory_id`, `name`, `slug`, `photo`, `file`, `size`, `size_qty`, `size_price`, `color`, `price`, `basket_commission_amount`, `previous_price`, `details`, `sub_details`, `stock`, `policy`, `status`, `views`, `tags`, `features`, `colors`, `product_condition`, `ship`, `is_meta`, `meta_tag`, `meta_description`, `youtube`, `type`, `license`, `license_qty`, `link`, `platform`, `region`, `licence_type`, `measure`, `featured`, `best`, `top`, `hot`, `latest`, `big`, `trending`, `sale`, `created_at`, `updated_at`, `is_discount`, `discount`, `discount_date`, `store_id`) VALUES
(1, 0, NULL, 51, 52, NULL, 'Cello Novelty Large Plastic Cupboard', 'cello-novelty-large-plastic-cupboard-cyo1anp', '15715597161.jpeg', NULL, NULL, NULL, NULL, NULL, 6985, '6000', 10000, '<span style=\"color: rgb(51, 51, 51); font-family: &quot;Source Sans Pro&quot;, Helvetica, Helvetica, Arial, sans-serif; font-size: 17.44px;\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" style=\"background-color: rgb(255, 255, 255); color: rgb(234, 75, 60); line-height: inherit; transition: all 0.1s ease 0s; font-family: &quot;Source Sans Pro&quot;, Helvetica, Helvetica, Arial, sans-serif; font-size: 17.44px;\">Unique furniture</a><span style=\"color: rgb(51, 51, 51); font-family: &quot;Source Sans Pro&quot;, Helvetica, Helvetica, Arial, sans-serif; font-size: 17.44px;\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 36, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; color: rgb(0, 153, 229); outline-style: initial; outline-width: 0px; transition: color 0.1s linear 0s; touch-action: manipulation; background-color: rgb(255, 255, 255);\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span><br style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"></div>', 1, 148, '1 Year Warranty Against Manufacturing Defects', 'Type,Modern,Suitable For,W x H x D,DIY', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, 0, 0, '2019-10-20 15:21:56', '2021-02-23 04:49:24', 0, NULL, NULL, NULL),
(2, 0, NULL, 51, 53, NULL, 'Spacewood Apex Engineered Wood 3 Door Wardrobe', 'spacewood-apex-engineered-wood-3-door-wardrobe-6ka2d0m', '15715624751.jpeg', NULL, NULL, NULL, NULL, NULL, 19690, '15000', 20000, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<div><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\"><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\"><ul style=\"color: rgb(70, 85, 65); font-family: \" open=\"\" sans\",=\"\" sans-serif;=\"\" font-size:=\"\" 16px;\"=\"\"><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul></span></div></span></div></div>', 0, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 259, NULL, 'Type,Modern,Suitable For,W x H x D,DIY', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, 0, 0, 0, '2019-10-20 16:07:55', '2021-02-23 05:00:19', 0, NULL, NULL, NULL),
(3, 0, NULL, 51, 53, NULL, 'Forzza Chelsea Engineered Wood Queen Bed', 'forzza-chelsea-engineered-wood-queen-bed-ewj3uya', '15715627041.jpeg', NULL, NULL, NULL, NULL, NULL, 12999, '11000', 13999, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 24, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 165, NULL, 'Type,Modern,Suitable For,W x H x D,DIY', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, 0, 0, 0, '2019-10-20 16:11:44', '2021-02-23 04:54:11', 0, NULL, NULL, NULL),
(4, 0, NULL, 67, 68, NULL, 'SOFTSPUN Microfiber 350 GSM Bath Towel', 'softspun-microfiber-350-gsm-bath-towel-dkv4gsn', '15715629761.jpeg', NULL, NULL, NULL, NULL, NULL, 325, '300', 400, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 29, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 32, NULL, 'Towel Type,Size,count,GSM', 'Bath,15.7 inch x 15.7 inch,4 Towels,350', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, '2019-10-20 16:16:16', '2021-01-19 00:29:56', 0, NULL, NULL, NULL),
(5, 0, NULL, 67, 68, NULL, 'Basket SmartBuy 480 GSM Cotton Bath Towel', 'basket-smartbuy-480-gsm-cotton-bath-towel-gll56fs', '15715638311.jpeg', NULL, NULL, NULL, NULL, NULL, 409, '400', 500, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 64, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 138, NULL, 'Type,Modern,W x H x D,DIY', 'Cupboard,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, 0, 0, 0, '2019-10-20 16:30:31', '2021-02-23 04:55:24', 0, NULL, NULL, NULL),
(6, 0, NULL, 67, 69, NULL, 'Impulse Tumbler Holder/Bathroom Accessories (15 x 6 Inches) Stainless Steel Wall Shelf', 'impulse-tumbler-holderbathroom-accessories-15-x-6-inches-stainless-steel-wall-shelf-yyy6szs', '15715641081.jpeg', NULL, NULL, NULL, NULL, NULL, 899, '800', 1000, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 44, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 142, NULL, 'Type,Modern,Suitable For,W x H x D,DIY', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, 0, 0, '2019-10-20 16:35:08', '2021-02-23 05:17:16', 0, NULL, NULL, NULL),
(7, 0, NULL, 67, 69, NULL, 'Basic assembly to be done with simple tools by the customer  comes with instructions.', 'basic-assembly-to-be-done-with-simple-tools-by-the-customer-comes-with-instructions-4di7gup', '15715642427.jpeg', NULL, NULL, NULL, NULL, NULL, 400, '350', 370, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', NULL, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 72, NULL, 'Type,Modern,Suitable For,W x H x D,DIY', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, '2019-10-20 16:37:22', '2021-02-16 11:56:40', 0, NULL, NULL, NULL),
(8, 0, NULL, 79, 80, NULL, 'ABS New Coffee Cup Stand Steel Kitchen Rack', 'abs-new-coffee-cup-stand-steel-kitchen-rack-n3e8xvl', '15715646621.jpeg', NULL, NULL, NULL, NULL, NULL, 419, '400', 500, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 19, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 76, NULL, 'Type,Modern,Suitable For,W x H x D,DIY', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, '2019-10-20 16:40:02', '2021-02-13 08:08:52', 0, NULL, NULL, NULL);
INSERT INTO `products` (`id`, `user_id`, `shop_id`, `category_id`, `subcategory_id`, `childcategory_id`, `name`, `slug`, `photo`, `file`, `size`, `size_qty`, `size_price`, `color`, `price`, `basket_commission_amount`, `previous_price`, `details`, `sub_details`, `stock`, `policy`, `status`, `views`, `tags`, `features`, `colors`, `product_condition`, `ship`, `is_meta`, `meta_tag`, `meta_description`, `youtube`, `type`, `license`, `license_qty`, `link`, `platform`, `region`, `licence_type`, `measure`, `featured`, `best`, `top`, `hot`, `latest`, `big`, `trending`, `sale`, `created_at`, `updated_at`, `is_discount`, `discount`, `discount_date`, `store_id`) VALUES
(9, 0, NULL, 79, 81, NULL, 'Ebee Iron Kitchen Rack  (White)', 'ebee-iron-kitchen-rack-white-iom9ciu', '15715645551.jpeg', NULL, NULL, NULL, NULL, NULL, 649, '600', 0, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.c</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 23, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 125, NULL, 'Type,Modern,Suitable For,W x H x D,DIY', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, 0, 0, 0, '2019-10-20 16:42:35', '2021-02-23 04:44:02', 0, NULL, NULL, NULL),
(10, 0, NULL, 93, 97, NULL, 'Weldecor Gate Light Outdoor Lamp', 'weldecor-gate-light-outdoor-lamp-nsc10oux', '15715648131.jpeg', NULL, NULL, NULL, NULL, NULL, 1492, '1000', 0, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 22, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 124, NULL, 'Type,Modern,Suitable For,W x H x D,DIY', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, 0, 0, '2019-10-20 16:46:53', '2021-02-23 04:46:21', 0, NULL, NULL, NULL),
(11, 0, NULL, 93, 97, NULL, 'Geco Flood Light Outdoor Lamp', 'geco-flood-light-outdoor-lamp-jh3112m2', '15715649332.jpeg', NULL, NULL, NULL, NULL, NULL, 2158, '2000', 3000, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 32, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 129, NULL, 'Type,Modern,Suitable For,W x H x D,DIY', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, 0, 0, '2019-10-20 16:48:53', '2021-02-23 04:44:42', 0, NULL, NULL, NULL),
(12, 0, NULL, 106, 118, NULL, 'Digimart  Girls Party(Festive) Dress Cap', 'digimart-girls-partyfestive-dress-cap-zyb12en9', '15715650712.jpeg', NULL, NULL, NULL, NULL, NULL, 319, '300', 400, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 68, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 156, NULL, 'Type,Modern,Suitable For,W x H x D,DIY', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 0, 0, 0, '2019-10-20 16:51:11', '2021-02-23 04:51:24', 0, NULL, NULL, NULL),
(13, 0, NULL, 106, 118, NULL, 'Girls Midi/Knee Length Casual Dress', 'girls-midiknee-length-casual-dress-min13zw0', '15715659151.jpeg', NULL, NULL, NULL, NULL, NULL, 549, '500', 700, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 0, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 154, NULL, 'Type,Modern,Suitable For,W x H x D,DIY', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 1, 0, 0, 0, '2019-10-20 17:05:15', '2021-02-23 04:48:20', 0, NULL, NULL, NULL),
(14, 0, NULL, 442, 447, NULL, 'Ayra pet care Dress, Life Jacket, Coat for Dog, Cat', 'ayra-pet-care-dress-life-jacket-coat-for-dog-cat-dfz14tby', '15715661141.jpeg', NULL, NULL, NULL, NULL, NULL, 399, '350', 450, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 9, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 86, NULL, 'Type,Modern,Suitable For,W x H x D,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in)', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, '2019-10-20 17:08:34', '2021-02-20 18:14:49', 0, NULL, NULL, NULL),
(15, 0, NULL, 442, 443, NULL, 'Canine Creek Starter dry dog food , Ultra Premium Chicken 135000 g Dry Dog Food', 'canine-creek-starter-dry-dog-food-ultra-premium-chicken-135000-g-dry-dog-food-7e415kce', '15715663331.jpeg', NULL, NULL, NULL, NULL, NULL, 5738, '5000', 0, '<span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">We believe that everyone should embrace their uniqueness and shouldn’t settle for universal designs or products. We’re all different and that’s something to be proud of. This needs to be reflected in everything we do and everything we surround ourselves with such as furniture or everyday accessories.&nbsp;</span><a href=\"https://www.homedit.com/20-unique-furniture-designs-that-will-make-you-drool/\" source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(234, 75, 60); background-color: rgb(255, 255, 255); line-height: inherit; transition: all 0.1s ease 0s;\">Unique furniture</a><span source=\"\" sans=\"\" pro\",=\"\" helvetica,=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 17.44px;\"=\"\" style=\"color: rgb(51, 51, 51);\">&nbsp;is hard to come by and that’s why custom-made designs are very appreciated. Every once in a while something stands out. We come across a really interesting concept, design and we think we should definitely remember that for our next home remodel. Ideas like those were put together here. We hope you’ll enjoy our selection of unusual furniture design details.</span><br>', '<ul><li><span class=\"_2YJn2R\" style=\"margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">Bank Offer</span><span style=\"margin: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\">5% Unlimited Cashback on Flipkart Axis Bank Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33); font-family: Roboto, Arial, sans-serif; font-size: 14px;\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">10% Cashback* on HDFC Bank Debit Cards</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li><li><span class=\"_2YJn2R\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px 4px 0px 0px; color: rgb(33, 33, 33);\">Bank Offer</span><span style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; color: rgb(33, 33, 33);\">Extra 5% off* with Axis Bank Buzz Credit Card</span><div class=\"_20yN1P _3eQYiv\" style=\"font-family: Roboto, Arial, sans-serif; font-size: 14px; margin: 0px; padding: 0px; display: inline-block; position: relative; color: rgb(33, 33, 33);\"><span class=\"MBd8C2\" style=\"margin: 0px 0px 0px 5px; padding: 0px; color: rgb(40, 116, 240); display: inline-block; cursor: pointer;\">T&amp;C</span></div></li></ul>', 12, '<span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Within 30 days of the product purchase date you may return products purchased at RogueFlash.com\'s store for a full refund of your purchase price. Products must be returned in their original condition and packaging with all included parts.&nbsp;&nbsp; You are responsible for the cost of the return shipment.</span><br><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Product exchanges are only available for products that you received in a defective or damaged condition or when a different product than what you ordered was incorrectly sent to you.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Shipping and handling is non-refundable on product returns under the 30 Day Return Policy, unless you received a damaged product or the wrong product was sent to you, in which case we will also pay the return shipping cost.</span><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\"><br></span></div><div><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">Return of products to ExpoImaging requires prior approval by e-mail to&nbsp;</span><a href=\"mailto:info@expoimaging.com?subject=Return%20Authorization%20Request\" style=\"color: rgb(0, 153, 229); background-color: rgb(255, 255, 255); outline-style: initial; outline-width: 0px; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; font-size: 14px; line-height: inherit; font-family: Roboto; transition: color 0.1s linear 0s; touch-action: manipulation;\">info@expoimaging.com</a><span style=\"color: rgb(82, 93, 99); font-family: Roboto; font-size: 14px;\">.</span></div>', 1, 135, NULL, 'Type,Modern,Suitable For,W x H x D,DIY', 'Cupboard,Contemporary & Modern Style,Kids Room  Storage  Bedroom,609.6 mm x 1803.4 mm x 381 mm (2 ft x 5 ft 11 in x 1 ft 3 in),Basic assembly to be done with simple tools by the customer  comes with instructions.', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 0, 0, 0, 0, 0, '2019-10-20 17:12:13', '2021-02-23 05:13:03', 0, NULL, NULL, NULL),
(16, 0, NULL, 79, 81, NULL, 'Skyline 04 pcs Unbreakable 100% ABS plastic Fridge Tray Plastic Kitchen Rack', 'skyline-04-pcs-unbreakable-100-abs-plastic-fridge-tray-plastic-kitchen-rack-nn816vpc', '15715843781.jpeg', NULL, NULL, NULL, NULL, NULL, 218, '200', 0, '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p><div><br></div>', '<span style=\"color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px; text-align: justify;\">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English.&nbsp;</span><br>', -10, '<p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 14px;\">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p><div><br></div>', 1, 176, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 0, 0, 0, '2019-10-20 22:12:58', '2021-02-23 05:15:22', 0, NULL, NULL, NULL);
INSERT INTO `products` (`id`, `user_id`, `shop_id`, `category_id`, `subcategory_id`, `childcategory_id`, `name`, `slug`, `photo`, `file`, `size`, `size_qty`, `size_price`, `color`, `price`, `basket_commission_amount`, `previous_price`, `details`, `sub_details`, `stock`, `policy`, `status`, `views`, `tags`, `features`, `colors`, `product_condition`, `ship`, `is_meta`, `meta_tag`, `meta_description`, `youtube`, `type`, `license`, `license_qty`, `link`, `platform`, `region`, `licence_type`, `measure`, `featured`, `best`, `top`, `hot`, `latest`, `big`, `trending`, `sale`, `created_at`, `updated_at`, `is_discount`, `discount`, `discount_date`, `store_id`) VALUES
(17, 0, NULL, 51, 57, NULL, 'Visko 111 Combination Screwdriver Set  (Pack of 9)', 'visko-111-combination-screwdriver-set-pack-of-9-mvs17dsz', '1572100624111-visko-original-imafgzbhgfz7pcxj.jpeg', NULL, NULL, NULL, NULL, NULL, 250, '240', 300, '<br><div><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\">Gear up for the small repair and maintenance jobs at home by including this VISKO Combination Screwdriver Set in your tool collection. Whether it is mechanical or electrical repair jobs, this screwdriver set will come to your rescue.</p><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\"><span style=\"margin: 0px; padding: 0px;\">Tester</span></p><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\">This kit contains an electrical tester that will help you check if electrical connections are live or not as you embark on a repair job.</p><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\"><span style=\"margin: 0px; padding: 0px;\">Extension Rod</span></p><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\">This screwdriver set includes an extension rod that helps you fasten screws that are located in hard-to-reach areas.</p></div>', '<br><div><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\">Gear up for the small repair and maintenance jobs at home by including this VISKO Combination Screwdriver Set in your tool collection. Whether it is mechanical or electrical repair jobs, this screwdriver set will come to your rescue.</p><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\"><span style=\"margin: 0px; padding: 0px;\">Tester</span></p><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\">This kit contains an electrical tester that will help you check if electrical connections are live or not as you embark on a repair job.</p><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\"><span style=\"margin: 0px; padding: 0px;\">Extension Rod</span></p><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\">This screwdriver set includes an extension rod that helps you fasten screws that are located in hard-to-reach areas.</p></div>', 17, '<br><div><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\">Gear up for the small repair and maintenance jobs at home by including this VISKO Combination Screwdriver Set in your tool collection. Whether it is mechanical or electrical repair jobs, this screwdriver set will come to your rescue.</p><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\"><span style=\"margin: 0px; padding: 0px;\">Tester</span></p><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\">This kit contains an electrical tester that will help you check if electrical connections are live or not as you embark on a repair job.</p><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\"><span style=\"margin: 0px; padding: 0px;\">Extension Rod</span></p><p style=\"margin-right: 0px; margin-left: 0px; padding: 0px; color: rgb(33, 33, 33); font-family: Arial, sans-serif; font-size: 14px; letter-spacing: -0.2px;\">This screwdriver set includes an extension rod that helps you fasten screws that are located in hard-to-reach areas.</p></div>', 2, 10, NULL, 'General,Sales Package', 'General,Screwdriver Kit of 8 Blades with Tester  Flat Tip: 3.25  4.5  5 mm  Philips No. - 0  1  2  Pocker and Extension Rod', 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, '2019-10-26 21:37:04', '2019-11-23 19:54:27', 0, NULL, NULL, NULL),
(18, 0, NULL, 51, 52, NULL, 'Wardrobe', 'wardrobe-um718rfn', '1575275869wardrobe.jpeg', NULL, NULL, NULL, NULL, NULL, 1400, '1200', 1600, '<br>', '<br>', 0, '<br>', 1, 67, 'a', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, '2019-12-02 15:37:49', '2021-02-13 08:04:00', 0, NULL, NULL, NULL),
(19, 0, NULL, 79, 84, NULL, 'Wardrobe', 'wardrobe-ipf19c94', '1575288724wardrobe.jpeg', NULL, NULL, NULL, NULL, NULL, 1700, '2000', 1800, '<br>', '<br>', 3, '<br>', 0, 0, 'a', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, '2019-12-02 19:12:04', '2019-12-03 11:53:42', 0, NULL, NULL, NULL),
(20, 10, 11, 51, 52, NULL, 'Havana 6 Seater Dining Table', 'havana-6-seater-dining-table-sfs200zj', '1599407651GUEST_3345b6d4-692e-4aea-ba22-07a9181a0833.jfif', NULL, NULL, NULL, NULL, NULL, 100, '240', 275, '<div class=\"d87Otf\" style=\"-webkit-tap-highlight-color: transparent; color: rgb(154, 160, 166); overflow-wrap: break-word; margin-bottom: 8px; line-height: 19px; font-family: Roboto, HelveticaNeue, Arial, sans-serif; font-size: small; background-color: rgb(20, 21, 24);\"><div style=\"-webkit-tap-highlight-color: transparent;\"><div class=\"UDylye\" style=\"-webkit-tap-highlight-color: transparent; font-size: 14px; line-height: 22px; margin-top: 6px;\"><span class=\"HboBSb\" style=\"-webkit-tap-highlight-color: transparent; display: inline-block; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;\">Brand: Royaloak</span></div><div class=\"YRasv mkSNZe\" style=\"-webkit-tap-highlight-color: transparent; font-size: 14px; line-height: 20px;\">Buy Royaloak Melbourne Coffee Table online Choose from the largest variety of Living online from Royaloak available at the best price in India. Free ...</div></div></div><div class=\"xjRZNc \" style=\"-webkit-tap-highlight-color: transparent; color: rgb(154, 160, 166); font-size: 12px; line-height: 20px; font-family: Roboto, HelveticaNeue, Arial, sans-serif; background-color: rgb(20, 21, 24);\"><div style=\"-webkit-tap-highlight-color: transparent;\">* Check website for latest pricing and availability.&nbsp;Images may be subject to copyright.&nbsp;<a href=\"https://support.google.com/legal/answer/3463239?hl=en\" jslog=\"52885;ved:0CAsQlZ0DahcKEwjwsv6G8dTrAhUAAAAAHQAAAAAQKQ;track:click\" class=\"qnLx5b\" target=\"_blank\" style=\"-webkit-tap-highlight-color: transparent; color: rgb(154, 160, 166); font-weight: 600;\">Learn More</a></div></div>', '<div class=\"d87Otf\" style=\"-webkit-tap-highlight-color: transparent; color: rgb(154, 160, 166); overflow-wrap: break-word; margin-bottom: 8px; line-height: 19px; font-family: Roboto, HelveticaNeue, Arial, sans-serif; font-size: small; background-color: rgb(20, 21, 24);\"><div style=\"-webkit-tap-highlight-color: transparent;\"><div class=\"UDylye\" style=\"-webkit-tap-highlight-color: transparent; font-size: 14px; line-height: 22px; margin-top: 6px;\"><span class=\"HboBSb\" style=\"-webkit-tap-highlight-color: transparent; display: inline-block; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;\">Brand: Royaloak</span></div><div class=\"YRasv mkSNZe\" style=\"-webkit-tap-highlight-color: transparent; font-size: 14px; line-height: 20px;\">Buy Royaloak Melbourne Coffee Table online Choose from the largest variety of Living online from Royaloak available at the best price in India. Free ...</div></div></div>', 6, '<h2 style=\"margin-right: 0px; margin-bottom: 10px; margin-left: 0px; padding: 0px; font-family: DauphinPlain; font-size: 24px; line-height: 24px; color: rgb(0, 0, 0);\">What is Lorem Ipsum?</h2><p style=\"margin-right: 0px; margin-bottom: 15px; margin-left: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" font-size:=\"\" 14px;\"=\"\"><strong style=\"margin: 0px; padding: 0px;\">Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>', 1, 139, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 0, 0, 0, '2020-09-06 15:54:11', '2021-02-23 04:44:22', 0, NULL, NULL, NULL),
(21, 0, NULL, 442, 443, NULL, 'Test', 'test-a1p21hgu', '1599560733coffee cup for customers.jpg', NULL, NULL, NULL, NULL, NULL, 15, '10', 30, 'test', 'test', 2, 'test', 0, 0, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, '2020-09-08 10:25:33', '2020-09-08 10:26:27', 0, NULL, NULL, NULL),
(22, 0, NULL, 448, 449, NULL, 'categorytest', 'categorytest-j5722bhd', '15995609642.jpg', NULL, NULL, NULL, NULL, NULL, 4, '2', 0, '<br>', '<br>', 0, '<br>', 0, 0, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, '2020-09-08 10:29:24', '2020-09-08 10:31:21', 0, NULL, NULL, NULL),
(23, 41, 13, 448, 449, NULL, 'Test123', 'test123-ka523mkh', '1600333670Yogamat.jpg', NULL, NULL, NULL, NULL, NULL, 33, '30', 40, 'main', 'sub', 0, 'one week', 1, 69, 'nice', NULL, NULL, 0, NULL, 0, NULL, NULL, NULL, 'Physical', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 0, 0, 0, '2020-09-17 09:07:50', '2021-02-23 04:25:22', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_clicks`
--

CREATE TABLE `product_clicks` (
  `id` int(191) NOT NULL,
  `product_id` int(191) NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_clicks`
--

INSERT INTO `product_clicks` (`id`, `product_id`, `date`) VALUES
(1, 1, '2019-10-20'),
(2, 2, '2019-10-20'),
(3, 3, '2019-10-20'),
(4, 4, '2019-10-20'),
(5, 5, '2019-10-20'),
(6, 6, '2019-10-20'),
(7, 7, '2019-10-20'),
(8, 8, '2019-10-20'),
(9, 10, '2019-10-20'),
(10, 12, '2019-10-20'),
(11, 12, '2019-10-20'),
(12, 12, '2019-10-20'),
(13, 12, '2019-10-20'),
(14, 6, '2019-10-20'),
(15, 12, '2019-10-20'),
(16, 13, '2019-10-20'),
(17, 14, '2019-10-20'),
(18, 15, '2019-10-20'),
(19, 9, '2019-10-20'),
(20, 9, '2019-10-20'),
(21, 2, '2019-10-20'),
(22, 3, '2019-10-20'),
(23, 2, '2019-10-20'),
(24, 7, '2019-10-20'),
(25, 13, '2019-10-20'),
(26, 6, '2019-10-20'),
(27, 15, '2019-10-20'),
(28, 3, '2019-10-20'),
(29, 2, '2019-10-20'),
(30, 2, '2019-10-20'),
(31, 2, '2019-10-20'),
(32, 2, '2019-10-20'),
(33, 2, '2019-10-20'),
(34, 2, '2019-10-20'),
(35, 2, '2019-10-20'),
(36, 2, '2019-10-20'),
(37, 2, '2019-10-20'),
(38, 2, '2019-10-20'),
(39, 2, '2019-10-20'),
(40, 2, '2019-10-20'),
(41, 2, '2019-10-20'),
(42, 16, '2019-10-20'),
(43, 16, '2019-10-20'),
(44, 16, '2019-10-20'),
(45, 3, '2019-10-20'),
(46, 12, '2019-10-26'),
(47, 12, '2019-10-26'),
(48, 14, '2019-10-26'),
(49, 7, '2019-10-26'),
(50, 2, '2019-10-26'),
(51, 1, '2019-10-26'),
(52, 12, '2019-10-26'),
(53, 12, '2019-10-26'),
(54, 2, '2019-10-26'),
(55, 12, '2019-10-26'),
(56, 12, '2019-10-26'),
(57, 12, '2019-10-26'),
(58, 12, '2019-10-26'),
(59, 3, '2019-10-26'),
(60, 9, '2019-10-26'),
(61, 12, '2019-10-26'),
(62, 12, '2019-10-26'),
(63, 17, '2019-10-26'),
(64, 17, '2019-10-26'),
(65, 17, '2019-10-26'),
(66, 17, '2019-10-26'),
(67, 17, '2019-10-26'),
(68, 12, '2019-10-26'),
(69, 12, '2019-10-26'),
(70, 12, '2019-10-26'),
(71, 12, '2019-10-26'),
(72, 12, '2019-10-26'),
(73, 12, '2019-10-26'),
(74, 12, '2019-10-26'),
(75, 12, '2019-10-26'),
(76, 17, '2019-10-26'),
(77, 12, '2019-10-26'),
(78, 12, '2019-10-26'),
(79, 12, '2019-10-26'),
(80, 12, '2019-10-26'),
(81, 12, '2019-10-26'),
(82, 17, '2019-10-26'),
(83, 17, '2019-10-27'),
(84, 12, '2019-10-27'),
(85, 3, '2019-10-27'),
(86, 12, '2019-10-27'),
(87, 2, '2019-10-29'),
(88, 17, '2019-11-08'),
(89, 9, '2019-11-14'),
(90, 3, '2019-11-19'),
(91, 2, '2019-11-19'),
(92, 2, '2019-11-19'),
(93, 2, '2019-11-19'),
(94, 17, '2019-11-23'),
(95, 3, '2019-11-23'),
(96, 6, '2019-11-23'),
(97, 5, '2019-11-23'),
(98, 16, '2019-11-24'),
(99, 3, '2019-11-27'),
(100, 3, '2019-11-27'),
(101, 3, '2019-11-27'),
(102, 3, '2019-11-27'),
(103, 3, '2019-11-27'),
(104, 3, '2019-11-27'),
(105, 3, '2019-11-27'),
(106, 3, '2019-11-27'),
(107, 2, '2019-12-02'),
(108, 1, '2019-12-02'),
(109, 1, '2019-12-02'),
(110, 3, '2019-12-02'),
(111, 3, '2019-12-02'),
(112, 3, '2019-12-02'),
(113, 3, '2019-12-02'),
(114, 1, '2019-12-02'),
(115, 2, '2019-12-02'),
(116, 3, '2019-12-02'),
(117, 12, '2019-12-02'),
(118, 16, '2019-12-02'),
(119, 5, '2019-12-02'),
(120, 3, '2019-12-02'),
(121, 3, '2019-12-02'),
(122, 3, '2019-12-02'),
(123, 3, '2019-12-02'),
(124, 3, '2019-12-02'),
(125, 3, '2019-12-02'),
(126, 3, '2019-12-02'),
(127, 18, '2019-12-02'),
(128, 16, '2019-12-02'),
(129, 2, '2019-12-02'),
(130, 12, '2019-12-03'),
(131, 12, '2019-12-03'),
(132, 14, '2019-12-03'),
(133, 9, '2019-12-03'),
(134, 18, '2019-12-03'),
(135, 3, '2019-12-03'),
(136, 3, '2019-12-03'),
(137, 18, '2019-12-04'),
(138, 15, '2019-12-05'),
(139, 13, '2019-12-05'),
(140, 18, '2019-12-07'),
(141, 3, '2019-12-07'),
(142, 2, '2019-12-07'),
(143, 2, '2019-12-07'),
(144, 2, '2019-12-07'),
(145, 2, '2019-12-07'),
(146, 18, '2019-12-07'),
(147, 3, '2019-12-07'),
(148, 10, '2019-12-09'),
(149, 11, '2019-12-09'),
(150, 13, '2019-12-09'),
(151, 9, '2019-12-10'),
(152, 9, '2019-12-10'),
(153, 9, '2019-12-10'),
(154, 18, '2019-12-10'),
(155, 18, '2019-12-10'),
(156, 18, '2019-12-10'),
(157, 7, '2019-12-10'),
(158, 7, '2019-12-10'),
(159, 7, '2019-12-10'),
(160, 16, '2019-12-10'),
(161, 3, '2019-12-10'),
(162, 3, '2019-12-10'),
(163, 3, '2019-12-10'),
(164, 3, '2019-12-10'),
(165, 3, '2019-12-10'),
(166, 3, '2019-12-15'),
(167, 3, '2019-12-16'),
(168, 18, '2019-12-16'),
(169, 18, '2019-12-16'),
(170, 18, '2019-12-16'),
(171, 1, '2019-12-16'),
(172, 1, '2019-12-16'),
(173, 18, '2019-12-17'),
(174, 3, '2019-12-17'),
(175, 18, '2019-12-17'),
(176, 1, '2019-12-17'),
(177, 9, '2019-12-19'),
(178, 13, '2019-12-21'),
(179, 3, '2019-12-25'),
(180, 18, '2020-01-04'),
(181, 18, '2020-01-04'),
(182, 18, '2020-01-08'),
(183, 1, '2020-01-08'),
(184, 16, '2020-01-12'),
(185, 18, '2020-01-12'),
(186, 5, '2020-01-12'),
(187, 16, '2020-01-12'),
(188, 16, '2020-01-12'),
(189, 16, '2020-01-13'),
(190, 16, '2020-01-14'),
(191, 16, '2020-01-14'),
(192, 16, '2020-01-14'),
(193, 16, '2020-01-14'),
(194, 16, '2020-01-14'),
(195, 16, '2020-01-14'),
(196, 16, '2020-01-14'),
(197, 16, '2020-01-14'),
(198, 16, '2020-01-14'),
(199, 16, '2020-01-14'),
(200, 5, '2020-01-14'),
(201, 18, '2020-01-14'),
(202, 18, '2020-01-15'),
(203, 18, '2020-01-15'),
(204, 13, '2020-01-15'),
(205, 13, '2020-01-15'),
(206, 13, '2020-01-15'),
(207, 13, '2020-01-15'),
(208, 13, '2020-01-15'),
(209, 16, '2020-01-15'),
(210, 16, '2020-01-15'),
(211, 15, '2020-01-15'),
(212, 15, '2020-01-15'),
(213, 16, '2020-01-15'),
(214, 15, '2020-01-15'),
(215, 15, '2020-01-15'),
(216, 15, '2020-01-15'),
(217, 15, '2020-01-15'),
(218, 1, '2020-01-15'),
(219, 1, '2020-01-15'),
(220, 1, '2020-01-15'),
(221, 1, '2020-01-15'),
(222, 1, '2020-01-15'),
(223, 1, '2020-01-16'),
(224, 1, '2020-01-17'),
(225, 8, '2020-01-18'),
(226, 3, '2020-01-18'),
(227, 3, '2020-01-18'),
(228, 3, '2020-01-18'),
(229, 3, '2020-01-18'),
(230, 3, '2020-01-18'),
(231, 3, '2020-01-18'),
(232, 3, '2020-01-18'),
(233, 3, '2020-01-18'),
(234, 3, '2020-01-18'),
(235, 3, '2020-01-18'),
(236, 1, '2020-01-20'),
(237, 11, '2020-05-11'),
(238, 16, '2020-05-11'),
(239, 6, '2020-05-11'),
(240, 1, '2020-05-12'),
(241, 6, '2020-05-12'),
(242, 9, '2020-05-12'),
(243, 11, '2020-05-12'),
(244, 10, '2020-05-12'),
(245, 13, '2020-05-12'),
(246, 1, '2020-05-12'),
(247, 12, '2020-05-12'),
(248, 3, '2020-05-12'),
(249, 5, '2020-05-12'),
(250, 8, '2020-05-12'),
(251, 2, '2020-05-12'),
(252, 12, '2020-05-12'),
(253, 14, '2020-05-12'),
(254, 7, '2020-05-12'),
(255, 16, '2020-05-12'),
(256, 6, '2020-05-12'),
(257, 15, '2020-05-12'),
(258, 13, '2020-05-13'),
(259, 1, '2020-05-13'),
(260, 9, '2020-05-13'),
(261, 11, '2020-05-13'),
(262, 10, '2020-05-13'),
(263, 12, '2020-05-13'),
(264, 8, '2020-05-13'),
(265, 3, '2020-05-13'),
(266, 2, '2020-05-13'),
(267, 14, '2020-05-13'),
(268, 5, '2020-05-13'),
(269, 4, '2020-05-13'),
(270, 18, '2020-05-13'),
(271, 6, '2020-05-13'),
(272, 7, '2020-05-13'),
(273, 16, '2020-05-13'),
(274, 15, '2020-05-13'),
(275, 18, '2020-05-14'),
(276, 2, '2020-05-21'),
(277, 3, '2020-05-21'),
(278, 5, '2020-05-21'),
(279, 9, '2020-05-21'),
(280, 12, '2020-05-21'),
(281, 13, '2020-05-21'),
(282, 16, '2020-05-21'),
(283, 12, '2020-05-21'),
(284, 1, '2020-05-21'),
(285, 6, '2020-05-21'),
(286, 10, '2020-05-21'),
(287, 11, '2020-05-21'),
(288, 15, '2020-05-21'),
(289, 7, '2020-05-21'),
(290, 8, '2020-05-21'),
(291, 14, '2020-05-21'),
(292, 18, '2020-05-21'),
(293, 4, '2020-05-21'),
(294, 15, '2020-05-22'),
(295, 7, '2020-05-22'),
(296, 6, '2020-05-22'),
(297, 16, '2020-05-22'),
(298, 14, '2020-05-22'),
(299, 3, '2020-05-23'),
(300, 13, '2020-05-23'),
(301, 11, '2020-05-23'),
(302, 1, '2020-05-24'),
(303, 5, '2020-05-25'),
(304, 9, '2020-05-25'),
(305, 2, '2020-05-25'),
(306, 3, '2020-05-25'),
(307, 5, '2020-05-25'),
(308, 9, '2020-05-25'),
(309, 12, '2020-05-25'),
(310, 13, '2020-05-25'),
(311, 16, '2020-05-25'),
(312, 12, '2020-05-25'),
(313, 1, '2020-05-25'),
(314, 6, '2020-05-25'),
(315, 10, '2020-05-25'),
(316, 11, '2020-05-25'),
(317, 15, '2020-05-25'),
(318, 7, '2020-05-25'),
(319, 8, '2020-05-25'),
(320, 14, '2020-05-25'),
(321, 10, '2020-05-25'),
(322, 8, '2020-05-25'),
(323, 2, '2020-05-26'),
(324, 2, '2020-05-27'),
(325, 12, '2020-05-28'),
(326, 15, '2020-05-29'),
(327, 13, '2020-05-29'),
(328, 16, '2020-05-29'),
(329, 9, '2020-05-29'),
(330, 7, '2020-05-29'),
(331, 3, '2020-05-29'),
(332, 2, '2020-05-29'),
(333, 1, '2020-05-29'),
(334, 5, '2020-05-29'),
(335, 11, '2020-05-29'),
(336, 6, '2020-05-29'),
(337, 14, '2020-05-29'),
(338, 10, '2020-05-29'),
(339, 12, '2020-05-29'),
(340, 8, '2020-05-29'),
(341, 3, '2020-05-31'),
(342, 8, '2020-06-15'),
(343, 14, '2020-06-15'),
(344, 7, '2020-06-15'),
(345, 5, '2020-06-15'),
(346, 15, '2020-06-15'),
(347, 1, '2020-06-15'),
(348, 12, '2020-06-15'),
(349, 9, '2020-06-15'),
(350, 3, '2020-06-15'),
(351, 11, '2020-06-15'),
(352, 13, '2020-06-15'),
(353, 6, '2020-06-15'),
(354, 16, '2020-06-15'),
(355, 2, '2020-06-15'),
(356, 10, '2020-06-15'),
(357, 9, '2020-06-16'),
(358, 11, '2020-06-16'),
(359, 10, '2020-06-16'),
(360, 13, '2020-06-16'),
(361, 1, '2020-06-16'),
(362, 12, '2020-06-16'),
(363, 3, '2020-06-16'),
(364, 5, '2020-06-16'),
(365, 8, '2020-06-16'),
(366, 2, '2020-06-16'),
(367, 14, '2020-06-16'),
(368, 15, '2020-06-16'),
(369, 16, '2020-06-16'),
(370, 7, '2020-06-16'),
(371, 6, '2020-06-16'),
(372, 18, '2020-06-16'),
(373, 4, '2020-06-16'),
(374, 18, '2020-06-17'),
(375, 9, '2020-06-17'),
(376, 11, '2020-06-17'),
(377, 18, '2020-06-17'),
(378, 14, '2020-06-17'),
(379, 5, '2020-06-17'),
(380, 15, '2020-06-17'),
(381, 12, '2020-06-17'),
(382, 11, '2020-06-17'),
(383, 6, '2020-06-17'),
(384, 16, '2020-06-17'),
(385, 10, '2020-06-17'),
(386, 8, '2020-06-17'),
(387, 7, '2020-06-17'),
(388, 1, '2020-06-17'),
(389, 9, '2020-06-17'),
(390, 3, '2020-06-17'),
(391, 13, '2020-06-17'),
(392, 2, '2020-06-17'),
(393, 4, '2020-06-17'),
(394, 11, '2020-06-17'),
(395, 18, '2020-06-17'),
(396, 9, '2020-06-17'),
(397, 10, '2020-06-17'),
(398, 11, '2020-06-17'),
(399, 10, '2020-06-17'),
(400, 13, '2020-06-18'),
(401, 1, '2020-06-30'),
(402, 1, '2020-06-30'),
(403, 6, '2020-06-30'),
(404, 12, '2020-07-01'),
(405, 4, '2020-07-01'),
(406, 3, '2020-07-01'),
(407, 14, '2020-07-01'),
(408, 15, '2020-07-01'),
(409, 7, '2020-07-01'),
(410, 6, '2020-07-01'),
(411, 13, '2020-07-01'),
(412, 13, '2020-07-02'),
(413, 10, '2020-07-02'),
(414, 14, '2020-07-02'),
(415, 6, '2020-07-02'),
(416, 12, '2020-07-02'),
(417, 3, '2020-07-02'),
(418, 13, '2020-07-03'),
(419, 15, '2020-07-03'),
(420, 9, '2020-07-03'),
(421, 8, '2020-07-03'),
(422, 2, '2020-07-03'),
(423, 1, '2020-07-04'),
(424, 18, '2020-07-04'),
(425, 7, '2020-07-04'),
(426, 2, '2020-07-05'),
(427, 16, '2020-07-05'),
(428, 9, '2020-07-05'),
(429, 11, '2020-07-05'),
(430, 10, '2020-07-05'),
(431, 13, '2020-07-05'),
(432, 1, '2020-07-05'),
(433, 12, '2020-07-05'),
(434, 5, '2020-07-05'),
(435, 8, '2020-07-05'),
(436, 2, '2020-07-05'),
(437, 14, '2020-07-05'),
(438, 15, '2020-07-05'),
(439, 16, '2020-07-05'),
(440, 7, '2020-07-05'),
(441, 6, '2020-07-05'),
(442, 16, '2020-07-05'),
(443, 5, '2020-07-06'),
(444, 8, '2020-07-06'),
(445, 2, '2020-07-06'),
(446, 16, '2020-07-06'),
(447, 8, '2020-07-06'),
(448, 14, '2020-07-06'),
(449, 7, '2020-07-06'),
(450, 5, '2020-07-06'),
(451, 15, '2020-07-06'),
(452, 1, '2020-07-06'),
(453, 12, '2020-07-06'),
(454, 9, '2020-07-06'),
(455, 3, '2020-07-06'),
(456, 11, '2020-07-06'),
(457, 13, '2020-07-06'),
(458, 6, '2020-07-06'),
(459, 16, '2020-07-06'),
(460, 2, '2020-07-06'),
(461, 10, '2020-07-06'),
(462, 1, '2020-07-06'),
(463, 16, '2020-07-06'),
(464, 18, '2020-07-06'),
(465, 7, '2020-07-06'),
(466, 4, '2020-07-07'),
(467, 14, '2020-07-08'),
(468, 15, '2020-07-08'),
(469, 18, '2020-07-08'),
(470, 6, '2020-07-08'),
(471, 12, '2020-07-08'),
(472, 3, '2020-07-08'),
(473, 1, '2020-07-08'),
(474, 2, '2020-07-08'),
(475, 16, '2020-07-08'),
(476, 11, '2020-07-08'),
(477, 10, '2020-07-08'),
(478, 7, '2020-07-08'),
(479, 5, '2020-07-08'),
(480, 18, '2020-07-08'),
(481, 8, '2020-07-08'),
(482, 5, '2020-07-09'),
(483, 9, '2020-07-09'),
(484, 13, '2020-07-09'),
(485, 7, '2020-07-10'),
(486, 9, '2020-07-10'),
(487, 5, '2020-07-10'),
(488, 12, '2020-07-10'),
(489, 3, '2020-07-10'),
(490, 2, '2020-07-10'),
(491, 1, '2020-07-10'),
(492, 16, '2020-07-10'),
(493, 15, '2020-07-10'),
(494, 13, '2020-07-10'),
(495, 7, '2020-07-10'),
(496, 8, '2020-07-10'),
(497, 6, '2020-07-10'),
(498, 11, '2020-07-10'),
(499, 14, '2020-07-10'),
(500, 10, '2020-07-10'),
(501, 11, '2020-07-10'),
(502, 4, '2020-07-11'),
(503, 6, '2020-07-11'),
(504, 2, '2020-07-11'),
(505, 5, '2020-07-12'),
(506, 18, '2020-07-14'),
(507, 1, '2020-07-15'),
(508, 9, '2020-07-29'),
(509, 11, '2020-07-29'),
(510, 10, '2020-07-29'),
(511, 13, '2020-07-29'),
(512, 1, '2020-07-29'),
(513, 12, '2020-07-29'),
(514, 3, '2020-07-29'),
(515, 5, '2020-07-29'),
(516, 8, '2020-07-29'),
(517, 2, '2020-07-29'),
(518, 14, '2020-07-29'),
(519, 15, '2020-07-29'),
(520, 16, '2020-07-29'),
(521, 7, '2020-07-29'),
(522, 6, '2020-07-29'),
(523, 8, '2020-07-29'),
(524, 18, '2020-07-29'),
(525, 14, '2020-07-29'),
(526, 10, '2020-07-30'),
(527, 3, '2020-07-30'),
(528, 5, '2020-07-30'),
(529, 14, '2020-07-30'),
(530, 9, '2020-07-30'),
(531, 1, '2020-07-30'),
(532, 8, '2020-07-30'),
(533, 6, '2020-07-30'),
(534, 2, '2020-07-30'),
(535, 15, '2020-07-30'),
(536, 12, '2020-07-30'),
(537, 13, '2020-07-30'),
(538, 16, '2020-07-30'),
(539, 7, '2020-07-30'),
(540, 11, '2020-07-30'),
(541, 10, '2020-07-30'),
(542, 14, '2020-07-30'),
(543, 8, '2020-07-30'),
(544, 15, '2020-07-30'),
(545, 9, '2020-07-30'),
(546, 12, '2020-07-30'),
(547, 7, '2020-07-30'),
(548, 6, '2020-07-30'),
(549, 13, '2020-07-30'),
(550, 11, '2020-07-30'),
(551, 16, '2020-07-30'),
(552, 10, '2020-07-30'),
(553, 3, '2020-07-30'),
(554, 1, '2020-07-30'),
(555, 2, '2020-07-30'),
(556, 5, '2020-07-30'),
(557, 18, '2020-07-30'),
(558, 4, '2020-07-30'),
(559, 18, '2020-07-30'),
(560, 14, '2020-07-30'),
(561, 15, '2020-07-30'),
(562, 6, '2020-07-30'),
(563, 12, '2020-07-30'),
(564, 8, '2020-07-30'),
(565, 3, '2020-07-30'),
(566, 1, '2020-07-30'),
(567, 2, '2020-07-30'),
(568, 16, '2020-07-30'),
(569, 11, '2020-07-30'),
(570, 10, '2020-07-30'),
(571, 5, '2020-07-30'),
(572, 8, '2020-07-30'),
(573, 13, '2020-07-30'),
(574, 18, '2020-07-30'),
(575, 1, '2020-07-30'),
(576, 9, '2020-07-30'),
(577, 7, '2020-07-30'),
(578, 10, '2020-07-30'),
(579, 13, '2020-07-31'),
(580, 2, '2020-07-31'),
(581, 4, '2020-08-01'),
(582, 2, '2020-08-01'),
(583, 9, '2020-08-01'),
(584, 11, '2020-08-01'),
(585, 10, '2020-08-01'),
(586, 13, '2020-08-01'),
(587, 1, '2020-08-01'),
(588, 12, '2020-08-01'),
(589, 3, '2020-08-01'),
(590, 5, '2020-08-01'),
(591, 8, '2020-08-01'),
(592, 2, '2020-08-01'),
(593, 14, '2020-08-01'),
(594, 15, '2020-08-01'),
(595, 16, '2020-08-01'),
(596, 7, '2020-08-01'),
(597, 6, '2020-08-01'),
(598, 13, '2020-08-02'),
(599, 2, '2020-08-02'),
(600, 15, '2020-08-02'),
(601, 3, '2020-08-02'),
(602, 7, '2020-08-02'),
(603, 2, '2020-08-03'),
(604, 8, '2020-08-03'),
(605, 14, '2020-08-03'),
(606, 13, '2020-08-03'),
(607, 1, '2020-08-03'),
(608, 5, '2020-08-03'),
(609, 16, '2020-08-03'),
(610, 10, '2020-08-03'),
(611, 3, '2020-08-03'),
(612, 8, '2020-08-03'),
(613, 15, '2020-08-03'),
(614, 6, '2020-08-04'),
(615, 9, '2020-08-04'),
(616, 11, '2020-08-04'),
(617, 10, '2020-08-04'),
(618, 13, '2020-08-04'),
(619, 1, '2020-08-04'),
(620, 12, '2020-08-04'),
(621, 3, '2020-08-04'),
(622, 5, '2020-08-04'),
(623, 8, '2020-08-04'),
(624, 2, '2020-08-04'),
(625, 14, '2020-08-04'),
(626, 12, '2020-08-04'),
(627, 7, '2020-08-04'),
(628, 15, '2020-08-04'),
(629, 16, '2020-08-04'),
(630, 6, '2020-08-04'),
(631, 10, '2020-08-04'),
(632, 2, '2020-08-05'),
(633, 2, '2020-08-05'),
(634, 3, '2020-08-05'),
(635, 5, '2020-08-05'),
(636, 14, '2020-08-05'),
(637, 9, '2020-08-05'),
(638, 2, '2020-08-05'),
(639, 1, '2020-08-05'),
(640, 8, '2020-08-05'),
(641, 6, '2020-08-05'),
(642, 2, '2020-08-05'),
(643, 15, '2020-08-05'),
(644, 12, '2020-08-05'),
(645, 13, '2020-08-05'),
(646, 16, '2020-08-05'),
(647, 7, '2020-08-05'),
(648, 11, '2020-08-05'),
(649, 10, '2020-08-05'),
(650, 11, '2020-08-06'),
(651, 12, '2020-08-06'),
(652, 2, '2020-08-06'),
(653, 11, '2020-08-07'),
(654, 11, '2020-08-07'),
(655, 9, '2020-08-07'),
(656, 11, '2020-08-07'),
(657, 10, '2020-08-07'),
(658, 13, '2020-08-07'),
(659, 1, '2020-08-07'),
(660, 12, '2020-08-07'),
(661, 3, '2020-08-07'),
(662, 5, '2020-08-07'),
(663, 8, '2020-08-07'),
(664, 2, '2020-08-07'),
(665, 14, '2020-08-07'),
(666, 7, '2020-08-07'),
(667, 15, '2020-08-07'),
(668, 16, '2020-08-07'),
(669, 6, '2020-08-07'),
(670, 10, '2020-08-07'),
(671, 12, '2020-08-07'),
(672, 10, '2020-08-08'),
(673, 10, '2020-08-08'),
(674, 9, '2020-08-08'),
(675, 12, '2020-08-08'),
(676, 13, '2020-08-09'),
(677, 10, '2020-08-09'),
(678, 2, '2020-08-09'),
(679, 16, '2020-08-09'),
(680, 12, '2020-08-09'),
(681, 3, '2020-08-09'),
(682, 12, '2020-08-09'),
(683, 10, '2020-08-09'),
(684, 12, '2020-08-10'),
(685, 12, '2020-08-10'),
(686, 10, '2020-08-10'),
(687, 7, '2020-08-10'),
(688, 14, '2020-08-10'),
(689, 9, '2020-08-10'),
(690, 11, '2020-08-10'),
(691, 10, '2020-08-10'),
(692, 13, '2020-08-10'),
(693, 1, '2020-08-10'),
(694, 12, '2020-08-10'),
(695, 3, '2020-08-10'),
(696, 5, '2020-08-10'),
(697, 8, '2020-08-10'),
(698, 2, '2020-08-10'),
(699, 14, '2020-08-10'),
(700, 15, '2020-08-10'),
(701, 7, '2020-08-10'),
(702, 2, '2020-08-10'),
(703, 16, '2020-08-10'),
(704, 6, '2020-08-10'),
(705, 7, '2020-08-11'),
(706, 11, '2020-08-11'),
(707, 13, '2020-08-11'),
(708, 10, '2020-08-11'),
(709, 12, '2020-08-11'),
(710, 11, '2020-08-11'),
(711, 8, '2020-08-12'),
(712, 5, '2020-08-12'),
(713, 12, '2020-08-12'),
(714, 10, '2020-08-12'),
(715, 3, '2020-08-13'),
(716, 5, '2020-08-13'),
(717, 14, '2020-08-13'),
(718, 9, '2020-08-13'),
(719, 1, '2020-08-13'),
(720, 8, '2020-08-13'),
(721, 6, '2020-08-13'),
(722, 2, '2020-08-13'),
(723, 15, '2020-08-13'),
(724, 12, '2020-08-13'),
(725, 13, '2020-08-13'),
(726, 16, '2020-08-13'),
(727, 7, '2020-08-13'),
(728, 11, '2020-08-13'),
(729, 10, '2020-08-13'),
(730, 9, '2020-08-13'),
(731, 11, '2020-08-13'),
(732, 10, '2020-08-13'),
(733, 13, '2020-08-13'),
(734, 1, '2020-08-13'),
(735, 12, '2020-08-13'),
(736, 3, '2020-08-13'),
(737, 5, '2020-08-13'),
(738, 8, '2020-08-13'),
(739, 2, '2020-08-13'),
(740, 14, '2020-08-13'),
(741, 15, '2020-08-13'),
(742, 7, '2020-08-13'),
(743, 9, '2020-08-13'),
(744, 16, '2020-08-13'),
(745, 6, '2020-08-13'),
(746, 3, '2020-08-14'),
(747, 12, '2020-08-14'),
(748, 18, '2020-08-14'),
(749, 16, '2020-08-15'),
(750, 14, '2020-08-15'),
(751, 9, '2020-08-15'),
(752, 9, '2020-08-15'),
(753, 11, '2020-08-15'),
(754, 10, '2020-08-15'),
(755, 12, '2020-08-15'),
(756, 2, '2020-08-16'),
(757, 6, '2020-08-16'),
(758, 5, '2020-08-17'),
(759, 14, '2020-08-20'),
(760, 8, '2020-08-20'),
(761, 15, '2020-08-20'),
(762, 9, '2020-08-20'),
(763, 12, '2020-08-20'),
(764, 13, '2020-08-20'),
(765, 16, '2020-08-20'),
(766, 11, '2020-08-20'),
(767, 10, '2020-08-20'),
(768, 6, '2020-08-20'),
(769, 7, '2020-08-20'),
(770, 3, '2020-08-20'),
(771, 1, '2020-08-20'),
(772, 2, '2020-08-20'),
(773, 18, '2020-08-20'),
(774, 5, '2020-08-20'),
(775, 4, '2020-08-20'),
(776, 6, '2020-08-20'),
(777, 12, '2020-08-20'),
(778, 14, '2020-08-20'),
(779, 16, '2020-08-20'),
(780, 15, '2020-08-20'),
(781, 11, '2020-08-20'),
(782, 10, '2020-08-20'),
(783, 5, '2020-08-20'),
(784, 3, '2020-08-21'),
(785, 8, '2020-08-21'),
(786, 2, '2020-08-21'),
(787, 1, '2020-08-21'),
(788, 9, '2020-08-21'),
(789, 18, '2020-08-21'),
(790, 7, '2020-08-21'),
(791, 13, '2020-08-21'),
(792, 2, '2020-08-21'),
(793, 13, '2020-08-26'),
(794, 9, '2020-08-27'),
(795, 11, '2020-08-27'),
(796, 10, '2020-08-27'),
(797, 13, '2020-08-27'),
(798, 1, '2020-08-27'),
(799, 12, '2020-08-27'),
(800, 3, '2020-08-27'),
(801, 5, '2020-08-27'),
(802, 8, '2020-08-27'),
(803, 2, '2020-08-27'),
(804, 14, '2020-08-27'),
(805, 16, '2020-08-27'),
(806, 7, '2020-08-27'),
(807, 15, '2020-08-27'),
(808, 6, '2020-08-27'),
(809, 14, '2020-08-27'),
(810, 5, '2020-08-27'),
(811, 7, '2020-08-28'),
(812, 12, '2020-08-29'),
(813, 16, '2020-09-03'),
(814, 3, '2020-09-03'),
(815, 13, '2020-09-03'),
(816, 18, '2020-09-03'),
(817, 18, '2020-09-03'),
(818, 11, '2020-09-04'),
(819, 10, '2020-09-04'),
(820, 9, '2020-09-04'),
(821, 11, '2020-09-04'),
(822, 10, '2020-09-04'),
(823, 13, '2020-09-04'),
(824, 1, '2020-09-04'),
(825, 12, '2020-09-04'),
(826, 3, '2020-09-04'),
(827, 5, '2020-09-04'),
(828, 8, '2020-09-04'),
(829, 2, '2020-09-04'),
(830, 14, '2020-09-04'),
(831, 15, '2020-09-04'),
(832, 16, '2020-09-04'),
(833, 7, '2020-09-04'),
(834, 6, '2020-09-04'),
(835, 11, '2020-09-04'),
(836, 11, '2020-09-05'),
(837, 12, '2020-09-05'),
(838, 16, '2020-09-06'),
(839, 16, '2020-09-06'),
(840, 14, '2020-09-06'),
(841, 1, '2020-09-06'),
(842, 2, '2020-09-06'),
(843, 6, '2020-09-06'),
(844, 14, '2020-09-06'),
(845, 14, '2020-09-06'),
(846, 18, '2020-09-06'),
(847, 18, '2020-09-06'),
(848, 13, '2020-09-06'),
(849, 20, '2020-09-06'),
(850, 18, '2020-09-06'),
(851, 3, '2020-09-06'),
(852, 3, '2020-09-06'),
(853, 3, '2020-09-06'),
(854, 3, '2020-09-06'),
(855, 10, '2020-09-06'),
(856, 20, '2020-09-06'),
(857, 20, '2020-09-06'),
(858, 20, '2020-09-06'),
(859, 2, '2020-09-06'),
(860, 20, '2020-09-07'),
(861, 13, '2020-09-07'),
(862, 18, '2020-09-07'),
(863, 10, '2020-09-07'),
(864, 11, '2020-09-07'),
(865, 11, '2020-09-07'),
(866, 2, '2020-09-07'),
(867, 13, '2020-09-07'),
(868, 13, '2020-09-07'),
(869, 20, '2020-09-07'),
(870, 9, '2020-09-07'),
(871, 11, '2020-09-07'),
(872, 10, '2020-09-07'),
(873, 13, '2020-09-07'),
(874, 1, '2020-09-07'),
(875, 12, '2020-09-07'),
(876, 3, '2020-09-07'),
(877, 5, '2020-09-07'),
(878, 8, '2020-09-07'),
(879, 2, '2020-09-07'),
(880, 14, '2020-09-07'),
(881, 15, '2020-09-07'),
(882, 16, '2020-09-07'),
(883, 7, '2020-09-07'),
(884, 6, '2020-09-07'),
(885, 2, '2020-09-07'),
(886, 11, '2020-09-07'),
(887, 20, '2020-09-08'),
(888, 1, '2020-09-08'),
(889, 4, '2020-09-08'),
(890, 13, '2020-09-08'),
(891, 13, '2020-09-08'),
(892, 13, '2020-09-08'),
(893, 20, '2020-09-08'),
(894, 3, '2020-09-08'),
(895, 7, '2020-09-08'),
(896, 10, '2020-09-13'),
(897, 2, '2020-09-13'),
(898, 3, '2020-09-13'),
(899, 5, '2020-09-13'),
(900, 9, '2020-09-13'),
(901, 12, '2020-09-13'),
(902, 13, '2020-09-13'),
(903, 16, '2020-09-13'),
(904, 20, '2020-09-13'),
(905, 1, '2020-09-13'),
(906, 6, '2020-09-13'),
(907, 10, '2020-09-13'),
(908, 11, '2020-09-13'),
(909, 15, '2020-09-13'),
(910, 7, '2020-09-13'),
(911, 8, '2020-09-13'),
(912, 14, '2020-09-13'),
(913, 13, '2020-09-13'),
(914, 7, '2020-09-14'),
(915, 10, '2020-09-14'),
(916, 7, '2020-09-14'),
(917, 12, '2020-09-14'),
(918, 12, '2020-09-14'),
(919, 12, '2020-09-14'),
(920, 11, '2020-09-14'),
(921, 8, '2020-09-14'),
(922, 14, '2020-09-14'),
(923, 7, '2020-09-14'),
(924, 15, '2020-09-14'),
(925, 9, '2020-09-14'),
(926, 11, '2020-09-14'),
(927, 6, '2020-09-14'),
(928, 2, '2020-09-14'),
(929, 5, '2020-09-15'),
(930, 1, '2020-09-15'),
(931, 12, '2020-09-15'),
(932, 3, '2020-09-15'),
(933, 13, '2020-09-15'),
(934, 20, '2020-09-15'),
(935, 16, '2020-09-15'),
(936, 4, '2020-09-15'),
(937, 18, '2020-09-15'),
(938, 10, '2020-09-15'),
(939, 1, '2020-09-15'),
(940, 20, '2020-09-15'),
(941, 20, '2020-09-15'),
(942, 20, '2020-09-15'),
(943, 20, '2020-09-15'),
(944, 20, '2020-09-15'),
(945, 20, '2020-09-15'),
(946, 20, '2020-09-15'),
(947, 20, '2020-09-15'),
(948, 20, '2020-09-15'),
(949, 20, '2020-09-15'),
(950, 20, '2020-09-15'),
(951, 20, '2020-09-15'),
(952, 20, '2020-09-15'),
(953, 20, '2020-09-15'),
(954, 20, '2020-09-15'),
(955, 20, '2020-09-15'),
(956, 20, '2020-09-15'),
(957, 20, '2020-09-15'),
(958, 20, '2020-09-15'),
(959, 20, '2020-09-15'),
(960, 20, '2020-09-15'),
(961, 20, '2020-09-15'),
(962, 20, '2020-09-15'),
(963, 20, '2020-09-15'),
(964, 20, '2020-09-15'),
(965, 20, '2020-09-15'),
(966, 20, '2020-09-15'),
(967, 20, '2020-09-16'),
(968, 2, '2020-09-16'),
(969, 3, '2020-09-16'),
(970, 5, '2020-09-16'),
(971, 9, '2020-09-16'),
(972, 12, '2020-09-16'),
(973, 13, '2020-09-16'),
(974, 16, '2020-09-16'),
(975, 20, '2020-09-16'),
(976, 1, '2020-09-16'),
(977, 6, '2020-09-16'),
(978, 10, '2020-09-16'),
(979, 11, '2020-09-16'),
(980, 15, '2020-09-16'),
(981, 7, '2020-09-16'),
(982, 8, '2020-09-16'),
(983, 14, '2020-09-16'),
(984, 18, '2020-09-16'),
(985, 4, '2020-09-16'),
(986, 20, '2020-09-16'),
(987, 1, '2020-09-16'),
(988, 20, '2020-09-16'),
(989, 18, '2020-09-16'),
(990, 1, '2020-09-16'),
(991, 6, '2020-09-16'),
(992, 20, '2020-09-16'),
(993, 12, '2020-09-17'),
(994, 23, '2020-09-17'),
(995, 3, '2020-09-17'),
(996, 5, '2020-09-17'),
(997, 14, '2020-09-17'),
(998, 9, '2020-09-17'),
(999, 1, '2020-09-17'),
(1000, 6, '2020-09-17'),
(1001, 2, '2020-09-17'),
(1002, 8, '2020-09-17'),
(1003, 15, '2020-09-17'),
(1004, 12, '2020-09-17'),
(1005, 13, '2020-09-17'),
(1006, 16, '2020-09-17'),
(1007, 7, '2020-09-17'),
(1008, 20, '2020-09-17'),
(1009, 11, '2020-09-17'),
(1010, 10, '2020-09-17'),
(1011, 23, '2020-09-17'),
(1012, 6, '2020-09-18'),
(1013, 2, '2020-09-18'),
(1014, 3, '2020-09-19'),
(1015, 16, '2020-09-19'),
(1016, 7, '2020-09-20'),
(1017, 2, '2020-09-20'),
(1018, 13, '2020-09-20'),
(1019, 6, '2020-09-20'),
(1020, 5, '2020-09-20'),
(1021, 1, '2020-09-20'),
(1022, 14, '2020-09-20'),
(1023, 20, '2020-09-20'),
(1024, 10, '2020-09-20'),
(1025, 23, '2020-09-20'),
(1026, 20, '2020-09-20'),
(1027, 15, '2020-09-20'),
(1028, 4, '2020-09-20'),
(1029, 8, '2020-09-20'),
(1030, 9, '2020-09-20'),
(1031, 12, '2020-09-20'),
(1032, 12, '2020-09-20'),
(1033, 2, '2020-09-20'),
(1034, 11, '2020-09-20'),
(1035, 15, '2020-09-21'),
(1036, 23, '2020-09-22'),
(1037, 9, '2020-09-22'),
(1038, 20, '2020-09-22'),
(1039, 11, '2020-09-22'),
(1040, 10, '2020-09-22'),
(1041, 13, '2020-09-22'),
(1042, 1, '2020-09-22'),
(1043, 12, '2020-09-22'),
(1044, 3, '2020-09-22'),
(1045, 5, '2020-09-22'),
(1046, 8, '2020-09-22'),
(1047, 2, '2020-09-22'),
(1048, 14, '2020-09-22'),
(1049, 7, '2020-09-22'),
(1050, 15, '2020-09-22'),
(1051, 16, '2020-09-22'),
(1052, 6, '2020-09-22'),
(1053, 20, '2020-09-23'),
(1054, 23, '2020-09-24'),
(1055, 9, '2020-09-24'),
(1056, 20, '2020-09-24'),
(1057, 13, '2020-09-24'),
(1058, 1, '2020-09-24'),
(1059, 10, '2020-09-24'),
(1060, 12, '2020-09-24'),
(1061, 11, '2020-09-24'),
(1062, 3, '2020-09-24'),
(1063, 5, '2020-09-24'),
(1064, 8, '2020-09-24'),
(1065, 2, '2020-09-24'),
(1066, 14, '2020-09-24'),
(1067, 16, '2020-09-24'),
(1068, 15, '2020-09-24'),
(1069, 7, '2020-09-24'),
(1070, 6, '2020-09-24'),
(1071, 18, '2020-09-24'),
(1072, 4, '2020-09-24'),
(1073, 23, '2020-09-24'),
(1074, 5, '2020-09-24'),
(1075, 5, '2020-09-24'),
(1076, 20, '2020-09-24'),
(1077, 20, '2020-09-24'),
(1078, 4, '2020-09-24'),
(1079, 4, '2020-09-24'),
(1080, 5, '2020-09-24'),
(1081, 5, '2020-09-24'),
(1082, 5, '2020-09-24'),
(1083, 5, '2020-09-24'),
(1084, 5, '2020-09-24'),
(1085, 5, '2020-09-24'),
(1086, 5, '2020-09-24'),
(1087, 5, '2020-09-24'),
(1088, 20, '2020-09-24'),
(1089, 4, '2020-09-24'),
(1090, 5, '2020-09-24'),
(1091, 5, '2020-09-24'),
(1092, 20, '2020-09-24'),
(1093, 5, '2020-09-24'),
(1094, 10, '2020-09-24'),
(1095, 15, '2020-09-24'),
(1096, 15, '2020-09-24'),
(1097, 2, '2020-09-24'),
(1098, 2, '2020-09-24'),
(1099, 15, '2020-09-24'),
(1100, 15, '2020-09-24'),
(1101, 15, '2020-09-24'),
(1102, 15, '2020-09-24'),
(1103, 15, '2020-09-24'),
(1104, 15, '2020-09-24'),
(1105, 15, '2020-09-24'),
(1106, 15, '2020-09-24'),
(1107, 15, '2020-09-24'),
(1108, 15, '2020-09-24'),
(1109, 15, '2020-09-24'),
(1110, 4, '2020-09-24'),
(1111, 15, '2020-09-24'),
(1112, 2, '2020-09-24'),
(1113, 15, '2020-09-24'),
(1114, 15, '2020-09-24'),
(1115, 9, '2020-09-24'),
(1116, 20, '2020-09-24'),
(1117, 3, '2020-09-24'),
(1118, 5, '2020-09-24'),
(1119, 14, '2020-09-24'),
(1120, 9, '2020-09-24'),
(1121, 1, '2020-09-24'),
(1122, 6, '2020-09-24'),
(1123, 2, '2020-09-24'),
(1124, 8, '2020-09-24'),
(1125, 2, '2020-09-24'),
(1126, 11, '2020-09-24'),
(1127, 10, '2020-09-24'),
(1128, 2, '2020-09-24'),
(1129, 14, '2020-09-24'),
(1130, 16, '2020-09-24'),
(1131, 6, '2020-09-24'),
(1132, 1, '2020-09-24'),
(1133, 15, '2020-09-24'),
(1134, 15, '2020-09-24'),
(1135, 12, '2020-09-24'),
(1136, 13, '2020-09-24'),
(1137, 16, '2020-09-25'),
(1138, 23, '2020-09-25'),
(1139, 7, '2020-09-25'),
(1140, 2, '2020-09-25'),
(1141, 20, '2020-09-26'),
(1142, 23, '2020-09-26'),
(1143, 5, '2020-09-26'),
(1144, 20, '2020-09-28'),
(1145, 14, '2020-09-29'),
(1146, 15, '2020-09-29'),
(1147, 9, '2020-09-29'),
(1148, 8, '2020-09-29'),
(1149, 2, '2020-09-30'),
(1150, 2, '2020-09-30'),
(1151, 1, '2020-09-30'),
(1152, 20, '2020-09-30'),
(1153, 3, '2020-09-30'),
(1154, 1, '2020-09-30'),
(1155, 2, '2020-09-30'),
(1156, 3, '2020-09-30'),
(1157, 20, '2020-09-30'),
(1158, 8, '2020-09-30'),
(1159, 10, '2020-09-30'),
(1160, 12, '2020-09-30'),
(1161, 13, '2020-09-30'),
(1162, 23, '2020-09-30'),
(1163, 13, '2020-09-30'),
(1164, 15, '2020-09-30'),
(1165, 3, '2020-09-30'),
(1166, 20, '2020-09-30'),
(1167, 11, '2020-09-30'),
(1168, 9, '2020-09-30'),
(1169, 3, '2020-09-30'),
(1170, 10, '2020-10-01'),
(1171, 14, '2020-10-01'),
(1172, 1, '2020-10-01'),
(1173, 6, '2020-10-01'),
(1174, 2, '2020-10-01'),
(1175, 8, '2020-10-01'),
(1176, 20, '2020-10-01'),
(1177, 11, '2020-10-01'),
(1178, 2, '2020-10-01'),
(1179, 3, '2020-10-01'),
(1180, 2, '2020-10-01'),
(1181, 3, '2020-10-01'),
(1182, 6, '2020-10-01'),
(1183, 7, '2020-10-01'),
(1184, 2, '2020-10-01'),
(1185, 15, '2020-10-01'),
(1186, 10, '2020-10-01'),
(1187, 16, '2020-10-01'),
(1188, 2, '2020-10-01'),
(1189, 1, '2020-10-01'),
(1190, 5, '2020-10-01'),
(1191, 12, '2020-10-01'),
(1192, 5, '2020-10-01'),
(1193, 13, '2020-10-01'),
(1194, 8, '2020-10-01'),
(1195, 9, '2020-10-01'),
(1196, 7, '2020-10-02'),
(1197, 23, '2020-10-02'),
(1198, 2, '2020-10-03'),
(1199, 20, '2020-10-04'),
(1200, 13, '2020-10-04'),
(1201, 13, '2020-10-04'),
(1202, 13, '2020-10-04'),
(1203, 13, '2020-10-04'),
(1204, 13, '2020-10-04'),
(1205, 2, '2020-10-04'),
(1206, 11, '2020-10-05'),
(1207, 2, '2020-10-05'),
(1208, 8, '2020-10-05'),
(1209, 23, '2020-10-06'),
(1210, 9, '2020-10-06'),
(1211, 20, '2020-10-06'),
(1212, 11, '2020-10-06'),
(1213, 10, '2020-10-06'),
(1214, 13, '2020-10-06'),
(1215, 1, '2020-10-06'),
(1216, 12, '2020-10-06'),
(1217, 3, '2020-10-06'),
(1218, 5, '2020-10-06'),
(1219, 2, '2020-10-06'),
(1220, 6, '2020-10-06'),
(1221, 15, '2020-10-06'),
(1222, 16, '2020-10-06'),
(1223, 13, '2020-10-06'),
(1224, 13, '2020-10-06'),
(1225, 14, '2020-10-06'),
(1226, 2, '2020-10-06'),
(1227, 13, '2020-10-06'),
(1228, 16, '2020-10-06'),
(1229, 1, '2020-10-07'),
(1230, 13, '2020-10-07'),
(1231, 20, '2020-10-07'),
(1232, 3, '2020-10-07'),
(1233, 1, '2020-10-07'),
(1234, 6, '2020-10-07'),
(1235, 2, '2020-10-07'),
(1236, 13, '2020-10-07'),
(1237, 11, '2020-10-07'),
(1238, 14, '2020-10-07'),
(1239, 8, '2020-10-07'),
(1240, 15, '2020-10-08'),
(1241, 10, '2020-10-08'),
(1242, 16, '2020-10-08'),
(1243, 12, '2020-10-08'),
(1244, 5, '2020-10-08'),
(1245, 13, '2020-10-08'),
(1246, 13, '2020-10-08'),
(1247, 9, '2020-10-08'),
(1248, 13, '2020-10-08'),
(1249, 23, '2020-10-08'),
(1250, 7, '2020-10-09'),
(1251, 8, '2020-10-11'),
(1252, 2, '2020-10-12'),
(1253, 2, '2020-10-12'),
(1254, 3, '2020-10-12'),
(1255, 3, '2020-10-12'),
(1256, 5, '2020-10-12'),
(1257, 5, '2020-10-12'),
(1258, 9, '2020-10-12'),
(1259, 9, '2020-10-12'),
(1260, 12, '2020-10-12'),
(1261, 13, '2020-10-12'),
(1262, 13, '2020-10-12'),
(1263, 16, '2020-10-12'),
(1264, 16, '2020-10-12'),
(1265, 20, '2020-10-12'),
(1266, 20, '2020-10-12'),
(1267, 23, '2020-10-12'),
(1268, 23, '2020-10-12'),
(1269, 1, '2020-10-12'),
(1270, 1, '2020-10-12'),
(1271, 6, '2020-10-12'),
(1272, 6, '2020-10-12'),
(1273, 10, '2020-10-12'),
(1274, 10, '2020-10-12'),
(1275, 11, '2020-10-12'),
(1276, 11, '2020-10-12'),
(1277, 15, '2020-10-12'),
(1278, 15, '2020-10-12'),
(1279, 20, '2020-10-13'),
(1280, 5, '2020-10-13'),
(1281, 5, '2020-10-13'),
(1282, 5, '2020-10-13'),
(1283, 5, '2020-10-13'),
(1284, 11, '2020-10-13'),
(1285, 11, '2020-10-13'),
(1286, 5, '2020-10-13'),
(1287, 5, '2020-10-13'),
(1288, 11, '2020-10-13'),
(1289, 11, '2020-10-13'),
(1290, 5, '2020-10-13'),
(1291, 5, '2020-10-13'),
(1292, 11, '2020-10-13'),
(1293, 11, '2020-10-13'),
(1294, 11, '2020-10-13'),
(1295, 11, '2020-10-13'),
(1296, 5, '2020-10-13'),
(1297, 5, '2020-10-13'),
(1298, 11, '2020-10-13'),
(1299, 11, '2020-10-13'),
(1300, 3, '2020-10-13'),
(1301, 1, '2020-10-13'),
(1302, 6, '2020-10-13'),
(1303, 2, '2020-10-13'),
(1304, 14, '2020-10-13'),
(1305, 11, '2020-10-14'),
(1306, 15, '2020-10-14'),
(1307, 10, '2020-10-14'),
(1308, 16, '2020-10-14'),
(1309, 12, '2020-10-14'),
(1310, 5, '2020-10-14'),
(1311, 13, '2020-10-14'),
(1312, 2, '2020-10-14'),
(1313, 3, '2020-10-14'),
(1314, 5, '2020-10-14'),
(1315, 9, '2020-10-14'),
(1316, 12, '2020-10-14'),
(1317, 13, '2020-10-14'),
(1318, 16, '2020-10-14'),
(1319, 20, '2020-10-14'),
(1320, 23, '2020-10-14'),
(1321, 1, '2020-10-14'),
(1322, 6, '2020-10-14'),
(1323, 10, '2020-10-14'),
(1324, 11, '2020-10-14'),
(1325, 15, '2020-10-14'),
(1326, 9, '2020-10-14'),
(1327, 11, '2020-10-14'),
(1328, 16, '2020-10-15'),
(1329, 9, '2020-10-15'),
(1330, 2, '2020-10-15'),
(1331, 10, '2020-10-15'),
(1332, 14, '2020-10-15'),
(1333, 23, '2020-10-15'),
(1334, 8, '2020-10-15'),
(1335, 20, '2020-10-15'),
(1336, 8, '2020-10-15'),
(1337, 2, '2020-10-15'),
(1338, 9, '2020-10-15'),
(1339, 3, '2020-10-15'),
(1340, 12, '2020-10-15'),
(1341, 7, '2020-10-16'),
(1342, 3, '2020-10-16'),
(1343, 20, '2020-10-17'),
(1344, 23, '2020-10-17'),
(1345, 10, '2020-10-17'),
(1346, 16, '2020-10-18'),
(1347, 6, '2020-10-18'),
(1348, 23, '2020-10-20'),
(1349, 9, '2020-10-20'),
(1350, 20, '2020-10-20'),
(1351, 11, '2020-10-20'),
(1352, 10, '2020-10-20'),
(1353, 13, '2020-10-20'),
(1354, 1, '2020-10-20'),
(1355, 12, '2020-10-20'),
(1356, 3, '2020-10-20'),
(1357, 5, '2020-10-20'),
(1358, 2, '2020-10-20'),
(1359, 16, '2020-10-20'),
(1360, 6, '2020-10-20'),
(1361, 15, '2020-10-20'),
(1362, 15, '2020-10-20'),
(1363, 3, '2020-10-20'),
(1364, 11, '2020-10-20'),
(1365, 15, '2020-10-20'),
(1366, 10, '2020-10-20'),
(1367, 16, '2020-10-20'),
(1368, 20, '2020-10-20'),
(1369, 1, '2020-10-20'),
(1370, 6, '2020-10-20'),
(1371, 12, '2020-10-21'),
(1372, 5, '2020-10-21'),
(1373, 13, '2020-10-21'),
(1374, 2, '2020-10-21'),
(1375, 20, '2020-10-21'),
(1376, 16, '2020-10-21'),
(1377, 16, '2020-10-21'),
(1378, 16, '2020-10-21'),
(1379, 16, '2020-10-21'),
(1380, 16, '2020-10-21'),
(1381, 20, '2020-10-21'),
(1382, 1, '2020-10-21'),
(1383, 23, '2020-10-21'),
(1384, 9, '2020-10-22'),
(1385, 3, '2020-10-22'),
(1386, 16, '2020-10-23'),
(1387, 2, '2020-10-23'),
(1388, 2, '2020-10-23'),
(1389, 3, '2020-10-23'),
(1390, 3, '2020-10-23'),
(1391, 5, '2020-10-23'),
(1392, 5, '2020-10-23'),
(1393, 9, '2020-10-23'),
(1394, 9, '2020-10-23'),
(1395, 12, '2020-10-23'),
(1396, 12, '2020-10-23'),
(1397, 13, '2020-10-23'),
(1398, 13, '2020-10-23'),
(1399, 16, '2020-10-23'),
(1400, 16, '2020-10-23'),
(1401, 20, '2020-10-23'),
(1402, 20, '2020-10-23'),
(1403, 23, '2020-10-23'),
(1404, 23, '2020-10-23'),
(1405, 1, '2020-10-23'),
(1406, 1, '2020-10-23'),
(1407, 6, '2020-10-23'),
(1408, 6, '2020-10-23'),
(1409, 10, '2020-10-23'),
(1410, 10, '2020-10-23'),
(1411, 11, '2020-10-23'),
(1412, 11, '2020-10-23'),
(1413, 15, '2020-10-23'),
(1414, 15, '2020-10-23'),
(1415, 14, '2020-10-23'),
(1416, 8, '2020-10-24'),
(1417, 5, '2020-10-24'),
(1418, 11, '2020-10-24'),
(1419, 16, '2020-10-24'),
(1420, 16, '2020-10-24'),
(1421, 4, '2020-10-25'),
(1422, 7, '2020-10-26'),
(1423, 23, '2020-10-26'),
(1424, 3, '2020-10-26'),
(1425, 11, '2020-10-27'),
(1426, 15, '2020-10-27'),
(1427, 1, '2020-10-27'),
(1428, 20, '2020-10-27'),
(1429, 6, '2020-10-27'),
(1430, 12, '2020-10-27'),
(1431, 5, '2020-10-27'),
(1432, 13, '2020-10-27'),
(1433, 13, '2020-10-27'),
(1434, 23, '2020-10-27'),
(1435, 2, '2020-10-27'),
(1436, 23, '2020-10-27'),
(1437, 15, '2020-10-27'),
(1438, 10, '2020-10-27'),
(1439, 14, '2020-10-27'),
(1440, 15, '2020-10-27'),
(1441, 13, '2020-10-28'),
(1442, 23, '2020-10-28'),
(1443, 9, '2020-10-28'),
(1444, 16, '2020-10-29'),
(1445, 11, '2020-10-29'),
(1446, 13, '2020-10-29'),
(1447, 2, '2020-10-30'),
(1448, 9, '2020-10-30'),
(1449, 16, '2020-10-30'),
(1450, 2, '2020-10-30'),
(1451, 2, '2020-10-30'),
(1452, 20, '2020-10-31'),
(1453, 23, '2020-10-31'),
(1454, 9, '2020-10-31'),
(1455, 20, '2020-10-31'),
(1456, 2, '2020-11-01'),
(1457, 2, '2020-11-01'),
(1458, 23, '2020-11-02'),
(1459, 20, '2020-11-02'),
(1460, 20, '2020-11-03'),
(1461, 3, '2020-11-03'),
(1462, 23, '2020-11-03'),
(1463, 9, '2020-11-03'),
(1464, 20, '2020-11-03'),
(1465, 11, '2020-11-03'),
(1466, 10, '2020-11-03'),
(1467, 13, '2020-11-03'),
(1468, 1, '2020-11-03'),
(1469, 12, '2020-11-03'),
(1470, 3, '2020-11-03'),
(1471, 5, '2020-11-03'),
(1472, 2, '2020-11-03'),
(1473, 15, '2020-11-03'),
(1474, 6, '2020-11-03'),
(1475, 16, '2020-11-03'),
(1476, 1, '2020-11-03'),
(1477, 11, '2020-11-03'),
(1478, 6, '2020-11-03'),
(1479, 15, '2020-11-03'),
(1480, 20, '2020-11-03'),
(1481, 12, '2020-11-03'),
(1482, 5, '2020-11-03'),
(1483, 13, '2020-11-03'),
(1484, 10, '2020-11-03'),
(1485, 23, '2020-11-03'),
(1486, 9, '2020-11-03'),
(1487, 2, '2020-11-04'),
(1488, 6, '2020-11-04'),
(1489, 10, '2020-11-04'),
(1490, 16, '2020-11-04'),
(1491, 2, '2020-11-05'),
(1492, 2, '2020-11-05'),
(1493, 8, '2020-11-05'),
(1494, 14, '2020-11-05'),
(1495, 18, '2020-11-05'),
(1496, 12, '2020-11-05'),
(1497, 2, '2020-11-06'),
(1498, 2, '2020-11-07'),
(1499, 20, '2020-11-07'),
(1500, 2, '2020-11-07'),
(1501, 23, '2020-11-08'),
(1502, 16, '2020-11-08'),
(1503, 2, '2020-11-08'),
(1504, 9, '2020-11-09'),
(1505, 2, '2020-11-09'),
(1506, 16, '2020-11-09'),
(1507, 20, '2020-11-09'),
(1508, 2, '2020-11-09'),
(1509, 3, '2020-11-09'),
(1510, 4, '2020-11-09'),
(1511, 13, '2020-11-09'),
(1512, 11, '2020-11-09'),
(1513, 6, '2020-11-09'),
(1514, 15, '2020-11-09'),
(1515, 1, '2020-11-09'),
(1516, 11, '2020-11-09'),
(1517, 2, '2020-11-10'),
(1518, 20, '2020-11-10'),
(1519, 12, '2020-11-10'),
(1520, 5, '2020-11-10'),
(1521, 9, '2020-11-10'),
(1522, 16, '2020-11-10'),
(1523, 23, '2020-11-10'),
(1524, 12, '2020-11-10'),
(1525, 13, '2020-11-10'),
(1526, 5, '2020-11-10'),
(1527, 2, '2020-11-10'),
(1528, 2, '2020-11-10'),
(1529, 4, '2020-11-10'),
(1530, 10, '2020-11-10'),
(1531, 2, '2020-11-11'),
(1532, 2, '2020-11-11'),
(1533, 2, '2020-11-12'),
(1534, 2, '2020-11-12'),
(1535, 16, '2020-11-13'),
(1536, 18, '2020-11-13'),
(1537, 2, '2020-11-14'),
(1538, 8, '2020-11-14'),
(1539, 4, '2020-11-14'),
(1540, 14, '2020-11-14'),
(1541, 6, '2020-11-15'),
(1542, 2, '2020-11-15'),
(1543, 16, '2020-11-15'),
(1544, 3, '2020-11-16'),
(1545, 2, '2020-11-16'),
(1546, 13, '2020-11-16'),
(1547, 9, '2020-11-17'),
(1548, 6, '2020-11-17'),
(1549, 23, '2020-11-17'),
(1550, 10, '2020-11-17'),
(1551, 9, '2020-11-17'),
(1552, 20, '2020-11-17'),
(1553, 11, '2020-11-17'),
(1554, 10, '2020-11-17'),
(1555, 13, '2020-11-17'),
(1556, 1, '2020-11-17'),
(1557, 12, '2020-11-17'),
(1558, 3, '2020-11-17'),
(1559, 5, '2020-11-17'),
(1560, 2, '2020-11-17'),
(1561, 15, '2020-11-17'),
(1562, 16, '2020-11-17'),
(1563, 6, '2020-11-17'),
(1564, 7, '2020-11-17'),
(1565, 2, '2020-11-17'),
(1566, 15, '2020-11-17'),
(1567, 12, '2020-11-17'),
(1568, 2, '2020-11-17'),
(1569, 20, '2020-11-17'),
(1570, 2, '2020-11-17'),
(1571, 15, '2020-11-17'),
(1572, 23, '2020-11-17'),
(1573, 5, '2020-11-17'),
(1574, 5, '2020-11-18'),
(1575, 23, '2020-11-18'),
(1576, 1, '2020-11-18'),
(1577, 2, '2020-11-18'),
(1578, 11, '2020-11-18'),
(1579, 2, '2020-11-19'),
(1580, 16, '2020-11-19'),
(1581, 2, '2020-11-19'),
(1582, 16, '2020-11-19'),
(1583, 15, '2020-11-19'),
(1584, 2, '2020-11-20'),
(1585, 4, '2020-11-20'),
(1586, 16, '2020-11-20'),
(1587, 15, '2020-11-20'),
(1588, 2, '2020-11-20'),
(1589, 1, '2020-11-21'),
(1590, 1, '2020-11-21'),
(1591, 1, '2020-11-21'),
(1592, 2, '2020-11-21'),
(1593, 12, '2020-11-22'),
(1594, 16, '2020-11-22'),
(1595, 2, '2020-11-22'),
(1596, 9, '2020-11-22'),
(1597, 13, '2020-11-22'),
(1598, 3, '2020-11-22'),
(1599, 2, '2020-11-23'),
(1600, 12, '2020-11-23'),
(1601, 2, '2020-11-23'),
(1602, 15, '2020-11-23'),
(1603, 13, '2020-11-23'),
(1604, 2, '2020-11-23'),
(1605, 9, '2020-11-23'),
(1606, 10, '2020-11-23'),
(1607, 2, '2020-11-24'),
(1608, 2, '2020-11-24'),
(1609, 3, '2020-11-24'),
(1610, 3, '2020-11-24'),
(1611, 5, '2020-11-24'),
(1612, 5, '2020-11-24'),
(1613, 9, '2020-11-24'),
(1614, 9, '2020-11-24'),
(1615, 12, '2020-11-24'),
(1616, 12, '2020-11-24'),
(1617, 13, '2020-11-24'),
(1618, 13, '2020-11-24'),
(1619, 16, '2020-11-24'),
(1620, 16, '2020-11-24'),
(1621, 20, '2020-11-24'),
(1622, 20, '2020-11-24'),
(1623, 23, '2020-11-24'),
(1624, 23, '2020-11-24'),
(1625, 1, '2020-11-24'),
(1626, 1, '2020-11-24'),
(1627, 6, '2020-11-24'),
(1628, 6, '2020-11-24'),
(1629, 10, '2020-11-24'),
(1630, 10, '2020-11-24'),
(1631, 11, '2020-11-24'),
(1632, 11, '2020-11-24'),
(1633, 12, '2020-11-24'),
(1634, 2, '2020-11-24'),
(1635, 20, '2020-11-24'),
(1636, 2, '2020-11-24'),
(1637, 15, '2020-11-24'),
(1638, 23, '2020-11-24'),
(1639, 16, '2020-11-24'),
(1640, 5, '2020-11-24'),
(1641, 6, '2020-11-25'),
(1642, 14, '2020-11-25'),
(1643, 1, '2020-11-25'),
(1644, 2, '2020-11-25'),
(1645, 11, '2020-11-25'),
(1646, 10, '2020-11-25'),
(1647, 2, '2020-11-25'),
(1648, 16, '2020-11-25'),
(1649, 13, '2020-11-26'),
(1650, 16, '2020-11-26'),
(1651, 16, '2020-11-26'),
(1652, 1, '2020-11-26'),
(1653, 7, '2020-11-26'),
(1654, 16, '2020-11-27'),
(1655, 16, '2020-11-27'),
(1656, 5, '2020-11-28'),
(1657, 2, '2020-11-28'),
(1658, 11, '2020-11-29'),
(1659, 20, '2020-11-29'),
(1660, 20, '2020-11-29'),
(1661, 20, '2020-11-29'),
(1662, 18, '2020-11-29'),
(1663, 11, '2020-11-29'),
(1664, 23, '2020-11-29'),
(1665, 18, '2020-11-29'),
(1666, 13, '2020-11-29'),
(1667, 9, '2020-11-29'),
(1668, 2, '2020-11-29'),
(1669, 3, '2020-11-29'),
(1670, 5, '2020-11-29'),
(1671, 9, '2020-11-29'),
(1672, 12, '2020-11-29'),
(1673, 13, '2020-11-29'),
(1674, 16, '2020-11-29'),
(1675, 20, '2020-11-29'),
(1676, 23, '2020-11-29'),
(1677, 1, '2020-11-29'),
(1678, 6, '2020-11-29'),
(1679, 10, '2020-11-29'),
(1680, 11, '2020-11-29'),
(1681, 15, '2020-11-29'),
(1682, 1, '2020-11-29'),
(1683, 3, '2020-11-30'),
(1684, 13, '2020-11-30'),
(1685, 11, '2020-11-30'),
(1686, 10, '2020-11-30'),
(1687, 10, '2020-11-30'),
(1688, 12, '2020-11-30'),
(1689, 9, '2020-11-30'),
(1690, 2, '2020-12-01'),
(1691, 14, '2020-12-01'),
(1692, 23, '2020-12-01'),
(1693, 9, '2020-12-01'),
(1694, 20, '2020-12-01'),
(1695, 11, '2020-12-01'),
(1696, 10, '2020-12-01'),
(1697, 13, '2020-12-01'),
(1698, 1, '2020-12-01'),
(1699, 12, '2020-12-01'),
(1700, 3, '2020-12-01'),
(1701, 5, '2020-12-01'),
(1702, 2, '2020-12-01'),
(1703, 15, '2020-12-01'),
(1704, 16, '2020-12-01'),
(1705, 6, '2020-12-01'),
(1706, 15, '2020-12-01'),
(1707, 23, '2020-12-01'),
(1708, 16, '2020-12-01'),
(1709, 5, '2020-12-01'),
(1710, 6, '2020-12-01'),
(1711, 1, '2020-12-01'),
(1712, 9, '2020-12-01'),
(1713, 11, '2020-12-02'),
(1714, 15, '2020-12-02'),
(1715, 20, '2020-12-02'),
(1716, 14, '2020-12-02'),
(1717, 20, '2020-12-02'),
(1718, 3, '2020-12-03'),
(1719, 13, '2020-12-03'),
(1720, 1, '2020-12-03'),
(1721, 16, '2020-12-03'),
(1722, 14, '2020-12-03'),
(1723, 2, '2020-12-03'),
(1724, 2, '2020-12-03'),
(1725, 14, '2020-12-04'),
(1726, 18, '2020-12-04'),
(1727, 2, '2020-12-04'),
(1728, 8, '2020-12-04'),
(1729, 2, '2020-12-05'),
(1730, 14, '2020-12-05'),
(1731, 4, '2020-12-05'),
(1732, 14, '2020-12-05'),
(1733, 7, '2020-12-05'),
(1734, 18, '2020-12-05'),
(1735, 3, '2020-12-06'),
(1736, 4, '2020-12-07'),
(1737, 2, '2020-12-07'),
(1738, 13, '2020-12-07'),
(1739, 3, '2020-12-07'),
(1740, 14, '2020-12-07'),
(1741, 9, '2020-12-07'),
(1742, 2, '2020-12-07'),
(1743, 15, '2020-12-07'),
(1744, 12, '2020-12-07'),
(1745, 13, '2020-12-07'),
(1746, 16, '2020-12-07'),
(1747, 8, '2020-12-07'),
(1748, 11, '2020-12-07'),
(1749, 10, '2020-12-07'),
(1750, 1, '2020-12-07'),
(1751, 2, '2020-12-07'),
(1752, 5, '2020-12-07'),
(1753, 18, '2020-12-07'),
(1754, 5, '2020-12-07'),
(1755, 10, '2020-12-07'),
(1756, 6, '2020-12-07'),
(1757, 7, '2020-12-07'),
(1758, 12, '2020-12-07'),
(1759, 2, '2020-12-07'),
(1760, 9, '2020-12-07'),
(1761, 2, '2020-12-08'),
(1762, 7, '2020-12-08'),
(1763, 15, '2020-12-08'),
(1764, 14, '2020-12-08'),
(1765, 14, '2020-12-08'),
(1766, 14, '2020-12-08'),
(1767, 14, '2020-12-08'),
(1768, 5, '2020-12-08'),
(1769, 14, '2020-12-08'),
(1770, 23, '2020-12-08'),
(1771, 2, '2020-12-08'),
(1772, 6, '2020-12-08'),
(1773, 1, '2020-12-08'),
(1774, 2, '2020-12-08'),
(1775, 11, '2020-12-09'),
(1776, 8, '2020-12-09'),
(1777, 16, '2020-12-09'),
(1778, 20, '2020-12-09'),
(1779, 2, '2020-12-09'),
(1780, 16, '2020-12-10'),
(1781, 16, '2020-12-10'),
(1782, 2, '2020-12-11'),
(1783, 2, '2020-12-11'),
(1784, 3, '2020-12-11'),
(1785, 3, '2020-12-11'),
(1786, 5, '2020-12-11'),
(1787, 5, '2020-12-11'),
(1788, 9, '2020-12-11'),
(1789, 9, '2020-12-11'),
(1790, 12, '2020-12-11'),
(1791, 12, '2020-12-11'),
(1792, 13, '2020-12-11'),
(1793, 13, '2020-12-11'),
(1794, 16, '2020-12-11'),
(1795, 16, '2020-12-11'),
(1796, 20, '2020-12-11'),
(1797, 20, '2020-12-11'),
(1798, 23, '2020-12-11'),
(1799, 23, '2020-12-11'),
(1800, 1, '2020-12-11'),
(1801, 1, '2020-12-11'),
(1802, 6, '2020-12-11'),
(1803, 6, '2020-12-11'),
(1804, 10, '2020-12-11'),
(1805, 10, '2020-12-11'),
(1806, 11, '2020-12-11'),
(1807, 11, '2020-12-11'),
(1808, 15, '2020-12-11'),
(1809, 15, '2020-12-11'),
(1810, 10, '2020-12-11'),
(1811, 2, '2020-12-11'),
(1812, 20, '2020-12-12'),
(1813, 20, '2020-12-12'),
(1814, 16, '2020-12-12'),
(1815, 10, '2020-12-12'),
(1816, 16, '2020-12-12'),
(1817, 2, '2020-12-12'),
(1818, 7, '2020-12-13'),
(1819, 10, '2020-12-13'),
(1820, 8, '2020-12-13'),
(1821, 3, '2020-12-13'),
(1822, 1, '2020-12-14'),
(1823, 12, '2020-12-14'),
(1824, 9, '2020-12-14'),
(1825, 9, '2020-12-14'),
(1826, 15, '2020-12-14'),
(1827, 23, '2020-12-15'),
(1828, 9, '2020-12-15'),
(1829, 20, '2020-12-15'),
(1830, 11, '2020-12-15'),
(1831, 10, '2020-12-15'),
(1832, 13, '2020-12-15'),
(1833, 1, '2020-12-15'),
(1834, 12, '2020-12-15'),
(1835, 3, '2020-12-15'),
(1836, 5, '2020-12-15'),
(1837, 2, '2020-12-15'),
(1838, 15, '2020-12-15'),
(1839, 16, '2020-12-15'),
(1840, 6, '2020-12-15'),
(1841, 5, '2020-12-15'),
(1842, 15, '2020-12-15'),
(1843, 6, '2020-12-15'),
(1844, 18, '2020-12-15'),
(1845, 1, '2020-12-15'),
(1846, 11, '2020-12-16'),
(1847, 2, '2020-12-16'),
(1848, 23, '2020-12-16'),
(1849, 2, '2020-12-17'),
(1850, 20, '2020-12-17'),
(1851, 16, '2020-12-17'),
(1852, 2, '2020-12-17'),
(1853, 10, '2020-12-17'),
(1854, 13, '2020-12-18'),
(1855, 2, '2020-12-19'),
(1856, 6, '2020-12-20'),
(1857, 3, '2020-12-20'),
(1858, 20, '2020-12-20'),
(1859, 2, '2020-12-20'),
(1860, 23, '2020-12-21'),
(1861, 8, '2020-12-21'),
(1862, 12, '2020-12-21'),
(1863, 9, '2020-12-21'),
(1864, 5, '2020-12-22'),
(1865, 15, '2020-12-22'),
(1866, 6, '2020-12-22'),
(1867, 1, '2020-12-22'),
(1868, 1, '2020-12-22'),
(1869, 8, '2020-12-23'),
(1870, 11, '2020-12-23'),
(1871, 2, '2020-12-23'),
(1872, 2, '2020-12-23'),
(1873, 23, '2020-12-23'),
(1874, 20, '2020-12-24'),
(1875, 16, '2020-12-24'),
(1876, 6, '2020-12-24'),
(1877, 3, '2020-12-24'),
(1878, 2, '2020-12-24'),
(1879, 2, '2020-12-24'),
(1880, 23, '2020-12-24'),
(1881, 10, '2020-12-24'),
(1882, 8, '2020-12-24'),
(1883, 13, '2020-12-25'),
(1884, 16, '2020-12-25'),
(1885, 18, '2020-12-25'),
(1886, 8, '2020-12-25'),
(1887, 15, '2020-12-26'),
(1888, 4, '2020-12-26'),
(1889, 15, '2020-12-26'),
(1890, 14, '2020-12-26'),
(1891, 5, '2020-12-27'),
(1892, 16, '2020-12-27'),
(1893, 16, '2020-12-27'),
(1894, 3, '2020-12-27'),
(1895, 5, '2020-12-27'),
(1896, 12, '2020-12-28'),
(1897, 9, '2020-12-28'),
(1898, 2, '2020-12-28'),
(1899, 4, '2020-12-28'),
(1900, 3, '2020-12-28'),
(1901, 14, '2020-12-28'),
(1902, 9, '2020-12-28'),
(1903, 12, '2020-12-28'),
(1904, 13, '2020-12-28'),
(1905, 16, '2020-12-28'),
(1906, 8, '2020-12-28'),
(1907, 11, '2020-12-28'),
(1908, 8, '2020-12-28'),
(1909, 10, '2020-12-28'),
(1910, 1, '2020-12-28'),
(1911, 2, '2020-12-28'),
(1912, 5, '2020-12-28'),
(1913, 18, '2020-12-28'),
(1914, 15, '2020-12-28'),
(1915, 15, '2020-12-29'),
(1916, 7, '2020-12-29'),
(1917, 6, '2020-12-29'),
(1918, 12, '2020-12-29'),
(1919, 5, '2020-12-29'),
(1920, 1, '2020-12-29'),
(1921, 6, '2020-12-29'),
(1922, 23, '2020-12-29'),
(1923, 9, '2020-12-29'),
(1924, 7, '2020-12-29'),
(1925, 20, '2020-12-29'),
(1926, 11, '2020-12-29'),
(1927, 10, '2020-12-29'),
(1928, 13, '2020-12-29'),
(1929, 1, '2020-12-29'),
(1930, 12, '2020-12-29'),
(1931, 3, '2020-12-29'),
(1932, 5, '2020-12-29'),
(1933, 2, '2020-12-29'),
(1934, 15, '2020-12-29'),
(1935, 16, '2020-12-29'),
(1936, 6, '2020-12-29'),
(1937, 16, '2020-12-29'),
(1938, 18, '2020-12-29'),
(1939, 15, '2020-12-29'),
(1940, 2, '2020-12-29'),
(1941, 1, '2020-12-29'),
(1942, 11, '2020-12-29'),
(1943, 2, '2020-12-29'),
(1944, 2, '2020-12-29'),
(1945, 2, '2020-12-30'),
(1946, 2, '2020-12-30'),
(1947, 23, '2020-12-30'),
(1948, 16, '2020-12-30'),
(1949, 20, '2020-12-30'),
(1950, 14, '2020-12-31'),
(1951, 10, '2020-12-31'),
(1952, 11, '2020-12-31'),
(1953, 13, '2020-12-31'),
(1954, 2, '2021-01-01'),
(1955, 2, '2021-01-01'),
(1956, 3, '2021-01-01'),
(1957, 5, '2021-01-01'),
(1958, 9, '2021-01-01'),
(1959, 12, '2021-01-01'),
(1960, 13, '2021-01-01'),
(1961, 16, '2021-01-01'),
(1962, 20, '2021-01-01'),
(1963, 23, '2021-01-01'),
(1964, 1, '2021-01-01'),
(1965, 6, '2021-01-01'),
(1966, 11, '2021-01-01'),
(1967, 15, '2021-01-01'),
(1968, 2, '2021-01-01'),
(1969, 14, '2021-01-01'),
(1970, 18, '2021-01-02'),
(1971, 11, '2021-01-02'),
(1972, 2, '2021-01-02'),
(1973, 16, '2021-01-02'),
(1974, 16, '2021-01-02'),
(1975, 3, '2021-01-02'),
(1976, 8, '2021-01-03'),
(1977, 2, '2021-01-03'),
(1978, 3, '2021-01-03'),
(1979, 5, '2021-01-03'),
(1980, 9, '2021-01-03'),
(1981, 12, '2021-01-03'),
(1982, 13, '2021-01-03'),
(1983, 16, '2021-01-03'),
(1984, 20, '2021-01-03'),
(1985, 23, '2021-01-03'),
(1986, 1, '2021-01-03'),
(1987, 6, '2021-01-03'),
(1988, 10, '2021-01-03'),
(1989, 11, '2021-01-03'),
(1990, 15, '2021-01-03'),
(1991, 12, '2021-01-03'),
(1992, 5, '2021-01-03'),
(1993, 2, '2021-01-03'),
(1994, 9, '2021-01-03'),
(1995, 6, '2021-01-03'),
(1996, 6, '2021-01-03'),
(1997, 2, '2021-01-03'),
(1998, 12, '2021-01-03'),
(1999, 3, '2021-01-03'),
(2000, 2, '2021-01-04'),
(2001, 15, '2021-01-04'),
(2002, 5, '2021-01-04'),
(2003, 1, '2021-01-04'),
(2004, 6, '2021-01-04'),
(2005, 11, '2021-01-05'),
(2006, 2, '2021-01-05'),
(2007, 2, '2021-01-05'),
(2008, 2, '2021-01-05'),
(2009, 16, '2021-01-06'),
(2010, 23, '2021-01-06'),
(2011, 20, '2021-01-06'),
(2012, 2, '2021-01-06'),
(2013, 3, '2021-01-06'),
(2014, 5, '2021-01-06'),
(2015, 12, '2021-01-06'),
(2016, 13, '2021-01-06'),
(2017, 16, '2021-01-06'),
(2018, 20, '2021-01-06'),
(2019, 23, '2021-01-06'),
(2020, 1, '2021-01-06'),
(2021, 6, '2021-01-06'),
(2022, 10, '2021-01-06'),
(2023, 11, '2021-01-06'),
(2024, 15, '2021-01-06'),
(2025, 2, '2021-01-06'),
(2026, 10, '2021-01-06'),
(2027, 13, '2021-01-07'),
(2028, 2, '2021-01-08'),
(2029, 3, '2021-01-08'),
(2030, 5, '2021-01-08'),
(2031, 9, '2021-01-08'),
(2032, 12, '2021-01-08'),
(2033, 16, '2021-01-08'),
(2034, 20, '2021-01-08'),
(2035, 23, '2021-01-08'),
(2036, 1, '2021-01-08'),
(2037, 6, '2021-01-08'),
(2038, 10, '2021-01-08'),
(2039, 11, '2021-01-08'),
(2040, 15, '2021-01-08'),
(2041, 6, '2021-01-08'),
(2042, 1, '2021-01-08'),
(2043, 2, '2021-01-09'),
(2044, 20, '2021-01-09'),
(2045, 2, '2021-01-09'),
(2046, 20, '2021-01-09'),
(2047, 13, '2021-01-09'),
(2048, 9, '2021-01-10'),
(2049, 5, '2021-01-10'),
(2050, 2, '2021-01-10'),
(2051, 3, '2021-01-10'),
(2052, 5, '2021-01-10'),
(2053, 9, '2021-01-10'),
(2054, 12, '2021-01-10'),
(2055, 12, '2021-01-10'),
(2056, 13, '2021-01-10'),
(2057, 3, '2021-01-10'),
(2058, 16, '2021-01-10'),
(2059, 13, '2021-01-10'),
(2060, 23, '2021-01-10'),
(2061, 20, '2021-01-10'),
(2062, 20, '2021-01-10'),
(2063, 1, '2021-01-10'),
(2064, 6, '2021-01-10'),
(2065, 16, '2021-01-10'),
(2066, 10, '2021-01-10'),
(2067, 11, '2021-01-10'),
(2068, 15, '2021-01-10'),
(2069, 16, '2021-01-10'),
(2070, 15, '2021-01-11'),
(2071, 6, '2021-01-11'),
(2072, 5, '2021-01-11'),
(2073, 2, '2021-01-11'),
(2074, 20, '2021-01-11'),
(2075, 11, '2021-01-11'),
(2076, 1, '2021-01-11'),
(2077, 23, '2021-01-11'),
(2078, 23, '2021-01-12'),
(2079, 23, '2021-01-12'),
(2080, 2, '2021-01-12'),
(2081, 9, '2021-01-12'),
(2082, 20, '2021-01-12'),
(2083, 11, '2021-01-12'),
(2084, 10, '2021-01-12'),
(2085, 13, '2021-01-12'),
(2086, 1, '2021-01-12'),
(2087, 12, '2021-01-12'),
(2088, 3, '2021-01-12'),
(2089, 5, '2021-01-12'),
(2090, 2, '2021-01-12'),
(2091, 15, '2021-01-12'),
(2092, 16, '2021-01-12'),
(2093, 6, '2021-01-12'),
(2094, 18, '2021-01-12'),
(2095, 1, '2021-01-12'),
(2096, 16, '2021-01-12'),
(2097, 2, '2021-01-12'),
(2098, 23, '2021-01-12'),
(2099, 5, '2021-01-12'),
(2100, 20, '2021-01-13'),
(2101, 10, '2021-01-13'),
(2102, 2, '2021-01-13'),
(2103, 13, '2021-01-13'),
(2104, 7, '2021-01-13'),
(2105, 23, '2021-01-13'),
(2106, 16, '2021-01-13'),
(2107, 10, '2021-01-13'),
(2108, 2, '2021-01-13'),
(2109, 6, '2021-01-13'),
(2110, 20, '2021-01-13'),
(2111, 13, '2021-01-13'),
(2112, 11, '2021-01-13'),
(2113, 3, '2021-01-13'),
(2114, 1, '2021-01-13'),
(2115, 12, '2021-01-13'),
(2116, 15, '2021-01-13'),
(2117, 9, '2021-01-13'),
(2118, 5, '2021-01-13'),
(2119, 2, '2021-01-13'),
(2120, 6, '2021-01-13'),
(2121, 2, '2021-01-14'),
(2122, 3, '2021-01-14'),
(2123, 5, '2021-01-14'),
(2124, 9, '2021-01-14'),
(2125, 12, '2021-01-14'),
(2126, 13, '2021-01-14'),
(2127, 16, '2021-01-14'),
(2128, 20, '2021-01-14'),
(2129, 1, '2021-01-14'),
(2130, 23, '2021-01-14'),
(2131, 6, '2021-01-14'),
(2132, 11, '2021-01-14'),
(2133, 10, '2021-01-14'),
(2134, 15, '2021-01-14'),
(2135, 13, '2021-01-14'),
(2136, 14, '2021-01-14'),
(2137, 18, '2021-01-14'),
(2138, 14, '2021-01-15'),
(2139, 8, '2021-01-15'),
(2140, 16, '2021-01-15'),
(2141, 3, '2021-01-16'),
(2142, 2, '2021-01-16'),
(2143, 9, '2021-01-16'),
(2144, 14, '2021-01-16'),
(2145, 4, '2021-01-16'),
(2146, 14, '2021-01-16'),
(2147, 1, '2021-01-16'),
(2148, 12, '2021-01-16'),
(2149, 3, '2021-01-17'),
(2150, 6, '2021-01-17'),
(2151, 2, '2021-01-17'),
(2152, 11, '2021-01-17'),
(2153, 20, '2021-01-17'),
(2154, 13, '2021-01-17'),
(2155, 1, '2021-01-17'),
(2156, 9, '2021-01-17'),
(2157, 12, '2021-01-17'),
(2158, 11, '2021-01-17'),
(2159, 15, '2021-01-17'),
(2160, 12, '2021-01-17'),
(2161, 16, '2021-01-17'),
(2162, 15, '2021-01-17'),
(2163, 6, '2021-01-17'),
(2164, 6, '2021-01-17'),
(2165, 5, '2021-01-17'),
(2166, 15, '2021-01-17'),
(2167, 12, '2021-01-18'),
(2168, 2, '2021-01-18'),
(2169, 11, '2021-01-18');
INSERT INTO `product_clicks` (`id`, `product_id`, `date`) VALUES
(2170, 1, '2021-01-18'),
(2171, 8, '2021-01-18'),
(2172, 4, '2021-01-18'),
(2173, 5, '2021-01-18'),
(2174, 6, '2021-01-18'),
(2175, 20, '2021-01-18'),
(2176, 20, '2021-01-18'),
(2177, 2, '2021-01-18'),
(2178, 4, '2021-01-19'),
(2179, 7, '2021-01-19'),
(2180, 3, '2021-01-19'),
(2181, 16, '2021-01-19'),
(2182, 14, '2021-01-19'),
(2183, 9, '2021-01-19'),
(2184, 12, '2021-01-19'),
(2185, 6, '2021-01-19'),
(2186, 13, '2021-01-19'),
(2187, 16, '2021-01-19'),
(2188, 8, '2021-01-19'),
(2189, 11, '2021-01-19'),
(2190, 10, '2021-01-19'),
(2191, 1, '2021-01-19'),
(2192, 2, '2021-01-19'),
(2193, 5, '2021-01-19'),
(2194, 18, '2021-01-19'),
(2195, 15, '2021-01-19'),
(2196, 23, '2021-01-19'),
(2197, 6, '2021-01-19'),
(2198, 2, '2021-01-19'),
(2199, 20, '2021-01-19'),
(2200, 10, '2021-01-19'),
(2201, 2, '2021-01-19'),
(2202, 7, '2021-01-19'),
(2203, 2, '2021-01-19'),
(2204, 20, '2021-01-19'),
(2205, 20, '2021-01-19'),
(2206, 9, '2021-01-19'),
(2207, 6, '2021-01-20'),
(2208, 8, '2021-01-20'),
(2209, 13, '2021-01-20'),
(2210, 6, '2021-01-20'),
(2211, 6, '2021-01-20'),
(2212, 2, '2021-01-21'),
(2213, 20, '2021-01-21'),
(2214, 6, '2021-01-21'),
(2215, 10, '2021-01-21'),
(2216, 5, '2021-01-21'),
(2217, 20, '2021-01-21'),
(2218, 10, '2021-01-21'),
(2219, 12, '2021-01-21'),
(2220, 1, '2021-01-21'),
(2221, 6, '2021-01-22'),
(2222, 2, '2021-01-22'),
(2223, 6, '2021-01-22'),
(2224, 10, '2021-01-22'),
(2225, 12, '2021-01-22'),
(2226, 3, '2021-01-22'),
(2227, 6, '2021-01-22'),
(2228, 6, '2021-01-22'),
(2229, 9, '2021-01-23'),
(2230, 10, '2021-01-23'),
(2231, 12, '2021-01-23'),
(2232, 6, '2021-01-23'),
(2233, 3, '2021-01-23'),
(2234, 16, '2021-01-23'),
(2235, 20, '2021-01-23'),
(2236, 5, '2021-01-23'),
(2237, 13, '2021-01-24'),
(2238, 13, '2021-01-24'),
(2239, 6, '2021-01-24'),
(2240, 15, '2021-01-24'),
(2241, 16, '2021-01-24'),
(2242, 20, '2021-01-24'),
(2243, 5, '2021-01-24'),
(2244, 1, '2021-01-24'),
(2245, 13, '2021-01-24'),
(2246, 11, '2021-01-24'),
(2247, 1, '2021-01-24'),
(2248, 9, '2021-01-24'),
(2249, 20, '2021-01-25'),
(2250, 13, '2021-01-25'),
(2251, 13, '2021-01-25'),
(2252, 16, '2021-01-25'),
(2253, 10, '2021-01-25'),
(2254, 2, '2021-01-25'),
(2255, 2, '2021-01-25'),
(2256, 2, '2021-01-25'),
(2257, 16, '2021-01-25'),
(2258, 6, '2021-01-25'),
(2259, 13, '2021-01-25'),
(2260, 16, '2021-01-25'),
(2261, 9, '2021-01-25'),
(2262, 9, '2021-01-25'),
(2263, 9, '2021-01-25'),
(2264, 9, '2021-01-25'),
(2265, 9, '2021-01-25'),
(2266, 9, '2021-01-25'),
(2267, 9, '2021-01-25'),
(2268, 9, '2021-01-25'),
(2269, 16, '2021-01-26'),
(2270, 8, '2021-01-26'),
(2271, 23, '2021-01-26'),
(2272, 10, '2021-01-26'),
(2273, 23, '2021-01-26'),
(2274, 9, '2021-01-26'),
(2275, 20, '2021-01-26'),
(2276, 11, '2021-01-26'),
(2277, 10, '2021-01-26'),
(2278, 13, '2021-01-26'),
(2279, 1, '2021-01-26'),
(2280, 12, '2021-01-26'),
(2281, 3, '2021-01-26'),
(2282, 5, '2021-01-26'),
(2283, 2, '2021-01-26'),
(2284, 15, '2021-01-26'),
(2285, 16, '2021-01-26'),
(2286, 6, '2021-01-26'),
(2287, 20, '2021-01-26'),
(2288, 13, '2021-01-26'),
(2289, 18, '2021-01-26'),
(2290, 16, '2021-01-26'),
(2291, 2, '2021-01-26'),
(2292, 6, '2021-01-26'),
(2293, 16, '2021-01-26'),
(2294, 1, '2021-01-27'),
(2295, 13, '2021-01-27'),
(2296, 9, '2021-01-27'),
(2297, 16, '2021-01-27'),
(2298, 6, '2021-01-27'),
(2299, 20, '2021-01-27'),
(2300, 14, '2021-01-27'),
(2301, 13, '2021-01-28'),
(2302, 6, '2021-01-28'),
(2303, 3, '2021-01-28'),
(2304, 1, '2021-01-28'),
(2305, 11, '2021-02-03'),
(2306, 8, '2021-02-03'),
(2307, 16, '2021-02-03'),
(2308, 2, '2021-02-03'),
(2309, 6, '2021-02-04'),
(2310, 1, '2021-02-04'),
(2311, 16, '2021-02-05'),
(2312, 1, '2021-02-05'),
(2313, 20, '2021-02-05'),
(2314, 1, '2021-02-05'),
(2315, 7, '2021-02-05'),
(2316, 2, '2021-02-06'),
(2317, 1, '2021-02-06'),
(2318, 23, '2021-02-07'),
(2319, 2, '2021-02-07'),
(2320, 2, '2021-02-07'),
(2321, 20, '2021-02-08'),
(2322, 12, '2021-02-08'),
(2323, 6, '2021-02-08'),
(2324, 16, '2021-02-08'),
(2325, 13, '2021-02-09'),
(2326, 13, '2021-02-09'),
(2327, 1, '2021-02-09'),
(2328, 23, '2021-02-09'),
(2329, 9, '2021-02-09'),
(2330, 20, '2021-02-09'),
(2331, 11, '2021-02-09'),
(2332, 10, '2021-02-09'),
(2333, 13, '2021-02-09'),
(2334, 1, '2021-02-09'),
(2335, 12, '2021-02-09'),
(2336, 3, '2021-02-09'),
(2337, 5, '2021-02-09'),
(2338, 2, '2021-02-09'),
(2339, 15, '2021-02-09'),
(2340, 16, '2021-02-09'),
(2341, 6, '2021-02-09'),
(2342, 13, '2021-02-09'),
(2343, 13, '2021-02-09'),
(2344, 18, '2021-02-09'),
(2345, 6, '2021-02-09'),
(2346, 13, '2021-02-09'),
(2347, 1, '2021-02-09'),
(2348, 15, '2021-02-09'),
(2349, 6, '2021-02-10'),
(2350, 13, '2021-02-10'),
(2351, 15, '2021-02-10'),
(2352, 1, '2021-02-10'),
(2353, 6, '2021-02-11'),
(2354, 16, '2021-02-11'),
(2355, 6, '2021-02-11'),
(2356, 15, '2021-02-11'),
(2357, 1, '2021-02-11'),
(2358, 6, '2021-02-11'),
(2359, 15, '2021-02-11'),
(2360, 6, '2021-02-12'),
(2361, 6, '2021-02-12'),
(2362, 6, '2021-02-12'),
(2363, 2, '2021-02-12'),
(2364, 6, '2021-02-12'),
(2365, 6, '2021-02-13'),
(2366, 18, '2021-02-13'),
(2367, 8, '2021-02-13'),
(2368, 14, '2021-02-13'),
(2369, 6, '2021-02-13'),
(2370, 2, '2021-02-14'),
(2371, 2, '2021-02-15'),
(2372, 5, '2021-02-15'),
(2373, 16, '2021-02-15'),
(2374, 3, '2021-02-15'),
(2375, 3, '2021-02-15'),
(2376, 2, '2021-02-15'),
(2377, 1, '2021-02-15'),
(2378, 16, '2021-02-16'),
(2379, 7, '2021-02-16'),
(2380, 2, '2021-02-17'),
(2381, 5, '2021-02-18'),
(2382, 16, '2021-02-19'),
(2383, 2, '2021-02-20'),
(2384, 14, '2021-02-20'),
(2385, 2, '2021-02-21'),
(2386, 2, '2021-02-22'),
(2387, 2, '2021-02-22'),
(2388, 2, '2021-02-22'),
(2389, 23, '2021-02-23'),
(2390, 9, '2021-02-23'),
(2391, 20, '2021-02-23'),
(2392, 11, '2021-02-23'),
(2393, 10, '2021-02-23'),
(2394, 13, '2021-02-23'),
(2395, 1, '2021-02-23'),
(2396, 12, '2021-02-23'),
(2397, 3, '2021-02-23'),
(2398, 5, '2021-02-23'),
(2399, 2, '2021-02-23'),
(2400, 15, '2021-02-23'),
(2401, 16, '2021-02-23'),
(2402, 6, '2021-02-23');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(191) NOT NULL,
  `user_id` int(191) NOT NULL,
  `product_id` int(191) NOT NULL,
  `title` varchar(250) NOT NULL,
  `review` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `rating` tinyint(2) NOT NULL,
  `review_date` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE `replies` (
  `id` int(11) NOT NULL,
  `user_id` int(191) UNSIGNED NOT NULL,
  `comment_id` int(191) UNSIGNED NOT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(10) UNSIGNED NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle` text COLLATE utf8mb4_unicode_ci,
  `details` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `seotools`
--

CREATE TABLE `seotools` (
  `id` int(10) UNSIGNED NOT NULL,
  `google_analytics` text COLLATE utf8mb4_unicode_ci,
  `meta_keys` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `seotools`
--

INSERT INTO `seotools` (`id`, `google_analytics`, `meta_keys`) VALUES
(1, '<script>//Google Analytics Scriptfffffffffffffffffffffffssssfffffs</script>', 'basket');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(191) NOT NULL,
  `user_id` int(191) NOT NULL DEFAULT '0',
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `user_id`, `title`, `details`, `photo`) VALUES
(2, 0, 'FREE SHIPPING', 'Free Shipping All Order', '1561348133service1.png'),
(3, 0, 'PAYMENT METHOD', 'Secure Payment', '1561348138service2.png'),
(4, 0, '30 DAY RETURNS', '30-Day Return Policy', '1561348143service3.png'),
(5, 0, 'HELP CENTER', '24/7 Support System', '1561348147service4.png'),
(6, 13, 'FREE SHIPPING', 'Free Shipping All Order', '1561346754service4.png'),
(7, 13, 'PAYMENT METHOD', 'Secure Payment', '1561346749service3.png'),
(8, 13, '30 DAY RETURNS', '30-Day Return Policy', '1561346745service2.png'),
(9, 13, 'HELP CENTER', '24/7 Support System', '1561346740service1.png');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_address`
--

CREATE TABLE `shipping_address` (
  `id` int(11) NOT NULL,
  `user_id` varchar(11) NOT NULL,
  `shipping_name` varchar(250) NOT NULL,
  `shipping_phone` varchar(250) NOT NULL,
  `shipping_email` varchar(250) NOT NULL,
  `shipping_address` text NOT NULL,
  `shipping_building_no` varchar(250) DEFAULT NULL,
  `shipping_zone_no` varchar(250) DEFAULT NULL,
  `shipping_street_no` varchar(250) DEFAULT NULL,
  `shipping_city` int(11) DEFAULT NULL,
  `map_lat` varchar(100) DEFAULT NULL,
  `map_long` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shipping_address`
--

INSERT INTO `shipping_address` (`id`, `user_id`, `shipping_name`, `shipping_phone`, `shipping_email`, `shipping_address`, `shipping_building_no`, `shipping_zone_no`, `shipping_street_no`, `shipping_city`, `map_lat`, `map_long`, `created_at`) VALUES
(1, '1', 'Unais Ellias', '33458856', 'contact.unais@gmail.com', 'Doha', '50', '27', '230', 8, NULL, NULL, '2019-10-21 08:09:05'),
(4, '11', 'mohammed', '66655997', 'mgalsulaiti@gmail.com', 'A', '55', '45', '45', 8, NULL, NULL, '2019-10-27 14:34:29'),
(6, '5', 'whyte', '12344561', 'whyte@gf.hg', 'Vzzbznnd', '15', '12', '12', 9, NULL, NULL, '2019-11-11 08:50:02'),
(7, '2', 'test123', '31404159', 'test@test.com', 'Test', '51', '27', '27', 8, NULL, NULL, '2019-11-22 05:53:28'),
(10, '2', 'ggkjkj', '55443366', 'ala@gmail.combb', 'Hhd', '88', '8888', '8888', 9, NULL, NULL, '2019-11-22 05:29:21'),
(17, '2', 'Ann Mary', '12345678', 'ann@whytestudio.co', 'Dfghjdghfksdhfgkjdfhsglh', '10', '23', '23', 9, NULL, NULL, '2019-11-09 05:08:08'),
(18, '2', 'AAAAAAAAAA', '12345678', 'add@sd.if', 'Arfsiisurtryetiuserhtiu', '12', '12', '12', 9, NULL, NULL, '2019-11-09 05:08:52'),
(19, '20', 'mohammed', '66655997', 'mgalsulaiti8@gmail.com', 'Doha', '55', '40', '40', 8, NULL, NULL, '2019-11-09 13:54:31'),
(38, '6', 'Anna', '12345678', 'ann@ddd.ij', 'Shdgjsdgijdsgh', '123', '12', '12', 9, NULL, NULL, '2019-11-11 08:26:30'),
(49, '5', 'Ancy', '12345678', 'ancy@ss.iu', 'Gsdgfjsdhfgjsdhfgjshdfgjsdhfgjsh\nHsdfjsdgdfghdfg', '123', '25', '25', 8, NULL, NULL, '2019-11-11 08:46:54'),
(51, '2', 'nais11', '6522211', 'uani11s@gmail.com', 'sd11fdsvdcxv dc', '53', '27', '230', 2, NULL, NULL, '2019-11-11 09:22:03'),
(53, '5', 'Ramya', '12345678', 'ramya@whytestudio.co', 'Wetwiutriurtuyuteiruytiuert', '10', '20', '20', 9, NULL, NULL, '2019-11-11 09:32:31'),
(58, '2', 'nais11', '6522211', 'uani11s@gmail.com', 'sd11fdsvdcxv dc', '53', '27', '230', 2, NULL, NULL, '2019-11-11 10:00:00'),
(59, '2', 'nais11', '6522211', 'uani11s@gmail.com', 'sd11fdsvdcxv dc', '53', '27', '230', 2, NULL, NULL, '2019-11-11 10:00:27'),
(60, '2', 'nais11', '6522211', 'uani11s@gmail.com', 'sd11fdsvdcxv dc', '53', '27', '230', 2, NULL, NULL, '2019-11-11 10:00:44'),
(61, '2', 'nais11', '6522211', 'uani11s@gmail.com', 'sd11fdsvdcxv dc', '53', '27', '230', 2, NULL, NULL, '2019-11-11 10:00:56'),
(66, '2', 'nais11', '6522211', 'uani11s@gmail.com', 'sd11fdsvdcxv dc', '53', '27', '230', 2, NULL, NULL, '2019-11-11 10:46:31'),
(71, '5', 'Ajith', '12345678', 'ajith@whytestudio.co', 'Wijergowrgioerjyioejrioywjrkotyjrwtkojrtkoyjotjwotjwktgjrekltjrjyrjortjk', '10', '20', '20', 8, NULL, NULL, '2019-11-11 11:10:33'),
(80, '15', 'wedsadwq', '98765432', 'aqwsed@DFG.FSGD', 'DFG', '3434', '34', '34', 8, NULL, NULL, '2019-11-13 08:07:49'),
(81, '15', 'wedsadwq', '98765432', 'aqwsed@DFG.FSGD', 'DFG', '3434', '34', '34', 8, NULL, NULL, '2019-11-13 08:07:59'),
(82, '15', 'wedsadwq', '98765432', 'aqwsed@DFG.FSGD', 'DFG', '3434', '34', '34', 8, NULL, NULL, '2019-11-13 08:08:10'),
(83, '2', 'Sneha', '12345678', 'sneha@dd.lk', 'Thgrehtiehirhjyirhjkhkhnkdhkdjkhdjkohj', '12', '25', '25', 9, NULL, NULL, '2019-11-22 05:30:46'),
(89, '4', 'smith', '45646546', 'ajith@whytecreations.co', 'Testaddress', '123', '12', '12', 8, NULL, NULL, '2019-12-20 11:12:46'),
(90, '7', 'mohammed', '66655997', 'mgalsulaiti8@gmail.com', 'Aldafna', '55', '55', '55', 8, '25.330362667206007', '51.51633895933628', '2020-10-21 13:11:29'),
(91, '8', 'smith', '65464648', 'ajith@whytecreations.co', 'Address', '3232', '232', '232', 8, '26.129728170067665', '51.25270329415798', '2020-01-07 11:53:49'),
(92, '13', 'Unais Elliasdsa', '12345678', 'unaisellias@gmail.com', 'New Test address', '50', '27', '27', 9, NULL, NULL, '2020-01-02 10:37:38'),
(93, '13', 'Unais ELlias 2', '85236974', 'unais@gmail.com', 'Test address', '20', '21', '21', 8, NULL, NULL, '2020-01-02 10:29:18'),
(94, '12', 'ajith', '12345678', 'ajith@whytecreations.co', 'Address’s', '2', '2', '2', 8, NULL, NULL, '2020-01-02 10:59:47'),
(95, '14', 'test', '32132132', 'test@test.com', 'Address', '2', '2', '2', 8, NULL, NULL, '2020-01-02 12:06:03'),
(96, '16', 'test', '25896314', 'tets@tets.com', 'Test', '50', '27', '27', 9, NULL, NULL, '2020-01-02 13:08:53'),
(98, '18', 'test', '46464646', 'test@test.com', 'Address', '2', '2', '2', 8, '25.16980641059486', '51.594683602452285', '2020-01-16 12:09:01'),
(101, '18', 'smith', '51545165', 'test@whyte.com', 'Address', '20', '20', '20', 8, '25.517236855843578', '51.21901474893093', '2020-01-16 12:07:02'),
(104, '5', 'test', '32569874', 'test@gmail.com', 'Test', '25', '32', '32', 9, '25.28538419695269', '51.592094264924526', '2020-01-07 11:27:28'),
(105, '7', 'gogo', '66655997', 'mgalsulaiti8@gmail.com', 'Aldafna', '55', '55', '55', 8, '25.33033690869079', '51.516316160559654', '2020-09-30 10:49:57'),
(114, '20', 'qqww', '22333333', 'rr@rr.com', 'eee', 'rr', '66', '66', 9, '25.354824999999998', '51.18388333333334', '2020-01-15 12:30:48'),
(115, '20', 'ww', '22222222', 'ee@ww.com', 'ee', '33', '33', '33', 8, '25.354824999999998', '51.18388333333334', '2020-01-15 11:27:33'),
(116, '20', 'e', '22222222', 'ee@ee.com', 'qqq', '44', '44', '44', 8, '25.354824999999998', '51.18388333333334', '2020-01-15 11:35:31'),
(117, '20', 'q', '22222222', 'err@jj.com', 'eee', '33', '33', '33', 8, '25.354824999999998', '51.18388333333334', '2020-01-15 11:36:54'),
(118, '20', 'rrr', '33333333', 'gg@ww.com', 'rrr', '33', '33', '33', 8, '25.354824999999998', '51.18388333333334', '2020-01-15 11:37:53'),
(119, '20', 'aaa', '11111111', 's@h.com', 'sss', '33', '33', '33', 8, '25.354824999999998', '51.18388333333334', '2020-01-15 11:41:08'),
(120, '20', 'aaa', '11111111', 's@h.com', 'sss', '33', '33', '33', 8, '25.354824999999998', '51.18388333333334', '2020-01-15 11:41:26'),
(122, '22', 'test name', '25896347', 'test@gmail.com', 'test', '50', '70', '79', 8, '25.02758684662973', '51.65079206228256', '2020-01-16 09:36:03'),
(126, '33', 'Backet User 1', '77481474', 'basketqa2019@gmail.com', 'Demo', '21', '22', '21', 8, '25.2837444', '51.231768', '2020-08-10 00:06:33'),
(130, '36', 'werw', '43346', 'sadf12@gmail.com', '124325', '23', '11', '12', 8, '25.2837444', '51.231768', '2020-09-08 09:12:14'),
(131, '10', 'Unais Name', '31401159', 'unais@gmail.com', 'Doha', '54', '52', '53', 8, '25.279238553768735', '51.51421698505859', '2020-09-15 15:12:13'),
(132, '37', 'Ali Hassan', '32165498', 'ali@whytecreations.com', 'ali@whytecreations.com', '85', '52', '53', 8, '25.276754966303447', '51.5313831227539', '2020-09-15 16:07:48'),
(133, '38', 'JASIM', '98765432', 'jasim@gmail.com', 'Demo Account', '85', '86', '87', 8, '25.286524097086534', '51.52966650898437', '2020-09-15 16:25:32'),
(134, '38', 'Mohammed', '66655997', 'mgalsulaiti8@gmail.com', '', '55', '65', '910', 8, '25.2837444', '51.231768', '2020-09-15 18:48:50'),
(135, '40', 'shipping address', '43346', 'sadf12@gmail.com', 'ersf', '23', '23', '23', 8, '25.2837444', '51.231768', '2020-09-17 09:19:10'),
(136, '42', 'bhanu', '42365578', 'ichacku@gmail.com', 'Dhhfgj', '525', '55', '55', 9, '25.254581373758207', '51.44978765398264', '2020-09-19 08:36:24'),
(137, '10', 'test', '12345678', 'test@gmsim.com', 'Tesr', '25', '26', '26', 9, '46.0019567241086', '-0.15145864337682724', '2020-10-12 09:49:18'),
(138, '10', 'unais', '25863314', 'unais@gmail.com', 'Test', '258', '23', '23', 9, '25.364986850202158', '51.54799439013004', '2020-11-09 08:14:07'),
(139, '45', 'arjun', '12345678', 'arjunkn.95@gmail.com', '1236547', 'a22', '22', '22', 9, '25.345736795167028', '51.18887946009636', '2020-11-09 11:43:52'),
(140, '35', 'try', '12345678', 'ajith@whyte.com', 'Err retry', 'ertrt', 'ret', 'ret', 8, '55.48085377945495', '25.23966059088707', '2020-12-26 09:49:37'),
(141, '21', 'gdfgdf', '12345678', 'ajith@ewhyte.com', 'Test', '32', '12', '12', 8, '51.17889991879489', '-1.8263999372720716', '2021-01-18 11:14:34'),
(142, '56', 'unais', '09207406780', 'contact.unais@gmail.com', 'EKM', '500', '500', '5000', 8, '25.288861974966373', '51.54408606464843', '2021-01-24 13:41:42'),
(143, '57', 'Jshbs', '76767578', 'demo@demo.com', 'Shsbbbs', '7363', '7363', '7363', 8, '25.279238553768735', '51.528293217968745', '2021-02-15 09:52:33');

-- --------------------------------------------------------

--
-- Table structure for table `shop_details`
--

CREATE TABLE `shop_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shop_type` varchar(250) DEFAULT NULL,
  `name` varchar(250) NOT NULL,
  `owner_name` varchar(250) NOT NULL,
  `number` varchar(250) NOT NULL,
  `building_no` varchar(250) NOT NULL,
  `zone_no` varchar(250) NOT NULL,
  `street_no` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL,
  `address` text NOT NULL,
  `registration_number` varchar(250) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shop_details`
--

INSERT INTO `shop_details` (`id`, `user_id`, `shop_type`, `name`, `owner_name`, `number`, `building_no`, `zone_no`, `street_no`, `city`, `address`, `registration_number`, `created_date`) VALUES
(1, 1, '', 'Big Shop', 'Unais ELlias', '65478932', '50', '27', '230', '8', 'EKM DOHA', '52200011', '2019-10-20 14:45:03'),
(2, 1, '', 'New Shop in Doha', 'Unais Ellias', '65432108', '50', '50', '500', '9', 'EKM DOHA', '852000315', '2019-10-20 08:11:36'),
(3, 11, '', '44', '44', '44', '44', '44', '44', '8', '44', '44', '2019-10-26 12:26:59'),
(6, 12, '', 'Whyte Creations', 'Sayd Fasil Bafaky Thangal', '56', '21', '23', '444', '8', '19190 Doha, Doha', '346', '2019-10-26 14:31:40'),
(7, 2, '', 'test', 'tester', '001', '002', '320', '45', '9', 'doha', '123456789', '2019-12-02 10:57:01'),
(8, 10, 'individual', 'Whyte Shop', 'Unais ELlias', '230', '12', '12', '21', '8', 'Testy', '123454', '2020-01-12 12:32:29'),
(9, 35, 'company', 'Unais 432we78', 'xcv dffr34werfvd', 'jslchxbvsadsxcv ds', '345', '3453', '34534', '8', '3453424', '345r34252', '2020-09-03 17:15:09'),
(10, 35, 'company', 'unaisergv4rew', 'wergw', 'wertfew', '50', '435', '345', '8', 'unais', '1111', '2020-09-03 17:27:05'),
(11, 10, NULL, 'Whyte2', 'Sayd', '70274727', '23', '23', '23', '9', 'Test', 'S6en', '2020-09-06 15:18:16'),
(12, 40, 'company', '123 Shop', 'Unais', '12345678', '56', '89', '98', '8', 'EKM', '1234567890', '2020-09-17 08:10:57'),
(13, 41, 'company', 'bhanu', 'bhanu', '32535345', '12', '12', '12', '8', '342354', '342355', '2020-09-17 09:03:44'),
(14, 41, NULL, 'Addshopp chking', 'bhanu', '34555463546', '23', '23', '23', '8', '23324234', '34234234', '2020-09-17 10:18:09'),
(15, 56, 'company', 'Whyte S ho p', 'Unais ELlias', '230', '500', '600', '700', '8', 'Testy', '52200011', '2021-01-24 13:40:16');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(191) UNSIGNED NOT NULL,
  `subtitle_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `subtitle_size` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle_color` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle_anime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `title_size` varchar(50) DEFAULT NULL,
  `title_color` varchar(50) DEFAULT NULL,
  `title_anime` varchar(50) DEFAULT NULL,
  `details_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `details_size` varchar(50) DEFAULT NULL,
  `details_color` varchar(50) DEFAULT NULL,
  `details_anime` varchar(50) DEFAULT NULL,
  `photo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `subtitle_text`, `subtitle_size`, `subtitle_color`, `subtitle_anime`, `title_text`, `title_size`, `title_color`, `title_anime`, `details_text`, `details_size`, `details_color`, `details_anime`, `photo`, `position`, `link`) VALUES
(8, 'World Fashion', '24', '#000000', 'slideInUp', 'Get Up to 40% Off', '36', '#a31c1c', 'slideInDown', 'Highlight your personality  and look with these fabulous and exquisite fashion.', '16', '#000000', 'slideInRight', '1567536005slider1.jpg', 'slide-one', 'https://www.google.com/'),
(9, 'World Fashion', '24', '#000000', 'slideInUp', 'Get Up to 40% Off', '36', '#a32727', 'slideInDown', 'Highlight your personality  and look with these fabulous and exquisite fashion.', '16', '#000000', 'slideInDown', '1567535993slider1 (2).jpg', 'slide-two', 'https://www.google.com/'),
(10, 'World Fashion', '24', '#000000', 'slideInUp', 'Get Up to 40% Off', '36', '#b01c1c', 'slideInDown', 'Highlight your personality  and look with these fabulous and exquisite fashion.', '16', '#000000', 'slideInLeft', '1567535981slider1 (1).jpg', 'slide-three', 'https://www.google.com/');

-- --------------------------------------------------------

--
-- Table structure for table `socialsettings`
--

CREATE TABLE `socialsettings` (
  `id` int(10) UNSIGNED NOT NULL,
  `facebook` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gplus` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `twitter` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `linkedin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dribble` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `f_status` tinyint(4) NOT NULL DEFAULT '1',
  `g_status` tinyint(4) NOT NULL DEFAULT '1',
  `t_status` tinyint(4) NOT NULL DEFAULT '1',
  `l_status` tinyint(4) NOT NULL DEFAULT '1',
  `d_status` tinyint(4) NOT NULL DEFAULT '1',
  `f_check` tinyint(10) DEFAULT NULL,
  `g_check` tinyint(10) DEFAULT NULL,
  `fclient_id` text COLLATE utf8mb4_unicode_ci,
  `fclient_secret` text COLLATE utf8mb4_unicode_ci,
  `fredirect` text COLLATE utf8mb4_unicode_ci,
  `gclient_id` text COLLATE utf8mb4_unicode_ci,
  `gclient_secret` text COLLATE utf8mb4_unicode_ci,
  `gredirect` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `socialsettings`
--

INSERT INTO `socialsettings` (`id`, `facebook`, `gplus`, `twitter`, `linkedin`, `dribble`, `f_status`, `g_status`, `t_status`, `l_status`, `d_status`, `f_check`, `g_check`, `fclient_id`, `fclient_secret`, `fredirect`, `gclient_id`, `gclient_secret`, `gredirect`) VALUES
(1, 'https://www.facebook.com', 'https://plus.google.com', 'https://twitter.com', 'https://www.linkedin.com', 'https://dribbble.com/', 1, 1, 1, 1, 0, 1, 1, '1384751275018261', '5cca2411ce2c85988ae562ece21c110d', 'https://basket.qa/beta-api/public/auth/facebook/callback', '790484802187-lo3f6de3e0usrvod7540794c937rfb8k.apps.googleusercontent.com', 'dtTGgpJDeynYy81PpXiU4qxS', 'https://basket.qa/beta-api/public/auth/google/callback');

-- --------------------------------------------------------

--
-- Table structure for table `social_providers`
--

CREATE TABLE `social_providers` (
  `id` int(191) NOT NULL,
  `user_id` int(191) NOT NULL,
  `provider_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `social_providers`
--

INSERT INTO `social_providers` (`id`, `user_id`, `provider_id`, `provider`, `created_at`, `updated_at`) VALUES
(1, 1, '2348062955456706', 'facebook', NULL, NULL),
(3, 5, '112607444276138367455', 'google', NULL, NULL),
(4, 6, '109139086274687786873', 'google', '2019-12-23 20:44:38', '2019-12-23 20:44:38'),
(5, 7, '110245776940995690858', 'google', '2019-12-24 13:43:06', '2019-12-24 13:43:06'),
(6, 8, '153673889167413', 'facebook', NULL, NULL),
(7, 9, '10150077853374079', 'facebook', '2020-01-01 08:57:51', '2020-01-01 08:57:51'),
(8, 14, '2165880966857383', 'facebook', NULL, NULL),
(9, 17, '110245776940995690858', 'google', NULL, NULL),
(10, 18, '102361250380681593957', 'google', NULL, NULL),
(11, 21, '118434483821420860422', 'google', NULL, NULL),
(12, 29, '180875773077619', 'facebook', NULL, NULL),
(13, 30, '2766855423406206', 'facebook', NULL, NULL),
(14, 43, '102967175362702494464', 'google', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` int(191) NOT NULL,
  `category_id` int(191) NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(191) NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `email`) VALUES
(1, 'testerwhytecreations@gmail.com\r\n'),
(2, 'albin@gmail.com'),
(3, 'albin@gmail.com'),
(4, 'fasilbafaky@gmail.com'),
(5, 'fasil@whytecreations.com'),
(6, 'fasilbafaky07@gmail.com'),
(7, 'admin@shop.com'),
(8, 'admin@sheltergroup.com'),
(9, 'admin@sheltergroup.com'),
(10, 'admin@sheltergroup.com'),
(11, 'admin@sheltergroup.com'),
(12, 'admin@sheltergroup.com'),
(13, 'admin@sheltergroup.com'),
(14, 'admin@sheltergroup.com'),
(15, 'admin@sheltergroup.com'),
(16, 'testceh1984@gmail.com'),
(17, 'sample@email.tst'),
(18, 'cfd80c1f6d92a633df0c16dd490ac942prx@ssemarketing.net');

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` int(11) NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `days` int(11) NOT NULL,
  `allowed_products` int(11) NOT NULL DEFAULT '0',
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `title`, `currency`, `currency_code`, `price`, `days`, `allowed_products`, `details`) VALUES
(1, 'Basic', 'QAR', 'QAR', 30, 30, 1, '<span style=\"color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" text-align:=\"\" justify;\"=\"\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span><br>'),
(5, 'Standard', 'QAR', 'QAR', 60, 45, 25, '<ol><li>Lorem ipsum dolor sit amet<br></li><li>Lorem ipsum dolor sit ame<br></li><li>Lorem ipsum dolor sit am<br></li></ol>'),
(6, 'Premium', 'QAR', 'QAR', 120, 90, 90, '<span style=\"color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" text-align:=\"\" justify;\"=\"\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span><br>'),
(7, 'Unlimited', 'QAR', 'QAR', 260, 365, 0, '<span style=\"color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" text-align:=\"\" justify;\"=\"\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span><br>'),
(8, 'Plan 750', 'Qatari Riyals', 'QAR', 750, 60, 1, '11czxzxczcxz zcx'),
(9, 'Test', 'QAR', 'QAR', 33, 33, 3, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_token` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_provider` tinyint(10) NOT NULL DEFAULT '0',
  `status` tinyint(10) NOT NULL DEFAULT '0',
  `verification_link` text COLLATE utf8mb4_unicode_ci,
  `email_verified` enum('Yes','No') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'No',
  `affilate_code` text COLLATE utf8mb4_unicode_ci,
  `affilate_income` double NOT NULL DEFAULT '0',
  `shop_name` text COLLATE utf8mb4_unicode_ci,
  `owner_name` text COLLATE utf8mb4_unicode_ci,
  `shop_number` text COLLATE utf8mb4_unicode_ci,
  `shop_address` text COLLATE utf8mb4_unicode_ci,
  `reg_number` text COLLATE utf8mb4_unicode_ci,
  `shop_type` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shop_message` text COLLATE utf8mb4_unicode_ci,
  `shop_details` text COLLATE utf8mb4_unicode_ci,
  `shop_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `f_url` text COLLATE utf8mb4_unicode_ci,
  `g_url` text COLLATE utf8mb4_unicode_ci,
  `t_url` text COLLATE utf8mb4_unicode_ci,
  `l_url` text COLLATE utf8mb4_unicode_ci,
  `is_vendor` tinyint(1) NOT NULL DEFAULT '0',
  `f_check` tinyint(1) NOT NULL DEFAULT '0',
  `g_check` tinyint(1) NOT NULL DEFAULT '0',
  `t_check` tinyint(1) NOT NULL DEFAULT '0',
  `l_check` tinyint(1) NOT NULL DEFAULT '0',
  `mail_sent` tinyint(1) NOT NULL DEFAULT '0',
  `shipping_cost` double NOT NULL DEFAULT '0',
  `current_balance` double NOT NULL DEFAULT '0',
  `date` date DEFAULT NULL,
  `ban` tinyint(1) NOT NULL DEFAULT '0',
  `fb_user_id` text COLLATE utf8mb4_unicode_ci,
  `gmail_user_id` text COLLATE utf8mb4_unicode_ci,
  `building_no` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zone_no` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street_no` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `photo`, `zip`, `city`, `address`, `phone`, `fax`, `email`, `password`, `app_token`, `remember_token`, `created_at`, `updated_at`, `is_provider`, `status`, `verification_link`, `email_verified`, `affilate_code`, `affilate_income`, `shop_name`, `owner_name`, `shop_number`, `shop_address`, `reg_number`, `shop_type`, `shop_message`, `shop_details`, `shop_image`, `f_url`, `g_url`, `t_url`, `l_url`, `is_vendor`, `f_check`, `g_check`, `t_check`, `l_check`, `mail_sent`, `shipping_cost`, `current_balance`, `date`, `ban`, `fb_user_id`, `gmail_user_id`, `building_no`, `zone_no`, `street_no`) VALUES
(1, 'Unais Ellias', '15775327391577532732390.jpg', NULL, '8', NULL, '31404159', NULL, 'test@gmail.com', NULL, '2348062955456706', 'bdiKOAYRHfOGgu9LuqLvqPjbx6TR9S67ACnKYHmcpc2Cb68gmFiyC8iOIClr', '2019-12-23 19:01:59', '2019-12-28 18:40:56', 0, 0, NULL, 'No', NULL, 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, '2348062955456706', NULL, '21', '22', '23'),
(5, 'Unais', NULL, NULL, '8', 'test', '31404159', NULL, 'test@gmail.com', NULL, '112607444276138367455', 'U21ICt0KKRANOQKROtkvpaMjv118bv0NohewVoIZ5kno7HmtdTYXsKcd3rN3', '2019-12-23 19:11:38', '2019-12-23 19:11:38', 0, 0, NULL, 'No', NULL, 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, '112607444276138367455', '21', '22', '23'),
(6, 'SMTP WHYTE', 'https://lh3.googleusercontent.com/-rGe8YJj41MI/AAAAAAAAAAI/AAAAAAAAAAA/ACHi3rf9WQ1u_oB8ywTnE295UTxiCh9Y_A/photo.jpg', NULL, NULL, NULL, NULL, NULL, 'smtp.whyte@gmail.com', NULL, '109139086274687786873', 'LLTK1HyXGqbuTgVhDnyt3k3gM3DnoktLtduL3mtb9FATXgCLgtVZ2WecSWSf', '2019-12-23 20:44:38', '2019-12-23 20:44:38', 1, 0, NULL, 'Yes', '7fffb159aecc6b8f3b2828b8837c4689', 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(7, 'Mohammed Alsulaiti', '1605416297photo1.jpeg', NULL, '0', 'aldafna', '66655997', NULL, 'mgalsulaiti8@gmail.com', NULL, '110245776940995690858', NULL, '2019-12-24 13:43:06', '2019-12-24 13:43:06', 1, 0, NULL, 'Yes', 'bc9914a40d6b7c38938084bda4e3cbce', 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, '55', '99', '55'),
(8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '153673889167413', NULL, '2019-12-30 13:24:52', '2019-12-30 13:24:52', 0, 0, NULL, 'No', NULL, 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, '153673889167413', NULL, NULL, NULL, NULL),
(9, 'Navtej Reddy', 'https://graph.facebook.com/v3.0/10150077853374079/picture?width=1920', NULL, NULL, NULL, NULL, NULL, 'geogatedproject202@gmail.com', NULL, '10150077853374079', NULL, '2020-01-01 08:57:51', '2020-01-01 08:57:51', 1, 0, NULL, 'Yes', 'd9f31fce4123a7b34293cb8827414abb', 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(10, 'unais', NULL, NULL, '8', 'test', '1234', NULL, 'email@gmail.com', '$2y$10$jU/H/3.cNB/GJqwvrDK5.eyXZexZegxyVdw5rdirPNaMiKIuLZ.U6', 'e8e89f21039b0a409a96e9945dbc921a', '9TMssV10QHS9BuHEDoJEZ6jgZceFie57AQblaXbi632g4yMdj7vG73Vspoym', '2020-01-02 17:09:24', '2020-11-11 00:00:18', 0, 1, 'a0fb31ee2d408b744de9592de2083414', 'Yes', '2f48a13716ae5d1a8151844ee4936c9d', 0, 'Whyte Shop', 'Unais ELlias', '230', 'Testy', '123454', 'individual', 'rwe', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 867, '2020-11-10', 0, NULL, NULL, '20', '270', '10'),
(11, 'Unais Ellias', NULL, NULL, NULL, NULL, '92074406780', NULL, 'testun@gmail.com', '$2y$10$hcIEJ118OuItmgoL3qyzL.iXb22majryKMnetmWRilTTQ5SHT5Uaq', '9da12d4e1641a56bc9866e9f9779f05e', NULL, '2020-01-02 17:22:20', '2020-01-02 17:22:20', 0, 0, '1a833de08202134439af116773337cde', 'No', 'e51265bd12c0f581838de61c22d73880', 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(12, 'ajith', NULL, NULL, '0', NULL, '12345678', NULL, 'ajith@whytecreations.co', '$2y$10$H7g4z/Q3.wpDQwY9T5/ZGuN8Dra6IJMxhbqsxZDj64B57fvpXysYG', '0af72cc91b773d5ed39633bf41b40b23', NULL, '2020-01-02 17:22:57', '2020-01-02 17:22:57', 0, 0, 'a3896447f6464aedd5abe151ca1d09b9', 'No', '39f8c0dd9134dde6d6dfaf7220aeb8de', 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(13, 'Unais EE', NULL, NULL, '0', NULL, '31404180', NULL, 'testunais@gmail.com', '$2y$10$PK.RhGiI5LTETvgqKpin/.OpLvq4Ek6Ql..SXGPCAtwxG9iQZ/PWm', 'cada309d6ab7668b2e2c7269bd3ca0be', NULL, '2020-01-02 17:25:18', '2020-01-02 17:25:18', 0, 0, '454da47fa591a525452f52cf12d77f13', 'No', 'dfb31f48c005bcd527b236902e4628f5', 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2165880966857383', NULL, '2020-01-02 19:04:58', '2020-01-02 19:04:58', 0, 0, NULL, 'No', NULL, 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, '2165880966857383', NULL, NULL, NULL, NULL),
(15, 'Unais Ellias', NULL, NULL, NULL, NULL, '31404159', NULL, 'contact11.unais@gmail.com', '$2y$10$dl4BBCNn74d2JQ.qsjrSKuZYxUz.ww6yXk0QTpj2EE.WK3x88FlEG', NULL, NULL, '2020-01-02 20:02:58', '2020-01-02 20:02:58', 0, 0, 'fd85a7c98e5e2aba56e95e415d505c69', 'No', '7096c9d2f8cbf07f1c67d5776e7641c2', 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(16, 'Unais Elias', '1577970445photo1.jpeg', NULL, '0', NULL, '123654781', NULL, 'unais@gamil.com', '$2y$10$92lnWoXJS.mTazOvJeDo3.nwET2n6YyzLRdu6UiBLDwbk.Obdjclq', 'dc713a2e0dfb73cce8e4c6e769604c68', 'vO5xFCi3Ahe5PCnaQJXEsb1uGFEjVTjypSVJErInXytrbtzYV1CVSl9xfXkY', '2020-01-02 20:06:30', '2020-01-04 21:26:33', 0, 1, '5a48a5945b1e2f9bffb07fe1498bfbb8', 'Yes', '5fe7673a10d41cf4aa940f333e127252', 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(17, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '110245776940995690858', NULL, '2020-01-05 14:27:10', '2020-01-05 14:27:10', 0, 0, NULL, 'No', NULL, 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, '110245776940995690858', NULL, NULL, NULL),
(18, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '102361250380681593957', NULL, '2020-01-06 14:19:57', '2020-01-06 14:19:57', 0, 0, NULL, 'No', NULL, 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, '102361250380681593957', NULL, NULL, NULL),
(19, 'Unais Ellias', NULL, NULL, NULL, NULL, '92074406780', NULL, 'testun11@gmail.com', '$2y$10$M1Wxs79XBzOHAxeRWicdfe5UdIB.pAIRus.yX/Gvrayt.4LHBkWKO', 'ab7b6b71e006a05f55d8b6bdb418b3a3', NULL, '2020-01-15 14:56:30', '2020-01-15 14:56:30', 0, 0, 'f84ca69ec9b15ce868d051ea5d49541a', 'No', 'f78fee429f8db7876dc2923e4e7a9356', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(20, 'arjunkn', NULL, NULL, NULL, NULL, '12345678', NULL, 'aaa@a.com', '$2y$10$OqstIiIklTKdEVVHoDNN7.WkGR/d9IJG45rLhy4yA11tL03OZdmGS', '87630ead963bde601ed30c27260c5310', NULL, '2020-01-15 15:46:58', '2020-01-15 15:46:58', 0, 0, 'd29a1c498f9ab316a063cd58ee3290f4', 'No', 'bcca54d9e9510fad097c88319df4369c', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(21, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '118434483821420860422', NULL, '2020-01-16 12:48:42', '2020-01-16 12:48:42', 0, 0, NULL, 'No', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, '118434483821420860422', NULL, NULL, NULL),
(22, 'Unais', NULL, NULL, NULL, NULL, '32569888', NULL, 'unais@gmail.com', '$2y$10$eomCOrhV9E23qzjSCddR6eKZMgTBzBKRu6sQ1oDkjVcPHyHdPI6Z.', 'b04aacaefcfa481721033234a1fcf190', NULL, '2020-01-16 16:26:43', '2020-01-16 16:26:43', 0, 0, 'b7662b6c15a87f94bb2b7f458fbb0f3a', 'No', '040674a857a6eb3a7a233189b9268667', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(23, 'anci', NULL, NULL, NULL, NULL, 'ddf', NULL, 'as@mnb.com', '$2y$10$wwnbgf6Vb4g0OY/jgh7IXeXUuwelERl1sPQP9/m8UHWJletjSA.0a', '9601fbdffa8c5e41ef66a156c21360ae', NULL, '2020-01-17 16:09:26', '2020-01-17 16:09:26', 0, 0, 'd169e2a206c1a1c36f3520e828b339be', 'No', '75a245205bfc332a9143f7e2f33de2d9', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(24, 'ki', NULL, NULL, NULL, NULL, '12345', NULL, 'mhg@nj.com', '$2y$10$ESuiuvWa6pmrDKmeJeYb4OCs690qq/vQDZ3esipz8e4Re1yiA6qKC', '88ebea68d2ebe914db2d5cd41b474a74', NULL, '2020-01-17 16:27:32', '2020-01-17 16:27:32', 0, 0, 'f23349157ac8c759d4d1904bed09f808', 'No', 'cfce3be71ccd27a9f5cbc399a82069b0', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(25, 'ki', NULL, NULL, NULL, NULL, '12345', NULL, 'rty@cgu.com', '$2y$10$rxEgeFFG5bWVapRheI1bwO.Fj.E6cdPCCuFFJ6OX27QlALTVjyvoW', 'd637acd6ce2f013accf93727799de213', NULL, '2020-01-17 16:28:19', '2020-01-17 16:28:19', 0, 0, '7f691e234dbd91ac03349d4aeb75b7ec', 'No', '82e25aecc215bb63ed72c521a3bca0f5', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(26, 'qwe', NULL, NULL, NULL, NULL, 'xcc', NULL, 'qe@fg.bcb', '$2y$10$moj1B4aKsnBom31AIGrS.eB0Wik8scrRdXzli.pimX6vTMN3gXu4S', 'a17a533325e915471d92340d2ff9c530', NULL, '2020-01-17 16:49:18', '2020-01-17 16:49:18', 0, 0, 'a96064fd1649a0406f96e592d114cbf8', 'No', '397b31aaec8fa3d8cdd3d33e6cd5ec98', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(27, 'qwert', NULL, NULL, NULL, NULL, '1234', NULL, 'qwe@q.com', '$2y$10$8bL2QfJFVOQEY/fROcgzI.BSAtlNOzCLqxNLTriAUB2lvfXgysamu', 'b0b0711fafa53d6ba9c63cf39edf4c62', NULL, '2020-01-17 16:55:16', '2020-01-17 16:55:16', 0, 0, 'e57483c06a56fa81f4efd6e8fe8bdc14', 'No', '38d3278170adfb944d9415a5c0bd988f', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(28, 'qwe', NULL, NULL, NULL, NULL, '1234', NULL, 'qw@e.com', '$2y$10$TSfFlOT2sxl8IN4u5yyJyuGeQ/K9h/oJ2DMA2w7c/g6YsWXty7LnK', '06c908eeb0127562b4006813c3f0e3fd', NULL, '2020-01-17 17:05:47', '2020-01-17 17:05:47', 0, 0, 'd95b9e9e645ac16ba10460f71da190a6', 'No', 'b0fd4f3189444b46198a67659314c10c', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(29, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '180875773077619', NULL, '2020-05-13 12:34:10', '2020-05-13 12:34:10', 0, 0, NULL, 'No', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, '180875773077619', NULL, NULL, NULL, NULL),
(30, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2766855423406206', NULL, '2020-05-20 18:04:00', '2020-05-20 18:04:00', 0, 0, NULL, 'No', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, '2766855423406206', NULL, NULL, NULL, NULL),
(31, 'Ali', NULL, NULL, NULL, NULL, '31322424', NULL, 'alihassanclt@gmail.com', '$2y$10$gOsTgMLeCWP3XBOZdbypZui1CeRVzSuwkFQGHKPTc9SqIxLWfKxVC', NULL, NULL, '2020-05-24 20:08:12', '2020-05-24 20:13:47', 0, 0, 'e74fd19afa6537b32fdc779b1e768467', 'Yes', '794c6d239a749eb0ca2e483e873ab978', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(32, 'azfad', NULL, NULL, NULL, NULL, '+1215454', NULL, 'www.gov.dz@gmail.com', '$2y$10$7TuKY/tpcFcOFE4GvY0R9.JxhkQ5Yn13dPhoVzCSxmRM04Q76n2bW', NULL, 'dSehk8BKUN4L1YIy08gxpKd2VTjNP9xypp5o7EGXlLt6olpLioC7svlRLZhv', '2020-08-03 03:38:13', '2020-08-03 03:38:13', 0, 0, '6e3be3b576894849b242cb2f1bf93a73', 'No', '9491b366bbeeabbdb347a06853084d99', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(33, 'Basket User 1', NULL, NULL, NULL, NULL, '77481474', NULL, 'basketqa2019@gmail.com', '$2y$10$YjpFexNOmXKDkm20Wmp3B.q63FYGHn5cM6/vqSyPGZDQlsvB5lQa6', NULL, 'NqGaXklukm4tEiVCLRrxjEJoeZjsevcIrsoXayCPLfVs8PdpTCqUSkmCc5YL', '2020-08-10 14:02:34', '2020-08-10 14:02:34', 0, 1, 'f1bfe5eee9a16620f86c8a157d7e7847', 'Yes', 'fee62ff4c4a4eabd228add26769bf051', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(35, 'unais', NULL, NULL, '8', 'test', '1234', NULL, 'email@gmail.com', '$2y$10$uleStnoOFKLHrPcr4wxni.BIhVcDfZahyjIh3/7l1TzH3BPdSU4wq', '7f91d68f3d4916f5ae7786734888e1bf', 's3Hs2VsMDjw0mXeDQ2IDF2RwOwREqTQoPqJ6sGseq17upM4HCOjdTq2pCReR', '2020-09-03 12:55:23', '2020-10-04 00:03:07', 0, 0, '720bea8de340748fc8b77ee1f4a07be9', 'Yes', '0aa889260c0c535ae6b79950cb13290d', 0, 'unaisergv4rew', 'wergw', 'wertfew', 'unais', '1111', 'company', 'wregfwe', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, '2020-10-03', 0, NULL, NULL, '20', '270', '10'),
(36, 'bhanu', '1599554489Swan-3.png', NULL, NULL, NULL, '34646467', NULL, 'bhanusai1112+1@gmail.com', '$2y$10$UAovA0xMcsTYqfizJ9vbdOTyR8dOUWySvlBkVRYhChoZm3PbIo5aC', NULL, 'iYf1CarcFrn2mt0OTejcEOB642uZ3wB3NjMopRlfEMu2tNoBhjPhPdsOUoQf', '2020-09-08 08:32:30', '2020-09-17 07:35:38', 0, 1, '4591c0e19d351b70450711a00a350b5e', 'Yes', 'd6b9d54436b7bc98c404a080ad59ab09', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(37, 'Ali', NULL, NULL, NULL, NULL, '30192000', NULL, 'ali@whytecreations.com', '$2y$10$ENyvNMqtUh4gRhUWx8OeSOOPwuxwko0smnDoZtR/zdGmsQdBBFMaG', NULL, 'cwUk8dbhtfVH8F7jsxujo6qiLbK18BLlYiaoA7eAsMjFUngkhHg8ivV308w7', '2020-09-15 16:05:39', '2020-09-15 16:06:25', 0, 0, '5eac82e42f6ae8063ab254a300a54f6d', 'Yes', 'a2b57ea10af34d9eec3527cca66fbb16', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(38, 'Jasim', NULL, NULL, NULL, NULL, '98765432', NULL, 'jasim@gmail.com', '$2y$10$XdWZ6rvNihZTuApZ8J07Fui8vd7SMnUW5cVxmSwqdRjqSjuM8jGr2', NULL, 'A0jp0gVC3E1Qi05nuiOFyCeLQZ4XqLvqgrlirZc2idrE8GNVoSqwQIYOueWs', '2020-09-15 16:23:54', '2020-09-15 16:23:54', 0, 1, '307f7ef8728fd99e05fa9a66627433fa', 'Yes', '2c7700a28a62d10a636b18879f88357e', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(39, 'sep17', NULL, NULL, NULL, NULL, '34646467', NULL, 'noorayene@forwardcreation.com', '$2y$10$i5pI43R7NVyiJYLizw4XB.KpP.3X1HWLDS7auHPo2GsgeTzIV1aUK', NULL, NULL, '2020-09-17 07:17:26', '2020-09-17 07:17:26', 0, 0, 'd40ff1ea1b13655204abd470d2046430', 'No', '2d26b164ff459d240361fadd305b0fee', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(40, 'Bhanu', '1600335531Yogamat.jpg', NULL, '8', NULL, '31404159', NULL, 'bhanusai1112@gmail.com', '$2y$10$.NxbDCf/AKgUxSjtnLNsi.ZlUSFVEq3qTg/feBb0FBx5HcapMgpdm', NULL, 'iU5sYVYadHSmsUxWGFy1jiqwZkQAyPDVizkwqUwMTK9eRZde1RUlUaQlX8pM', '2020-09-17 08:08:08', '2020-10-21 00:01:27', 0, 1, '0395f2fc6ccade036d6bdb8268943655', 'Yes', '03f8bb167b4eec5fa635cee04011e07f', 0, '123 Shop', 'Unais', '12345678', 'EKM', '1234567890', 'company', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 0, '2020-10-20', 0, NULL, NULL, '56', '89', '98'),
(41, 'bhanu2', '16003328722878458a.jpg', NULL, '8', NULL, '34646467', NULL, 'projects@whytecreations.in', '$2y$10$cxmv/Vn0oKSlNQB/msl8z.Y/N/pnQ6BbA8cH.KTYBSKXH4kdiuu.2', NULL, 'FIvrCsB1wp4GPUk2sCbwYkCuwcjAVVrfweg0oPtiQgAcI7bU348bT2PKasXs', '2020-09-17 08:33:30', '2020-10-18 00:03:12', 0, 1, '1fff7d3c0fad4a13e158fc677a80dc34', 'Yes', '744a63373cf78f64206b50848d73e168', 0, 'bhanu', 'bhanu', '32535345', '342354', '342355', 'company', 'etset', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 0, 0, 0, 0, 99, '2020-10-17', 0, NULL, NULL, '12', '12', '12'),
(42, 'iosttst', NULL, NULL, NULL, NULL, '25896374', NULL, 'ichacku@gmail.com', '$2y$10$SVlKORAUTtzVl4MWQD8Rkepfi6MET4WYmhQqFIWAA5Hb/iHPJBFwC', '9c91a0c09425f9d54fb3e83204299be2', NULL, '2020-09-19 08:25:57', '2020-09-19 08:25:57', 0, 0, '3c4863e686a91e9119b0097f4a71aca3', 'No', '9cab743a0e9c0d85aea5c0a1ae0c61eb', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '102967175362702494464', NULL, '2020-09-19 09:40:22', '2020-09-19 09:40:22', 0, 0, NULL, 'No', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, '102967175362702494464', NULL, NULL, NULL),
(44, 'hxebkzytpx', NULL, NULL, '8', 'cfd80c1f6d92a633df0c16dd490ac942prx@ssemarketing.net', '+1 213 425 1453', NULL, 'cfd80c1f6d92a633df0c16dd490ac942prx@ssemarketing.net', '$2y$10$a1N3s7JBT3uvsbEGjDEkYOpPWlX1xdjiIxuPQPV0CThXGYDe8oEQS', NULL, NULL, '2020-11-07 18:21:29', '2020-11-07 18:21:29', 0, 0, '0120171dec4774fa4b6d0ed83ed6c05e', 'No', 'd0023e2e0459608536198ef2634b1a58', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, 'zogzccehhv', 'mfphpmuvzc', '34 Watts road'),
(45, 'arjun', NULL, NULL, NULL, NULL, '12345678', NULL, 'arjunkn.95@gmail.com', '$2y$10$9b22TW8WSozHifT0JU3HLOBeAx4DvlEWgKR/8pTUKO4H.cqX7eZB2', '37a7a4448d94b76fe403da5f8109aa99', NULL, '2020-11-09 11:29:53', '2020-11-09 11:29:53', 0, 0, '0c60f40bc560d183f8ccf88d388fcde9', 'No', '3c32fc97e4ec2de304ed88d61adc4442', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(46, 'Bhanu', NULL, NULL, NULL, NULL, '34646467', NULL, 'designer@whytecreations.in', '$2y$10$GTZCa1j0udv6g4RbxZtxfuI594pMxlTEsaIm58ia.F60ZMkJOKIcq', NULL, NULL, '2020-11-29 07:55:13', '2020-11-29 12:18:09', 0, 0, '8e13dbb237c65eda50ade65fef116d0c', 'Yes', '326dcc73904ccfb5e3c0995a4802a4f2', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, NULL, NULL, NULL),
(47, 'Bhanu', NULL, NULL, '8', '21', '12345678', NULL, 'check@gmail.com', '$2y$10$S9X6xn7kJf51END1GPfhoOtI/Zb9fdiqAuCMFxy6cKAxa5G9XYOPW', NULL, NULL, '2020-12-08 10:11:02', '2020-12-08 10:11:02', 0, 0, '7e1b332b9cd7367bc1b1694996cf7e66', 'No', 'd21eb55bcbe9a6a49af1228e00169b92', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, '21', '12', '12'),
(48, 'Bhanu', NULL, NULL, '8', '21', '12345678', NULL, 'ichaku@gmail.com', '$2y$10$jnPPHlWC.clD47eeX0lyRufvpG0TcLlebgXruwr/dD9xcnFA8F9zy', NULL, NULL, '2020-12-08 10:11:39', '2020-12-08 10:11:39', 0, 0, '6a7d63fa9c8f1b1c58f89d070256df38', 'No', 'e93b02576d06aa4ad8bfd41b7a9a9163', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, '21', '12', '12'),
(49, 'Bhanu1', NULL, NULL, '8', '21', '12345678', NULL, 'ishaksyed19@gmail.com', '$2y$10$9ClWYqxIF/cW6hcuMGQs/ekQDlpJ4egbJdfchhH3VNWjQqp0a1fUy', NULL, NULL, '2020-12-08 10:14:57', '2020-12-08 10:14:57', 0, 0, '6d848390218f8732233d07aefbd024ad', 'No', 'b68fbc2765739620fa86e184a0d9ca58', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, '21', '12', '12'),
(56, 'Unais Ellias', NULL, NULL, '8', NULL, '31404156', NULL, 'unais.whyte@gmail.com', '$2y$10$eWZYg0RdVmka/lfKl4OeSewOawVFxS372OgEZLJlNscXtnwXsA9qa', NULL, 'uEFvN43uFcO8PUTYKlejULMldSHVYGVWYI4SjSXifZviqhldIh9rI9qaIqEd', '2021-01-24 13:16:05', '2021-02-18 00:00:32', 0, 0, 'ffd4281b1229704dea771735796fcf50', 'Yes', '0aa889260c0c535ae6b79950cb13290d', 0, 'Whyte S ho p', 'Unais ELlias', '230', 'Testy', '52200011', 'company', 'erfewrfwe', NULL, NULL, NULL, NULL, NULL, NULL, 2, 0, 0, 0, 0, 0, 0, 0, '2021-02-23', 0, NULL, NULL, '500', '600', '700'),
(57, 'SHAMEER NADUVILAKKANDIYIL', NULL, NULL, '9', 'NADUVILAKKANDIYIL VADAKARA', '08113844811', NULL, 'info@papayaqatar.com', '$2y$10$ZL.LNz38WDU9Q7s0tnNh9eRHnuFqUPq31OEEjYjkAtRIIccNrJepS', NULL, NULL, '2021-02-15 09:50:43', '2021-02-15 09:51:19', 0, 0, '16854376a2e2c5ee8ad94e3dfa8e4dad', 'Yes', '9c2f6d4b72edbc74e35a1557c23f42c1', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, NULL, NULL, '737', '73637', '7362772');

-- --------------------------------------------------------

--
-- Table structure for table `user_notifications`
--

CREATE TABLE `user_notifications` (
  `id` int(191) NOT NULL,
  `user_id` int(191) NOT NULL,
  `order_number` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_subscriptions`
--

CREATE TABLE `user_subscriptions` (
  `id` int(191) NOT NULL,
  `user_id` int(191) NOT NULL,
  `subscription_id` int(191) NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL DEFAULT '0',
  `days` int(11) NOT NULL,
  `allowed_products` int(11) NOT NULL DEFAULT '0',
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Free',
  `txnid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `charge_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_subscriptions`
--

INSERT INTO `user_subscriptions` (`id`, `user_id`, `subscription_id`, `title`, `currency`, `currency_code`, `price`, `days`, `allowed_products`, `details`, `method`, `txnid`, `charge_id`, `created_at`, `updated_at`, `status`) VALUES
(1, 12, 1, 'Basic', 'QAR', 'QAR', 30, 30, 1, '<span style=\"color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" text-align:=\"\" justify;\"=\"\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span><br>', 'Free', NULL, NULL, '2019-10-23 07:00:00', '2019-09-13 21:31:40', 1),
(2, 12, 1, 'Basic', 'QAR', 'QAR', 30, 30, 1, '<span style=\"color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" text-align:=\"\" justify;\"=\"\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span><br>', 'Free', NULL, NULL, '2019-10-27 22:45:10', '2019-10-27 22:45:10', 1),
(3, 2, 1, 'Basic', 'QAR', 'QAR', 30, 30, 1, '<span style=\"color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" text-align:=\"\" justify;\"=\"\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span><br>', 'Free', NULL, NULL, '2019-12-02 17:57:01', '2019-12-02 17:57:01', 1),
(4, 10, 1, 'Basic', 'QAR', 'QAR', 30, 30, 1, '<span style=\"color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" text-align:=\"\" justify;\"=\"\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span><br>', 'Free', NULL, NULL, '2020-01-12 19:32:29', '2020-01-12 19:32:29', 1),
(5, 10, 1, 'Basic', 'QAR', 'QAR', 30, 30, 1, '<span style=\"color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" text-align:=\"\" justify;\"=\"\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span><br>', 'Free', NULL, NULL, '2020-09-03 16:59:27', '2020-09-03 16:59:27', 1),
(6, 35, 1, 'Basic', 'QAR', 'QAR', 30, 30, 1, '<span style=\"color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" text-align:=\"\" justify;\"=\"\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span><br>', 'Free', NULL, NULL, '2020-09-03 17:15:09', '2020-09-03 17:15:09', 1),
(7, 35, 1, 'Basic', 'QAR', 'QAR', 30, 30, 1, '<span style=\"color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" text-align:=\"\" justify;\"=\"\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span><br>', 'Free', NULL, NULL, '2020-09-03 17:27:05', '2020-09-03 17:27:05', 1),
(8, 40, 9, 'Test', 'QAR', 'QAR', 33, 33, 3, 'test', 'Free', NULL, NULL, '2020-09-17 08:10:57', '2020-09-17 08:10:57', 1),
(9, 41, 1, 'Basic', 'QAR', 'QAR', 30, 30, 1, '<span style=\"color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" text-align:=\"\" justify;\"=\"\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span><br>', 'Free', NULL, NULL, '2020-09-17 09:03:44', '2020-09-17 09:03:44', 1),
(10, 10, 9, 'Test', 'QAR', 'QAR', 33, 33, 3, 'test', 'Free', NULL, NULL, '2020-10-08 06:55:54', '2020-10-08 06:55:54', 1),
(11, 56, 1, 'Basic', 'QAR', 'QAR', 30, 30, 1, '<span style=\"color: rgb(0, 0, 0); font-family: \" open=\"\" sans\",=\"\" arial,=\"\" sans-serif;=\"\" text-align:=\"\" justify;\"=\"\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span><br>', 'Free', NULL, NULL, '2021-01-24 13:40:16', '2021-01-24 13:40:16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vendor_orders`
--

CREATE TABLE `vendor_orders` (
  `id` int(191) NOT NULL,
  `user_id` int(191) NOT NULL,
  `order_id` int(191) NOT NULL,
  `qty` int(191) NOT NULL,
  `price` int(191) NOT NULL,
  `order_number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pending','processing','completed','declined') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor_orders`
--

INSERT INTO `vendor_orders` (`id`, `user_id`, `order_id`, `qty`, `price`, `order_number`, `status`) VALUES
(1, 10, 2, 2, 100, '5WIs1608815563', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `id` int(191) UNSIGNED NOT NULL,
  `user_id` int(191) UNSIGNED NOT NULL,
  `product_id` int(191) UNSIGNED NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wishlists`
--

INSERT INTO `wishlists` (`id`, `user_id`, `product_id`, `created_at`, `updated_at`) VALUES
(8, 18, 13, '2020-01-09 10:05:13', '2020-01-09 10:05:13'),
(9, 10, 20, '2020-09-06 16:15:40', NULL),
(12, 41, 10, '2020-09-17 08:55:21', NULL),
(13, 42, 20, '2020-09-19 08:27:55', '2020-09-19 08:27:55'),
(20, 35, 8, '2020-11-29 12:48:58', '2020-11-29 12:48:58'),
(22, 35, 20, '2020-11-29 12:49:32', '2020-11-29 12:49:32');

-- --------------------------------------------------------

--
-- Table structure for table `withdraws`
--

CREATE TABLE `withdraws` (
  `id` int(191) NOT NULL,
  `user_id` int(191) DEFAULT NULL,
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acc_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iban` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acc_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `swift` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `amount` float DEFAULT NULL,
  `fee` float DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` enum('pending','completed','rejected') NOT NULL DEFAULT 'pending',
  `type` enum('user','vendor') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `admin_user_conversations`
--
ALTER TABLE `admin_user_conversations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_user_messages`
--
ALTER TABLE `admin_user_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog_categories`
--
ALTER TABLE `blog_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `childcategories`
--
ALTER TABLE `childcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conversations`
--
ALTER TABLE `conversations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `delivery_time`
--
ALTER TABLE `delivery_time`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_templates`
--
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `favorite_sellers`
--
ALTER TABLE `favorite_sellers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `generalsettings`
--
ALTER TABLE `generalsettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pagesettings`
--
ALTER TABLE `pagesettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_gateways`
--
ALTER TABLE `payment_gateways`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pickups`
--
ALTER TABLE `pickups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_clicks`
--
ALTER TABLE `product_clicks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `replies`
--
ALTER TABLE `replies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seotools`
--
ALTER TABLE `seotools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipping_address`
--
ALTER TABLE `shipping_address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shop_details`
--
ALTER TABLE `shop_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `socialsettings`
--
ALTER TABLE `socialsettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_providers`
--
ALTER TABLE `social_providers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_subscriptions`
--
ALTER TABLE `user_subscriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendor_orders`
--
ALTER TABLE `vendor_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdraws`
--
ALTER TABLE `withdraws`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin_user_conversations`
--
ALTER TABLE `admin_user_conversations`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `admin_user_messages`
--
ALTER TABLE `admin_user_messages`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog_categories`
--
ALTER TABLE `blog_categories`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=450;

--
-- AUTO_INCREMENT for table `childcategories`
--
ALTER TABLE `childcategories`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `conversations`
--
ALTER TABLE `conversations`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `delivery_time`
--
ALTER TABLE `delivery_time`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `email_templates`
--
ALTER TABLE `email_templates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `favorite_sellers`
--
ALTER TABLE `favorite_sellers`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` int(191) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `generalsettings`
--
ALTER TABLE `generalsettings`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pagesettings`
--
ALTER TABLE `pagesettings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment_gateways`
--
ALTER TABLE `payment_gateways`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pickups`
--
ALTER TABLE `pickups`
  MODIFY `id` int(191) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(191) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `product_clicks`
--
ALTER TABLE `product_clicks`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2403;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `replies`
--
ALTER TABLE `replies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `seotools`
--
ALTER TABLE `seotools`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `shipping_address`
--
ALTER TABLE `shipping_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `shop_details`
--
ALTER TABLE `shop_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(191) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `socialsettings`
--
ALTER TABLE `socialsettings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `social_providers`
--
ALTER TABLE `social_providers`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `user_notifications`
--
ALTER TABLE `user_notifications`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_subscriptions`
--
ALTER TABLE `user_subscriptions`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `vendor_orders`
--
ALTER TABLE `vendor_orders`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` int(191) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `withdraws`
--
ALTER TABLE `withdraws`
  MODIFY `id` int(191) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
